variable "ado_work_item_template" {
  type    = string
  default = "Agile"

  validation {
    condition = (
      anytrue([
        var.ado_work_item_template == "Agile",
        var.ado_work_item_template == "Scrum",
        var.ado_work_item_template == "Basic",
        var.ado_work_item_template == "CMMI"
      ])
    )
    error_message = "Work item template must be Agile, Scrum, Basic, or CMMI."
  }
}

variable "ado_project_features" {
  type = object({
    boards       = string
    repositories = string
    pipelines    = string
    testplans    = string
    artifacts    = string
  })
  default = {
    boards       = "enabled"
    repositories = "enabled"
    pipelines    = "enabled"
    testplans    = "enabled"
    artifacts    = "enabled"
  }
}

####################### Platform Admin Group Permissions ###################

variable "platform_admin_project_permissions" {
  type = map(string)
  default = {
    GENERIC_READ                 = "Allow" # View project-level information
    GENERIC_WRITE                = "Allow" # Edit project-level information
    DELETE                       = "Deny"  # Delete
    PUBLISH_TEST_RESULTS         = "Allow" # Create test runs
    ADMINISTER_BUILD             = "Allow" # Administer a build
    START_BUILD                  = "Allow" # Start a build
    EDIT_BUILD_STATUS            = "Allow" # Edit build quality
    UPDATE_BUILD                 = "Allow" # Write to build operational store
    DELETE_TEST_RESULTS          = "Allow" # Delete test runs
    VIEW_TEST_RESULTS            = "Allow" # View test runs
    MANAGE_TEST_ENVIRONMENTS     = "Allow" # Manage test environments
    MANAGE_TEST_CONFIGURATIONS   = "Allow" # Manage test configurations
    WORK_ITEM_DELETE             = "Allow" # Delete and restore work items
    WORK_ITEM_MOVE               = "Allow" # Move work items out of this project
    WORK_ITEM_PERMANENTLY_DELETE = "Allow" # Permanently delete work items
    RENAME                       = "Allow" # Rename team project
    MANAGE_PROPERTIES            = "Allow" # Manage project properties
    BYPASS_RULES                 = "Deny"  # Bypass rules on work item updates
    SUPPRESS_NOTIFICATIONS       = "Allow" # Suppress notifications for work item updates
    UPDATE_VISIBILITY            = "Allow" # Update project visibility
    CHANGE_PROCESS               = "Allow" # Change process of team project.
    AGILETOOLS_PLANS             = "Allow" # Agile plans.

    #TODO: Find analytics permissions settings

    # Using the properties below will result in an error
    # Error: VS403284: Invalid operation. Unable to set bits '17563648' in security namespace '52d39943-cb85-4d7f-8fa8-c6baac873819' as it is reserved by the system.
    #MANAGE_SYSTEM_PROPERTIES     = "Allow" # Manage system project properties
    #BYPASS_PROPERTY_CACHE  = "Deny"  # Bypass project property cache
    #AGILETOOLS_BACKLOG     = "Deny"  # Agile backlog management.
  }
}

variable "platform_admin_area_permissions" {
  type = map(string)
  default = {
    GENERIC_READ           = "Allow" # View permissions for this node
    GENERIC_WRITE          = "Allow" # Edit this node
    CREATE_CHILDREN        = "Allow" # Create child nodes
    DELETE                 = "Allow" # Delete this node
    WORK_ITEM_READ         = "Allow" # View work items in this node
    WORK_ITEM_WRITE        = "Allow" # Edit work items in this node
    MANAGE_TEST_PLANS      = "Allow" # Manage test plans
    MANAGE_TEST_SUITES     = "Allow" # Manage test suites
    WORK_ITEM_SAVE_COMMENT = "Allow" # Edit work item comments in this node 
  }
}

variable "platform_admin_build_permissions" {
  type = map(string)
  default = {
    ViewBuilds                     = "Allow" # View builds
    EditBuildQuality               = "Allow" # Edit build quality
    RetainIndefinitely             = "Allow" # Retain indefinitely
    DeleteBuilds                   = "Allow" # Delete builds
    ManageBuildQualities           = "Allow" # Manage build qualities
    DestroyBuilds                  = "Allow" # Destroy builds
    UpdateBuildInformation         = "Allow" # Update build information
    QueueBuilds                    = "Allow" # Queue builds
    ManageBuildQueue               = "Allow" # Manage build queue
    StopBuilds                     = "Allow" # Stop builds
    ViewBuildDefinition            = "Allow" # View build pipeline
    EditBuildDefinition            = "Allow" # Edit build pipeline
    DeleteBuildDefinition          = "Allow" # Delete build pipeline
    OverrideBuildCheckInValidation = "Allow" # Override check-in validation by build
    AdministerBuildPermissions     = "Allow" # Administer build permissions
    CreateBuildDefinition          = "Allow" # Create build pipeline
  }
}

variable "platform_admin_git_permissions" {
  type = map(string)
  default = {
    Administer              = "Allow" # Administer
    GenericRead             = "Allow" # Read
    GenericContribute       = "Allow" # Contribute
    ForcePush               = "Allow" # Force push (rewrite history, delete branches and tags)
    CreateBranch            = "Allow" # Create branch
    CreateTag               = "Allow" # Create tag
    ManageNote              = "Allow" # Manage notes
    PolicyExempt            = "Deny"  # Bypass policies when pushing
    CreateRepository        = "Allow" # Create repository
    DeleteRepository        = "Deny"  # Delete repository
    RenameRepository        = "Allow" # Rename repository
    EditPolicies            = "Allow" # Edit policies
    RemoveOthersLocks       = "Allow" # Remove others' locks
    ManagePermissions       = "Allow" # Manage permissions
    PullRequestContribute   = "Allow" # Contribute to pull requests
    PullRequestBypassPolicy = "Deny"  # Bypass policies when completing pull requests
  }
}

variable "platform_admin_iteration_permissions" {
  type = map(string)
  default = {
    GENERIC_READ    = "Allow" # View permissions for this node
    GENERIC_WRITE   = "Allow" # Edit this node
    CREATE_CHILDREN = "Allow" # Create child nodes
    DELETE          = "Allow" # Delete this node
  }
}

variable "platform_admin_library_permissions" {
  type = map(string)
  default = {
    View        = "Allow" # View
    Create      = "Allow" # View, Create
    Use         = "Allow" # View, Use
    Administer  = "Allow" # View, Use, Administer
    ViewSecrets = "Allow" # View secrets
    Owner       = "Allow" # View, Use, Administer, Owner
  }
}

variable "platform_admin_tagging_permissions" {
  type = map(string)
  default = {
    Enumerate = "Allow" # Enumerate tag definitions
    Create    = "Allow" # Create tag definition
    Update    = "Allow" # Update tag definition
    Delete    = "Allow" # Delete tag definition
  }
}

variable "platform_admin_shared_query_permissions" {
  type = map(string)
  default = {
    Read              = "Allow" # Read
    Delete            = "Allow" # Delete
    Contribute        = "Allow" # Contribute
    ManagePermissions = "Allow" # Manage Permissions
  }
}

####################### Lead Engineer Group Permissions ###################

variable "lead_engineer_project_permissions" {
  type = map(string)
  default = {
    GENERIC_READ                 = "Allow" # View project-level information
    GENERIC_WRITE                = "Deny"  # Edit project-level information
    DELETE                       = "Deny"  # Delete
    PUBLISH_TEST_RESULTS         = "Allow" # Create test runs
    ADMINISTER_BUILD             = "Allow" # Administer a build
    START_BUILD                  = "Allow" # Start a build
    EDIT_BUILD_STATUS            = "Allow" # Edit build quality
    UPDATE_BUILD                 = "Allow" # Write to build operational store
    DELETE_TEST_RESULTS          = "Deny"  # Delete test runs
    VIEW_TEST_RESULTS            = "Allow" # View test runs
    MANAGE_TEST_ENVIRONMENTS     = "Allow" # Manage test environments
    MANAGE_TEST_CONFIGURATIONS   = "Allow" # Manage test configurations
    WORK_ITEM_DELETE             = "Allow" # Delete and restore work items
    WORK_ITEM_MOVE               = "Allow" # Move work items out of this project
    WORK_ITEM_PERMANENTLY_DELETE = "Deny"  # Permanently delete work items
    RENAME                       = "Deny"  # Rename team project
    MANAGE_PROPERTIES            = "Allow" # Manage project properties
    BYPASS_RULES                 = "Deny"  # Bypass rules on work item updates
    SUPPRESS_NOTIFICATIONS       = "Allow" # Suppress notifications for work item updates
    UPDATE_VISIBILITY            = "Allow" # Update project visibility
    CHANGE_PROCESS               = "Deny"  # Change process of team project.
    AGILETOOLS_PLANS             = "Allow" # Agile plans.

    #TODO: Find analytics permissions settings

    # Using the properties below will result in an error
    # Error: VS403284: Invalid operation. Unable to set bits '17563648' in security namespace '52d39943-cb85-4d7f-8fa8-c6baac873819' as it is reserved by the system.
    #MANAGE_SYSTEM_PROPERTIES     = "Allow" # Manage system project properties
    #BYPASS_PROPERTY_CACHE  = "Deny"  # Bypass project property cache
    #AGILETOOLS_BACKLOG     = "Deny"  # Agile backlog management.
  }
}

variable "lead_engineer_area_permissions" {
  type = map(string)
  default = {
    GENERIC_READ           = "Allow" # View permissions for this node
    GENERIC_WRITE          = "Allow" # Edit this node
    CREATE_CHILDREN        = "Allow" # Create child nodes
    DELETE                 = "Allow" # Delete this node
    WORK_ITEM_READ         = "Allow" # View work items in this node
    WORK_ITEM_WRITE        = "Allow" # Edit work items in this node
    MANAGE_TEST_PLANS      = "Allow" # Manage test plans
    MANAGE_TEST_SUITES     = "Allow" # Manage test suites
    WORK_ITEM_SAVE_COMMENT = "Allow" # Edit work item comments in this node 
  }
}

variable "lead_engineer_build_permissions" {
  type = map(string)
  default = {
    ViewBuilds                     = "Allow" # View builds
    EditBuildQuality               = "Allow" # Edit build quality
    RetainIndefinitely             = "Allow" # Retain indefinitely
    DeleteBuilds                   = "Allow" # Delete builds
    ManageBuildQualities           = "Allow" # Manage build qualities
    DestroyBuilds                  = "Allow" # Destroy builds
    UpdateBuildInformation         = "Allow" # Update build information
    QueueBuilds                    = "Allow" # Queue builds
    ManageBuildQueue               = "Allow" # Manage build queue
    StopBuilds                     = "Allow" # Stop builds
    ViewBuildDefinition            = "Allow" # View build pipeline
    EditBuildDefinition            = "Allow" # Edit build pipeline
    DeleteBuildDefinition          = "Allow" # Delete build pipeline
    OverrideBuildCheckInValidation = "Allow" # Override check-in validation by build
    AdministerBuildPermissions     = "Allow" # Administer build permissions
    CreateBuildDefinition          = "Allow" # Create build pipeline
  }
}

variable "lead_engineer_git_permissions" {
  type = map(string)
  default = {
    Administer              = "Deny"  # Administer
    GenericRead             = "Allow" # Read
    GenericContribute       = "Allow" # Contribute
    ForcePush               = "Deny"  # Force push (rewrite history, delete branches and tags)
    CreateBranch            = "Allow" # Create branch
    CreateTag               = "Allow" # Create tag
    ManageNote              = "Allow" # Manage notes
    PolicyExempt            = "Deny"  # Bypass policies when pushing
    CreateRepository        = "Allow" # Create repository
    DeleteRepository        = "Deny"  # Delete repository
    RenameRepository        = "Allow" # Rename repository
    EditPolicies            = "Allow" # Edit policies
    RemoveOthersLocks       = "Allow" # Remove others' locks
    ManagePermissions       = "Allow" # Manage permissions
    PullRequestContribute   = "Allow" # Contribute to pull requests
    PullRequestBypassPolicy = "Deny"  # Bypass policies when completing pull requests
  }
}

variable "lead_engineer_iteration_permissions" {
  type = map(string)
  default = {
    GENERIC_READ    = "Allow" # View permissions for this node
    GENERIC_WRITE   = "Allow" # Edit this node
    CREATE_CHILDREN = "Allow" # Create child nodes
    DELETE          = "Deny"  # Delete this node
  }
}

variable "lead_engineer_library_permissions" {
  type = map(string)
  default = {
    View        = "Allow" # View
    Create      = "Allow" # View, Create
    Use         = "Allow" # View, Use
    Administer  = "Allow" # View, Use, Administer
    ViewSecrets = "Allow" # View secrets
    Owner       = "Allow" # View, Use, Administer, Owner
  }
}

variable "lead_engineer_tagging_permissions" {
  type = map(string)
  default = {
    Enumerate = "Allow" # Enumerate tag definitions
    Create    = "Allow" # Create tag definition
    Update    = "Allow" # Update tag definition
    Delete    = "Allow" # Delete tag definition
  }
}

variable "lead_engineer_shared_query_permissions" {
  type = map(string)
  default = {
    Read              = "Allow" # Read
    Delete            = "Allow" # Delete
    Contribute        = "Allow" # Contribute
    ManagePermissions = "Allow" # Manage Permissions
  }
}

####################### Engineer Group Permissions #######################

variable "engineer_project_permissions" {
  type = map(string)
  default = {
    GENERIC_READ                 = "Allow" # View project-level information
    GENERIC_WRITE                = "Deny"  # Edit project-level information
    DELETE                       = "Deny"  # Delete
    PUBLISH_TEST_RESULTS         = "Allow" # Create test runs
    ADMINISTER_BUILD             = "Allow" # Administer a build
    START_BUILD                  = "Allow" # Start a build
    EDIT_BUILD_STATUS            = "Allow" # Edit build quality
    UPDATE_BUILD                 = "Allow" # Write to build operational store
    DELETE_TEST_RESULTS          = "Deny"  # Delete test runs
    VIEW_TEST_RESULTS            = "Allow" # View test runs
    MANAGE_TEST_ENVIRONMENTS     = "Allow" # Manage test environments
    MANAGE_TEST_CONFIGURATIONS   = "Allow" # Manage test configurations
    WORK_ITEM_DELETE             = "Allow" # Delete and restore work items
    WORK_ITEM_MOVE               = "Allow" # Move work items out of this project
    WORK_ITEM_PERMANENTLY_DELETE = "Deny"  # Permanently delete work items
    RENAME                       = "Deny"  # Rename team project
    MANAGE_PROPERTIES            = "Allow" # Manage project properties
    BYPASS_RULES                 = "Deny"  # Bypass rules on work item updates
    SUPPRESS_NOTIFICATIONS       = "Allow" # Suppress notifications for work item updates
    UPDATE_VISIBILITY            = "Allow" # Update project visibility
    CHANGE_PROCESS               = "Deny"  # Change process of team project.
    AGILETOOLS_PLANS             = "Allow" # Agile plans.

    #TODO: Find analytics permissions settings

    # Using the properties below will result in an error
    # Error: VS403284: Invalid operation. Unable to set bits '17563648' in security namespace '52d39943-cb85-4d7f-8fa8-c6baac873819' as it is reserved by the system.
    #MANAGE_SYSTEM_PROPERTIES     = "Allow" # Manage system project properties
    #BYPASS_PROPERTY_CACHE  = "Deny"  # Bypass project property cache
    #AGILETOOLS_BACKLOG     = "Deny"  # Agile backlog management.
  }
}

variable "engineer_area_permissions" {
  type = map(string)
  default = {
    GENERIC_READ           = "Allow" # View permissions for this node
    GENERIC_WRITE          = "Allow" # Edit this node
    CREATE_CHILDREN        = "Deny"  # Create child nodes
    DELETE                 = "Deny"  # Delete this node
    WORK_ITEM_READ         = "Allow" # View work items in this node
    WORK_ITEM_WRITE        = "Allow" # Edit work items in this node
    MANAGE_TEST_PLANS      = "Allow" # Manage test plans
    MANAGE_TEST_SUITES     = "Allow" # Manage test suites
    WORK_ITEM_SAVE_COMMENT = "Allow" # Edit work item comments in this node 
  }
}

variable "engineer_build_permissions" {
  type = map(string)
  default = {
    ViewBuilds                     = "Allow" # View builds
    EditBuildQuality               = "Allow" # Edit build quality
    RetainIndefinitely             = "Allow" # Retain indefinitely
    DeleteBuilds                   = "Deny"  # Delete builds
    ManageBuildQualities           = "Allow" # Manage build qualities
    DestroyBuilds                  = "Allow" # Destroy builds
    UpdateBuildInformation         = "Allow" # Update build information
    QueueBuilds                    = "Allow" # Queue builds
    ManageBuildQueue               = "Allow" # Manage build queue
    StopBuilds                     = "Allow" # Stop builds
    ViewBuildDefinition            = "Allow" # View build pipeline
    EditBuildDefinition            = "Allow" # Edit build pipeline
    DeleteBuildDefinition          = "Deny"  # Delete build pipeline
    OverrideBuildCheckInValidation = "Deny"  # Override check-in validation by build
    AdministerBuildPermissions     = "Deny"  # Administer build permissions
    CreateBuildDefinition          = "Allow" # Create build pipeline
  }
}

variable "engineer_git_permissions" {
  type = map(string)
  default = {
    Administer              = "Deny"  # Administer
    GenericRead             = "Allow" # Read
    GenericContribute       = "Allow" # Contribute
    ForcePush               = "Deny"  # Force push (rewrite history, delete branches and tags)
    CreateBranch            = "Allow" # Create branch
    CreateTag               = "Allow" # Create tag
    ManageNote              = "Allow" # Manage notes
    PolicyExempt            = "Deny"  # Bypass policies when pushing
    CreateRepository        = "Deny"  # Create repository
    DeleteRepository        = "Deny"  # Delete repository
    RenameRepository        = "Deny"  # Rename repository
    EditPolicies            = "Deny"  # Edit policies
    RemoveOthersLocks       = "Deny"  # Remove others' locks
    ManagePermissions       = "Deny"  # Manage permissions
    PullRequestContribute   = "Allow" # Contribute to pull requests
    PullRequestBypassPolicy = "Deny"  # Bypass policies when completing pull requests
  }
}

variable "engineer_iteration_permissions" {
  type = map(string)
  default = {
    GENERIC_READ    = "Allow" # View permissions for this node
    GENERIC_WRITE   = "Allow" # Edit this node
    CREATE_CHILDREN = "Deny"  # Create child nodes
    DELETE          = "Deny"  # Delete this node
  }
}

variable "engineer_library_permissions" {
  type = map(string)
  default = {
    View        = "Allow" # View
    Create      = "Allow" # View, Create
    Use         = "Allow" # View, Use
    Administer  = "Deny"  # View, Use, Administer
    ViewSecrets = "Allow" # View secrets
    Owner       = "Deny"  # View, Use, Administer, Owner
  }
}

variable "engineer_tagging_permissions" {
  type = map(string)
  default = {
    Enumerate = "Allow" # Enumerate tag definitions
    Create    = "Allow" # Create tag definition
    Update    = "Allow" # Update tag definition
    Delete    = "Allow" # Delete tag definition
  }
}

variable "engineer_shared_query_permissions" {
  type = map(string)
  default = {
    Read              = "Allow" # Read
    Delete            = "Allow" # Delete
    Contribute        = "Allow" # Contribute
    ManagePermissions = "Deny"  # Manage Permissions
  }
}

####################### Lead Tester Group Permissions ####################

variable "lead_tester_project_permissions" {
  type = map(string)
  default = {
    GENERIC_READ                 = "Allow" # View project-level information
    GENERIC_WRITE                = "Deny"  # Edit project-level information
    DELETE                       = "Deny"  # Delete
    PUBLISH_TEST_RESULTS         = "Allow" # Create test runs
    ADMINISTER_BUILD             = "Deny"  # Administer a build
    START_BUILD                  = "Deny"  # Start a build
    EDIT_BUILD_STATUS            = "Deny"  # Edit build quality
    UPDATE_BUILD                 = "Deny"  # Write to build operational store
    DELETE_TEST_RESULTS          = "Allow" # Delete test runs
    VIEW_TEST_RESULTS            = "Allow" # View test runs
    MANAGE_TEST_ENVIRONMENTS     = "Allow" # Manage test environments
    MANAGE_TEST_CONFIGURATIONS   = "Allow" # Manage test configurations
    WORK_ITEM_DELETE             = "Allow" # Delete and restore work items
    WORK_ITEM_MOVE               = "Allow" # Move work items out of this project
    WORK_ITEM_PERMANENTLY_DELETE = "Deny"  # Permanently delete work items
    RENAME                       = "Deny"  # Rename team project
    MANAGE_PROPERTIES            = "Allow" # Manage project properties
    BYPASS_RULES                 = "Deny"  # Bypass rules on work item updates
    SUPPRESS_NOTIFICATIONS       = "Allow" # Suppress notifications for work item updates
    UPDATE_VISIBILITY            = "Allow" # Update project visibility
    CHANGE_PROCESS               = "Deny"  # Change process of team project.
    AGILETOOLS_PLANS             = "Allow" # Agile plans.

    #TODO: Find analytics permissions settings

    # Using the properties below will result in an error
    # Error: VS403284: Invalid operation. Unable to set bits '17563648' in security namespace '52d39943-cb85-4d7f-8fa8-c6baac873819' as it is reserved by the system.
    #MANAGE_SYSTEM_PROPERTIES     = "Allow" # Manage system project properties
    #BYPASS_PROPERTY_CACHE  = "Deny"  # Bypass project property cache
    #AGILETOOLS_BACKLOG     = "Deny"  # Agile backlog management.
  }
}

variable "lead_tester_area_permissions" {
  type = map(string)
  default = {
    GENERIC_READ           = "Allow" # View permissions for this node
    GENERIC_WRITE          = "Allow" # Edit this node
    CREATE_CHILDREN        = "Deny"  # Create child nodes
    DELETE                 = "Deny"  # Delete this node
    WORK_ITEM_READ         = "Allow" # View work items in this node
    WORK_ITEM_WRITE        = "Allow" # Edit work items in this node
    MANAGE_TEST_PLANS      = "Allow" # Manage test plans
    MANAGE_TEST_SUITES     = "Allow" # Manage test suites
    WORK_ITEM_SAVE_COMMENT = "Allow" # Edit work item comments in this node 
  }
}

variable "lead_tester_build_permissions" {
  type = map(string)
  default = {
    ViewBuilds                     = "Allow" # View builds
    EditBuildQuality               = "Deny"  # Edit build quality
    RetainIndefinitely             = "Deny"  # Retain indefinitely
    DeleteBuilds                   = "Deny"  # Delete builds
    ManageBuildQualities           = "Deny"  # Manage build qualities
    DestroyBuilds                  = "Deny"  # Destroy builds
    UpdateBuildInformation         = "Deny"  # Update build information
    QueueBuilds                    = "Deny"  # Queue builds
    ManageBuildQueue               = "Deny"  # Manage build queue
    StopBuilds                     = "Deny"  # Stop builds
    ViewBuildDefinition            = "Allow" # View build pipeline
    EditBuildDefinition            = "Deny"  # Edit build pipeline
    DeleteBuildDefinition          = "Deny"  # Delete build pipeline
    OverrideBuildCheckInValidation = "Deny"  # Override check-in validation by build
    AdministerBuildPermissions     = "Deny"  # Administer build permissions
    CreateBuildDefinition          = "Deny"  # Create build pipeline
  }
}

variable "lead_tester_git_permissions" {
  type = map(string)
  default = {
    Administer              = "Deny"  # Administer
    GenericRead             = "Allow" # Read
    GenericContribute       = "Allow" # Contribute
    ForcePush               = "Deny"  # Force push (rewrite history, delete branches and tags)
    CreateBranch            = "Allow" # Create branch
    CreateTag               = "Allow" # Create tag
    ManageNote              = "Allow" # Manage notes
    PolicyExempt            = "Deny"  # Bypass policies when pushing
    CreateRepository        = "Deny"  # Create repository
    DeleteRepository        = "Deny"  # Delete repository
    RenameRepository        = "Deny"  # Rename repository
    EditPolicies            = "Deny"  # Edit policies
    RemoveOthersLocks       = "Deny"  # Remove others' locks
    ManagePermissions       = "Deny"  # Manage permissions
    PullRequestContribute   = "Allow" # Contribute to pull requests
    PullRequestBypassPolicy = "Deny"  # Bypass policies when completing pull requests
  }
}

variable "lead_tester_iteration_permissions" {
  type = map(string)
  default = {
    GENERIC_READ    = "Allow" # View permissions for this node
    GENERIC_WRITE   = "Allow" # Edit this node
    CREATE_CHILDREN = "Allow" # Create child nodes
    DELETE          = "Deny"  # Delete this node
  }
}

variable "lead_tester_library_permissions" {
  type = map(string)
  default = {
    View        = "Allow" # View
    Create      = "Deny"  # View, Create
    Use         = "Allow" # View, Use
    Administer  = "Deny"  # View, Use, Administer
    ViewSecrets = "Allow" # View secrets
    Owner       = "Deny"  # View, Use, Administer, Owner
  }
}

variable "lead_tester_tagging_permissions" {
  type = map(string)
  default = {
    Enumerate = "Allow" # Enumerate tag definitions
    Create    = "Allow" # Create tag definition
    Update    = "Allow" # Update tag definition
    Delete    = "Deny"  # Delete tag definition
  }
}

variable "lead_tester_shared_query_permissions" {
  type = map(string)
  default = {
    Read              = "Allow" # Read
    Delete            = "Deny"  # Delete
    Contribute        = "Allow" # Contribute
    ManagePermissions = "Deny"  # Manage Permissions
  }
}

####################### Tester Group Permissions #########################

variable "tester_project_permissions" {
  type = map(string)
  default = {
    GENERIC_READ                 = "Allow" # View project-level information
    GENERIC_WRITE                = "Deny"  # Edit project-level information
    DELETE                       = "Deny"  # Delete
    PUBLISH_TEST_RESULTS         = "Allow" # Create test runs
    ADMINISTER_BUILD             = "Deny"  # Administer a build
    START_BUILD                  = "Deny"  # Start a build
    EDIT_BUILD_STATUS            = "Deny"  # Edit build quality
    UPDATE_BUILD                 = "Deny"  # Write to build operational store
    DELETE_TEST_RESULTS          = "Allow" # Delete test runs
    VIEW_TEST_RESULTS            = "Allow" # View test runs
    MANAGE_TEST_ENVIRONMENTS     = "Allow" # Manage test environments
    MANAGE_TEST_CONFIGURATIONS   = "Allow" # Manage test configurations
    WORK_ITEM_DELETE             = "Allow" # Delete and restore work items
    WORK_ITEM_MOVE               = "Allow" # Move work items out of this project
    WORK_ITEM_PERMANENTLY_DELETE = "Deny"  # Permanently delete work items
    RENAME                       = "Deny"  # Rename team project
    MANAGE_PROPERTIES            = "Allow" # Manage project properties
    BYPASS_RULES                 = "Deny"  # Bypass rules on work item updates
    SUPPRESS_NOTIFICATIONS       = "Allow" # Suppress notifications for work item updates
    UPDATE_VISIBILITY            = "Allow" # Update project visibility
    CHANGE_PROCESS               = "Deny"  # Change process of team project.
    AGILETOOLS_PLANS             = "Allow" # Agile plans.

    #TODO: Find analytics permissions settings

    # Using the properties below will result in an error
    # Error: VS403284: Invalid operation. Unable to set bits '17563648' in security namespace '52d39943-cb85-4d7f-8fa8-c6baac873819' as it is reserved by the system.
    #MANAGE_SYSTEM_PROPERTIES     = "Allow" # Manage system project properties
    #BYPASS_PROPERTY_CACHE  = "Deny"  # Bypass project property cache
    #AGILETOOLS_BACKLOG     = "Deny"  # Agile backlog management.
  }
}

variable "tester_area_permissions" {
  type = map(string)
  default = {
    GENERIC_READ           = "Allow" # View permissions for this node
    GENERIC_WRITE          = "Allow" # Edit this node
    CREATE_CHILDREN        = "Deny"  # Create child nodes
    DELETE                 = "Deny"  # Delete this node
    WORK_ITEM_READ         = "Allow" # View work items in this node
    WORK_ITEM_WRITE        = "Allow" # Edit work items in this node
    MANAGE_TEST_PLANS      = "Allow" # Manage test plans
    MANAGE_TEST_SUITES     = "Allow" # Manage test suites
    WORK_ITEM_SAVE_COMMENT = "Allow" # Edit work item comments in this node 
  }
}

variable "tester_build_permissions" {
  type = map(string)
  default = {
    ViewBuilds                     = "Allow" # View builds
    EditBuildQuality               = "Deny"  # Edit build quality
    RetainIndefinitely             = "Deny"  # Retain indefinitely
    DeleteBuilds                   = "Deny"  # Delete builds
    ManageBuildQualities           = "Deny"  # Manage build qualities
    DestroyBuilds                  = "Deny"  # Destroy builds
    UpdateBuildInformation         = "Deny"  # Update build information
    QueueBuilds                    = "Deny"  # Queue builds
    ManageBuildQueue               = "Deny"  # Manage build queue
    StopBuilds                     = "Deny"  # Stop builds
    ViewBuildDefinition            = "Allow" # View build pipeline
    EditBuildDefinition            = "Deny"  # Edit build pipeline
    DeleteBuildDefinition          = "Deny"  # Delete build pipeline
    OverrideBuildCheckInValidation = "Deny"  # Override check-in validation by build
    AdministerBuildPermissions     = "Deny"  # Administer build permissions
    CreateBuildDefinition          = "Deny"  # Create build pipeline
  }
}

variable "tester_git_permissions" {
  type = map(string)
  default = {
    Administer              = "Deny"  # Administer
    GenericRead             = "Allow" # Read
    GenericContribute       = "Allow" # Contribute
    ForcePush               = "Deny"  # Force push (rewrite history, delete branches and tags)
    CreateBranch            = "Allow" # Create branch
    CreateTag               = "Allow" # Create tag
    ManageNote              = "Allow" # Manage notes
    PolicyExempt            = "Deny"  # Bypass policies when pushing
    CreateRepository        = "Deny"  # Create repository
    DeleteRepository        = "Deny"  # Delete repository
    RenameRepository        = "Deny"  # Rename repository
    EditPolicies            = "Deny"  # Edit policies
    RemoveOthersLocks       = "Deny"  # Remove others' locks
    ManagePermissions       = "Deny"  # Manage permissions
    PullRequestContribute   = "Allow" # Contribute to pull requests
    PullRequestBypassPolicy = "Deny"  # Bypass policies when completing pull requests
  }
}

variable "tester_iteration_permissions" {
  type = map(string)
  default = {
    GENERIC_READ    = "Allow" # View permissions for this node
    GENERIC_WRITE   = "Allow" # Edit this node
    CREATE_CHILDREN = "Deny"  # Create child nodes
    DELETE          = "Deny"  # Delete this node
  }
}

variable "tester_library_permissions" {
  type = map(string)
  default = {
    View        = "Allow" # View
    Create      = "Deny"  # View, Create
    Use         = "Allow" # View, Use
    Administer  = "Deny"  # View, Use, Administer
    ViewSecrets = "Allow" # View secrets
    Owner       = "Deny"  # View, Use, Administer, Owner
  }
}

variable "tester_tagging_permissions" {
  type = map(string)
  default = {
    Enumerate = "Allow" # Enumerate tag definitions
    Create    = "Allow" # Create tag definition
    Update    = "Allow" # Update tag definition
    Delete    = "Deny"  # Delete tag definition
  }
}

variable "tester_shared_query_permissions" {
  type = map(string)
  default = {
    Read              = "Allow" # Read
    Delete            = "Deny"  # Delete
    Contribute        = "Allow" # Contribute
    ManagePermissions = "Deny"  # Manage Permissions
  }
}

####################### Project Manager Group Permissions ################

variable "pm_project_permissions" {
  type = map(string)
  default = {
    GENERIC_READ                 = "Allow" # View project-level information
    GENERIC_WRITE                = "Deny"  # Edit project-level information
    DELETE                       = "Deny"  # Delete
    PUBLISH_TEST_RESULTS         = "Deny"  # Create test runs
    ADMINISTER_BUILD             = "Deny"  # Administer a build
    START_BUILD                  = "Deny"  # Start a build
    EDIT_BUILD_STATUS            = "Deny"  # Edit build quality
    UPDATE_BUILD                 = "Deny"  # Write to build operational store
    DELETE_TEST_RESULTS          = "Deny"  # Delete test runs
    VIEW_TEST_RESULTS            = "Allow" # View test runs
    MANAGE_TEST_ENVIRONMENTS     = "Deny"  # Manage test environments
    MANAGE_TEST_CONFIGURATIONS   = "Deny"  # Manage test configurations
    WORK_ITEM_DELETE             = "Allow" # Delete and restore work items
    WORK_ITEM_MOVE               = "Allow" # Move work items out of this project
    WORK_ITEM_PERMANENTLY_DELETE = "Deny"  # Permanently delete work items
    RENAME                       = "Deny"  # Rename team project
    MANAGE_PROPERTIES            = "Deny"  # Manage project properties
    BYPASS_RULES                 = "Deny"  # Bypass rules on work item updates
    SUPPRESS_NOTIFICATIONS       = "Allow" # Suppress notifications for work item updates
    UPDATE_VISIBILITY            = "Allow" # Update project visibility
    CHANGE_PROCESS               = "Deny"  # Change process of team project.
    AGILETOOLS_PLANS             = "Allow" # Agile plans.

    #TODO: Find analytics permissions settings

    # Using the properties below will result in an error
    # Error: VS403284: Invalid operation. Unable to set bits '17563648' in security namespace '52d39943-cb85-4d7f-8fa8-c6baac873819' as it is reserved by the system.
    #MANAGE_SYSTEM_PROPERTIES     = "Allow" # Manage system project properties
    #BYPASS_PROPERTY_CACHE  = "Deny"  # Bypass project property cache
    #AGILETOOLS_BACKLOG     = "Deny"  # Agile backlog management.
  }
}

variable "pm_area_permissions" {
  type = map(string)
  default = {
    GENERIC_READ           = "Allow" # View permissions for this node
    GENERIC_WRITE          = "Allow" # Edit this node
    CREATE_CHILDREN        = "Allow" # Create child nodes
    DELETE                 = "Allow" # Delete this node
    WORK_ITEM_READ         = "Allow" # View work items in this node
    WORK_ITEM_WRITE        = "Allow" # Edit work items in this node
    MANAGE_TEST_PLANS      = "Deny"  # Manage test plans
    MANAGE_TEST_SUITES     = "Deny"  # Manage test suites
    WORK_ITEM_SAVE_COMMENT = "Allow" # Edit work item comments in this node 
  }
}

variable "pm_build_permissions" {
  type = map(string)
  default = {
    ViewBuilds                     = "Allow" # View builds
    EditBuildQuality               = "Deny"  # Edit build quality
    RetainIndefinitely             = "Deny"  # Retain indefinitely
    DeleteBuilds                   = "Deny"  # Delete builds
    ManageBuildQualities           = "Deny"  # Manage build qualities
    DestroyBuilds                  = "Deny"  # Destroy builds
    UpdateBuildInformation         = "Deny"  # Update build information
    QueueBuilds                    = "Deny"  # Queue builds
    ManageBuildQueue               = "Deny"  # Manage build queue
    StopBuilds                     = "Deny"  # Stop builds
    ViewBuildDefinition            = "Allow" # View build pipeline
    EditBuildDefinition            = "Deny"  # Edit build pipeline
    DeleteBuildDefinition          = "Deny"  # Delete build pipeline
    OverrideBuildCheckInValidation = "Deny"  # Override check-in validation by build
    AdministerBuildPermissions     = "Deny"  # Administer build permissions
    CreateBuildDefinition          = "Deny"  # Create build pipeline
  }
}

variable "pm_git_permissions" {
  type = map(string)
  default = {
    Administer              = "Deny"  # Administer
    GenericRead             = "Allow" # Read
    GenericContribute       = "Deny"  # Contribute
    ForcePush               = "Deny"  # Force push (rewrite history, delete branches and tags)
    CreateBranch            = "Deny"  # Create branch
    CreateTag               = "Deny"  # Create tag
    ManageNote              = "Deny"  # Manage notes
    PolicyExempt            = "Deny"  # Bypass policies when pushing
    CreateRepository        = "Deny"  # Create repository
    DeleteRepository        = "Deny"  # Delete repository
    RenameRepository        = "Deny"  # Rename repository
    EditPolicies            = "Deny"  # Edit policies
    RemoveOthersLocks       = "Deny"  # Remove others' locks
    ManagePermissions       = "Deny"  # Manage permissions
    PullRequestContribute   = "Deny"  # Contribute to pull requests
    PullRequestBypassPolicy = "Deny"  # Bypass policies when completing pull requests
  }
}

variable "pm_iteration_permissions" {
  type = map(string)
  default = {
    GENERIC_READ    = "Allow" # View permissions for this node
    GENERIC_WRITE   = "Allow" # Edit this node
    CREATE_CHILDREN = "Allow" # Create child nodes
    DELETE          = "Allow" # Delete this node
  }
}

variable "pm_library_permissions" {
  type = map(string)
  default = {
    View        = "Allow" # View
    Create      = "Deny"  # View, Create
    Use         = "Allow" # View, Use
    Administer  = "Deny"  # View, Use, Administer
    ViewSecrets = "Deny"  # View secrets
    Owner       = "Deny"  # View, Use, Administer, Owner
  }
}

variable "pm_tagging_permissions" {
  type = map(string)
  default = {
    Enumerate = "Allow" # Enumerate tag definitions
    Create    = "Allow" # Create tag definition
    Update    = "Allow" # Update tag definition
    Delete    = "Allow" # Delete tag definition
  }
}

variable "pm_shared_query_permissions" {
  type = map(string)
  default = {
    Read              = "Allow" # Read
    Delete            = "Allow" # Delete
    Contribute        = "Allow" # Contribute
    ManagePermissions = "Deny"  # Manage Permissions
  }
}

####################### GitHub Team Repository Roles ###################
# GitHub equivalent of the ADO group permission maps above.
# Values: pull, triage, push, maintain, admin, or the name of an organisation custom repository role.

variable "github_team_repository_roles" {
  type = map(string)
  default = {
    platformAdmin = "admin"    # Full control, including settings and rulesets
    leadEngineer  = "maintain" # Manage the repository without access to sensitive or destructive actions
    engineer      = "push"     # Push branches, open and merge pull requests (subject to rulesets)
    pm            = "triage"   # Manage issues and pull requests, no code write
    leadTester    = "triage"   # Manage issues and pull requests, no code write
    tester        = "pull"     # Read and clone
  }

  validation {
    condition     = alltrue([for k in ["platformAdmin", "leadEngineer", "engineer", "pm", "leadTester", "tester"] : contains(keys(var.github_team_repository_roles), k)])
    error_message = "github_team_repository_roles must define platformAdmin, leadEngineer, engineer, pm, leadTester and tester."
  }
}

####################### Shared CI/CD repository (set by ign bootstrap) ###################

variable "cicd_repo_files_dir" {
  type        = string
  default     = ""
  description = "Directory holding the rendered shared CI/CD repository files. Set by ign bootstrap (TF_VAR_cicd_repo_files_dir)."
}

variable "app_repo_files_dir" {
  type        = string
  default     = ""
  description = "Directory holding the starter files (e.g. .devcontainer/) committed to a newly created infrastructure repository. Set by ign bootstrap (TF_VAR_app_repo_files_dir)."
}

variable "python_executable" {
  type        = string
  default     = "python3"
  description = "Python interpreter used to upload binary starter files (the Ignition CLI wheel). Set by ign bootstrap (TF_VAR_python_executable)."
}

variable "cicd_repo_exists" {
  type        = bool
  default     = false
  description = "Whether the shared CI/CD repository already exists in the organisation. Set by ign bootstrap (TF_VAR_cicd_repo_exists)."
}
