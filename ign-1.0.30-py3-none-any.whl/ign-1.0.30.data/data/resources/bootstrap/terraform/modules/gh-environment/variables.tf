variable "repository" {
  type        = string
  description = "Repository name (without the organisation)."
}

variable "environment_name" {
  type        = string
  description = "GitHub environment name, e.g. dev or dev/apply."
}

variable "environment_variables" {
  type        = map(string)
  default     = {}
  description = "Environment variables to create (name => value)."
}

# ----- Azure OIDC -----
variable "umi_resource_id" {
  type        = string
  description = "Resource ID of the user-assigned managed identity trusted by this environment."
}

variable "federated_credential_name" {
  type = string
}

variable "federated_subject" {
  type        = string
  description = "OIDC subject, e.g. repo:<org>@<orgId>/<repo>@<repoId>:environment:<env> (immutable) or repo:<org>/<repo>:environment:<env> (legacy)."
}

# ----- Approval gate -----
variable "deploy_approval_required" {
  type    = bool
  default = false
}

variable "approvers_team_name" {
  type    = string
  default = null
}

variable "approvers" {
  type        = list(string)
  default     = []
  description = "GitHub usernames added to the approvers team."
}

variable "additional_reviewer_team_ids" {
  type        = list(number)
  default     = []
  description = "Extra team IDs allowed to approve (GitHub allows up to 6 reviewers in total)."
}

variable "prevent_self_review" {
  type    = bool
  default = true
}

variable "can_admins_bypass" {
  type    = bool
  default = false
}

variable "wait_timer" {
  type    = number
  default = 0

  validation {
    condition     = var.wait_timer >= 0 && var.wait_timer <= 43200
    error_message = "wait_timer must be between 0 and 43200 minutes."
  }
}

variable "deployment_branch_patterns" {
  type        = list(string)
  default     = []
  description = "Branch name patterns allowed to run in this environment. Empty = all branches."
}
