"""Commit one file - binary or text - to a GitHub repository branch via the Contents API.

github_repository_file only accepts UTF-8 text, so bootstrap uses this for binary
starter files such as the Ignition CLI wheel in .devcontainer/wheels/.
Standard library only. Run by a terraform_data local-exec in this module.

Environment:
  GITHUB_TOKEN  token with contents:write on the repository (set by ign bootstrap)
  GH_REPO       owner/name
  GH_BRANCH     branch to commit to
  GH_PATH       path of the file in the repository
  GH_SOURCE     local file to upload
  GH_MESSAGE    commit message
  GITHUB_API_URL  optional, default https://api.github.com
"""
import base64
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


def _request(method, url, token, body=None):
    data = json.dumps(body).encode('utf-8') if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        'Authorization': f'Bearer {token}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'ign-bootstrap',
    })
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read() or b'{}')


def main() -> int:
    env = os.environ
    missing = [k for k in ('GITHUB_TOKEN', 'GH_REPO', 'GH_BRANCH', 'GH_PATH', 'GH_SOURCE', 'GH_MESSAGE') if not env.get(k)]
    if missing:
        print(f"github_put_file: missing environment variables: {', '.join(missing)}", file=sys.stderr)
        return 2

    api = env.get('GITHUB_API_URL', 'https://api.github.com').rstrip('/')
    path = urllib.parse.quote(env['GH_PATH'].lstrip('/'))
    url = f"{api}/repos/{env['GH_REPO']}/contents/{path}"
    branch = env['GH_BRANCH']

    with open(env['GH_SOURCE'], 'rb') as fh:
        content = base64.b64encode(fh.read()).decode('ascii')

    body = {'message': env['GH_MESSAGE'], 'content': content, 'branch': branch}

    # Updating an existing file needs its blob sha (makes re-runs idempotent).
    try:
        existing = _request('GET', f"{url}?ref={urllib.parse.quote(branch)}", env['GITHUB_TOKEN'])
        if isinstance(existing, dict) and existing.get('sha'):
            body['sha'] = existing['sha']
    except urllib.error.HTTPError as exc:
        if exc.code != 404:
            print(f"github_put_file: GET {env['GH_PATH']} failed: HTTP {exc.code} {exc.read().decode(errors='replace')}", file=sys.stderr)
            return 1

    try:
        _request('PUT', url, env['GITHUB_TOKEN'], body)
    except urllib.error.HTTPError as exc:
        print(f"github_put_file: PUT {env['GH_PATH']} failed: HTTP {exc.code} {exc.read().decode(errors='replace')}", file=sys.stderr)
        return 1

    print(f"github_put_file: committed {env['GH_PATH']} to {env['GH_REPO']}@{branch}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
