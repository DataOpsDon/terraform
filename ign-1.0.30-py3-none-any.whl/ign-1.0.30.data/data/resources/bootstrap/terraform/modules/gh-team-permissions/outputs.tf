output "team_id" {
  description = "Numeric team ID"
  value       = github_team.this.id
}

output "team_slug" {
  description = "Team slug (used in CODEOWNERS as @org/<slug>)"
  value       = github_team.this.slug
}
