# Data source for current Azure client configuration (for tenant_id)
data "azurerm_client_config" "current" {}

data "azurerm_subscription" "application" {
  provider        = azurerm.application
  subscription_id = local.subscriptionId_Application
}
