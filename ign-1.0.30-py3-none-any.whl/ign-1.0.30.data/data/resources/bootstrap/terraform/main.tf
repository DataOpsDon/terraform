
module "resourcegroup_state" {
  source   = "Azure/avm-res-resources-resourcegroup/azurerm"
  version  = "0.2.1"
  name     = local.rgName_state
  location = local.location
  tags     = merge(local.tags, local.tags_state)
  role_assignments = {
    Owner_Deploy = {
      principal_type             = "ServicePrincipal"
      principal_id               = module.umi_tf_deploy.principal_id
      role_definition_id_or_name = "Owner"
    }
    Reader_Build = {
      principal_type             = "ServicePrincipal"
      principal_id               = module.umi_tf_build.principal_id
      role_definition_id_or_name = "Reader"
    }
    BlobContributor_Build = {
      principal_type             = "ServicePrincipal"
      principal_id               = module.umi_tf_build.principal_id
      role_definition_id_or_name = "Storage Blob Data Contributor"
    }
  }
}

module "storageaccount_state" {
  source                        = "Azure/avm-res-storage-storageaccount/azurerm"
  version                       = "0.7.4"
  parent_id                     = module.resourcegroup_state.resource_id
  name                          = local.saName_state
  location                      = local.location
  tags                          = merge(local.tags, local.tags_state)
  containers                    = local.containers_state
  public_network_access_enabled = local.stateStoragePublic_network_access_enabled == true ? true : false ##This logic says if the variable is true, then enable public network access, otherwise disable it. This is to ensure that if the variable is not set, it defaults to false.  This capture the ability for someone to enter neither true or false and not break the deployment.
  network_rules = {
    default_action = "Allow"
  }
  account_sku_name          = local.stateStorageSku != null ? local.stateStorageSku : "Standard_ZRS"
  shared_access_key_enabled = true
  role_assignments = {
    BlobContributor_Deploy = {
      principal_type             = "ServicePrincipal"
      principal_id               = module.umi_tf_deploy.principal_id
      role_definition_id_or_name = "Storage Blob Data Contributor"
    }
    BlobContributor_Build = {
      principal_type             = "ServicePrincipal"
      principal_id               = module.umi_tf_build.principal_id
      role_definition_id_or_name = "Storage Blob Data Contributor"
    }
  }
}

module "resourcegroup_umi" {
  source   = "Azure/avm-res-resources-resourcegroup/azurerm"
  version  = "0.2.1"
  name     = local.rgName_umi
  location = local.location
  tags     = merge(local.tags, local.tags_umi)
}

module "umi_tf_build" {
  source              = "Azure/avm-res-managedidentity-userassignedidentity/azurerm"
  version             = "0.3.4"
  resource_group_name = module.resourcegroup_umi.name
  name                = local.umiName_build
  location            = local.location
  tags                = merge(local.tags, local.tags_umi)
}

module "umi_tf_deploy" {
  source              = "Azure/avm-res-managedidentity-userassignedidentity/azurerm"
  version             = "0.3.4"
  resource_group_name = module.resourcegroup_umi.name
  name                = local.umiName_deploy
  location            = local.location
  tags                = merge(local.tags, local.tags_umi)
}

# Assign the Deploy UMI as Owner on the Application subscription with a condition
# that prevents it from delegating the Owner, User Access Administrator, or
# Role Based Access Control Administrator roles to others.
resource "azurerm_role_assignment" "deploy_owner_application_subscription" {
  provider             = azurerm.application
  scope                = data.azurerm_subscription.application.id
  role_definition_name = "Owner"
  principal_id         = module.umi_tf_deploy.principal_id

  condition_version = "2.0"
  condition         = <<-EOT
    (
     (
      !(ActionMatches{'Microsoft.Authorization/roleAssignments/write'})
     )
     OR
     (
      @Request[Microsoft.Authorization/roleAssignments:RoleDefinitionId] ForAnyOfAnyValues:GuidNotEquals {8e3af657-a8ff-443c-a75c-2fe8c4bcb635, 18d7d88d-d35e-4fb5-a5c3-7773c20a72d9, f58310d9-a9f6-439a-9e8d-f62e7b41a168}
     )
    )
    AND
    (
     (
      !(ActionMatches{'Microsoft.Authorization/roleAssignments/delete'})
     )
     OR
     (
      @Request[Microsoft.Authorization/roleAssignments:RoleDefinitionId] ForAnyOfAnyValues:GuidNotEquals {8e3af657-a8ff-443c-a75c-2fe8c4bcb635, 18d7d88d-d35e-4fb5-a5c3-7773c20a72d9, f58310d9-a9f6-439a-9e8d-f62e7b41a168}
     )
    )
  EOT
}

# Assign the Deploy UMI as Owner on the Application subscription with a condition
# that prevents it from delegating the Owner, User Access Administrator, or
# Role Based Access Control Administrator roles to others.
resource "azurerm_role_assignment" "build_reader_application_subscription" {
  provider             = azurerm.application
  scope                = data.azurerm_subscription.application.id
  role_definition_name = "Reader"
  principal_id         = module.umi_tf_build.principal_id
}

# =============================================================================
# GitHub Actions (cicdPlatform: github)
# GitHub equivalent of the Azure DevOps resources in ado.tf:
#   ADO project + project settings      -> module.gh_repository   (repo, rulesets, Actions policy, security)
#   ADO project groups + permissions    -> module.gh_teams        (role teams + repository roles)
#   ADO build/deploy service connection -> module.*_github_environment
#       build  identity -> environment "<environmentName_gh>"        (CI + plan jobs)
#       deploy identity -> environment "<environmentName_gh>/apply"  (apply job, approval gate)
# The environment names and OIDC subjects match the shared reusable workflow
# (_terraform-pipeline.yml).
# Repository-level resources run once per repository (isFirstTimeDeployToGH);
# environments run for every environment you bootstrap.
# =============================================================================

module "gh_repository" {
  source = "./modules/gh-repository"
  count  = local.github_first_time ? 1 : 0

  repository_name   = local.repositoryName_gh
  create_repository = local.ghCreateRepository
  description       = local.ghRepositoryDescription
  visibility        = local.ghRepositoryVisibility

  # Only committed when the repository is created here (the module ignores them otherwise).
  initial_files          = local.app_repo_files
  initial_binary_files   = local.app_repo_binary_files
  python_executable      = var.python_executable
  initial_commit_message = "Add dev container (ign bootstrap)"

  allowed_merge_methods       = local.gh_guardrails.allowed_merge_methods
  enable_vulnerability_alerts = local.gh_guardrails.enable_vulnerability_alerts
  enable_secret_scanning      = local.gh_guardrails.enable_secret_scanning

  manage_actions_permissions = local.gh_guardrails.manage_actions_permissions
  allowed_action_patterns    = local.gh_guardrails.allowed_action_patterns
  sha_pinning_required       = local.gh_guardrails.sha_pinning_required

  enable_rulesets            = local.gh_guardrails.enable_rulesets
  protected_branches         = local.gh_guardrails.protected_branches
  required_approvals         = local.gh_guardrails.required_approvals
  require_code_owner_review  = local.gh_guardrails.require_code_owner_review
  require_last_push_approval = local.gh_guardrails.require_last_push_approval
  required_status_checks     = local.gh_guardrails.required_status_checks
  require_signed_commits     = local.gh_guardrails.require_signed_commits
  require_linear_history     = local.gh_guardrails.require_linear_history

  # Platform Admins may bypass the ruleset, but only by merging a pull request (break-glass).
  bypass_team_ids = contains(keys(local.gh_teams), "platformAdmin") ? [tonumber(module.gh_teams["platformAdmin"].team_id)] : []
}

module "gh_teams" {
  source   = "./modules/gh-team-permissions"
  for_each = local.github_first_time ? local.gh_teams : {}

  team_name             = each.value.name
  team_description      = each.value.description
  repository            = local.gh_repository_name
  repository_permission = each.value.permission
  members               = each.value.members
}

# Later runs (isFirstTimeDeployToGH: false): look up the Platform Admin team created by the first run.
data "github_team" "platform_admin" {
  count        = local.github_configured && !local.isFirstTimeDeployToGH && contains(keys(local.gh_teams), "platformAdmin") ? 1 : 0
  slug         = local.gh_teams["platformAdmin"].slug
  summary_only = true
}

# Numeric organisation and repository IDs for the immutable OIDC subject claim.
data "github_organization" "this" {
  count        = local.github_configured ? 1 : 0
  name         = local.orgName_gh
  summary_only = true

  lifecycle {
    precondition {
      condition     = contains(["immutable", "legacy"], local.oidcSubjectFormat_gh)
      error_message = "oidcSubjectFormat_gh must be 'immutable' or 'legacy'."
    }
    postcondition {
      condition     = self.id != null && self.id != ""
      error_message = "GitHub organisation '${local.orgName_gh}' was not found, so its ID cannot be added to the OIDC subject. Check orgName_gh and the token's access."
    }
  }
}

# Later runs: the repository already exists, so read its ID directly.
data "github_repository" "oidc" {
  count     = local.github_configured && !local.isFirstTimeDeployToGH && local.oidcSubjectFormat_gh == "immutable" ? 1 : 0
  full_name = "${local.orgName_gh}/${local.repositoryName_gh}"

  lifecycle {
    postcondition {
      condition     = self.repo_id != null && self.repo_id != 0
      error_message = "GitHub repository '${local.orgName_gh}/${local.repositoryName_gh}' was not found, so its ID cannot be added to the OIDC subject. Check repositoryName_gh / orgName_gh and the token's access."
    }
  }
}

locals {
  gh_repository_name = local.github_first_time ? module.gh_repository[0].repository_name : local.repositoryName_gh

  gh_org_id = local.oidcSubjectFormat_gh == "immutable" && length(data.github_organization.this) > 0 ? data.github_organization.this[0].id : null
  gh_repo_id = local.oidcSubjectFormat_gh != "immutable" ? null : (
    local.github_first_time ? module.gh_repository[0].repo_id :
    length(data.github_repository.oidc) > 0 ? data.github_repository.oidc[0].repo_id : null
  )

  github_subject_repo = (
    local.oidcSubjectFormat_gh == "immutable"
    ? "repo:${coalesce(local.orgName_gh, "unset")}@${coalesce(local.gh_org_id, "unset")}/${local.repositoryName_gh}@${coalesce(local.gh_repo_id, "unset")}"
    : "repo:${coalesce(local.orgName_gh, "unset")}/${local.repositoryName_gh}"
  )
  github_subject_build  = "${local.github_subject_repo}:environment:${local.environmentName_gh}"
  github_subject_deploy = "${local.github_subject_repo}:environment:${local.environmentName_gh}/apply"

  gh_platform_admin_team_ids = (
    local.github_first_time && contains(keys(local.gh_teams), "platformAdmin") ? [tonumber(module.gh_teams["platformAdmin"].team_id)] :
    length(data.github_team.platform_admin) > 0 ? [tonumber(data.github_team.platform_admin[0].id)] : []
  )
}

# Plan / CI environment: build identity (Reader on the application subscription).
module "build_github_environment" {
  source = "./modules/gh-environment"
  count  = local.github_configured ? 1 : 0

  repository       = local.gh_repository_name
  environment_name = local.environmentName_gh
  environment_variables = merge(local.gh_common_variables, {
    AZURE_CLIENT_ID = module.umi_tf_build.client_id
  })

  umi_resource_id           = module.umi_tf_build.resource_id
  federated_credential_name = substr(replace("github-${local.repositoryName_gh}-${local.environmentName_gh}-build", "/[^a-zA-Z0-9_-]/", "-"), 0, 120)
  federated_subject         = local.github_subject_build

  deploy_approval_required = false
}

# Apply environment: deploy identity (conditional Owner) behind required reviewers
# and restricted to the apply branches.
module "deploy_github_environment" {
  source = "./modules/gh-environment"
  count  = local.github_configured ? 1 : 0

  repository       = local.gh_repository_name
  environment_name = "${local.environmentName_gh}/apply"
  environment_variables = merge(local.gh_common_variables, {
    AZURE_CLIENT_ID = module.umi_tf_deploy.client_id
  })

  umi_resource_id           = module.umi_tf_deploy.resource_id
  federated_credential_name = substr(replace("github-${local.repositoryName_gh}-${local.environmentName_gh}-deploy", "/[^a-zA-Z0-9_-]/", "-"), 0, 120)
  federated_subject         = local.github_subject_deploy

  deploy_approval_required     = local.deployApprovalRequired == true
  approvers_team_name          = local.teamName_gh
  approvers                    = local.approvers_gh
  additional_reviewer_team_ids = local.gh_platform_admin_team_ids
  prevent_self_review          = local.preventSelfReviewDeploy_gh == true
  can_admins_bypass            = local.canAdminsBypassDeploy
  wait_timer                   = local.deployWaitTimer_gh
  deployment_branch_patterns   = local.applyBranchPatterns_gh
}

# -----------------------------------------------------------------------------
# Shared CI/CD repository (createCicdRepo_gh)
# Created and populated once per organisation with the reusable workflow and
# composite actions rendered for this organisation by ign bootstrap. The release
# workflow is committed last with "#major" so a single run publishes v1.0.0.
# -----------------------------------------------------------------------------

module "gh_cicd_maintainers" {
  source = "./modules/gh-team-permissions"
  count  = local.create_cicd_repo ? 1 : 0

  team_name             = "${local.cicdRepoName_gh}-maintainers"
  team_description      = "Code owners of the shared Terraform CI/CD repository ${local.cicdRepoName_gh}. Changes affect every consuming repository."
  repository            = module.gh_cicd_repository[0].repository_name
  repository_permission = "admin"
  members               = local.cicdRepoMaintainers_gh
}

module "gh_cicd_repository" {
  source = "./modules/gh-repository"
  count  = local.create_cicd_repo ? 1 : 0

  repository_name       = local.cicdRepoName_gh
  create_repository     = true
  description           = "Shared GitHub Actions CI/CD for Terraform on Azure (reusable workflow + composite actions)"
  visibility            = local.cicdRepoVisibility_gh
  create_develop_branch = false

  initial_files          = local.cicd_repo_files
  last_file_paths        = [".github/workflows/release.yml"]
  initial_commit_message = "Add shared Terraform CI/CD templates (ign bootstrap)"
  last_commit_message    = "Add release workflow (ign bootstrap) #major"

  allowed_merge_methods       = local.gh_guardrails.allowed_merge_methods
  enable_vulnerability_alerts = local.gh_guardrails.enable_vulnerability_alerts
  enable_secret_scanning      = local.gh_guardrails.enable_secret_scanning

  manage_actions_permissions = local.gh_guardrails.manage_actions_permissions
  allowed_action_patterns    = local.gh_guardrails.allowed_action_patterns
  sha_pinning_required       = local.gh_guardrails.sha_pinning_required

  enable_rulesets            = local.gh_guardrails.enable_rulesets
  protected_branches         = local.gh_guardrails.protected_branches
  required_approvals         = local.gh_guardrails.required_approvals
  require_code_owner_review  = local.gh_guardrails.require_code_owner_review
  require_last_push_approval = local.gh_guardrails.require_last_push_approval
  require_signed_commits     = local.gh_guardrails.require_signed_commits
  require_linear_history     = local.gh_guardrails.require_linear_history

  bypass_team_ids = [tonumber(module.gh_cicd_maintainers[0].team_id)]
}

# Fail early if the CLI did not supply the rendered CI/CD repository files.
resource "terraform_data" "cicd_repo_files_check" {
  count = local.create_cicd_repo ? 1 : 0

  lifecycle {
    precondition {
      condition     = length(local.cicd_repo_files) > 0
      error_message = "createCicdRepo_gh is true but no CI/CD repository files were supplied. Run through ign bootstrap, which renders them and sets TF_VAR_cicd_repo_files_dir."
    }
  }
}

# Allow repositories in the organisation to call the shared CI/CD repo's
# reusable workflow and composite actions (needed because it is private/internal).
resource "github_actions_repository_access_level" "cicd_repo" {
  count        = local.create_cicd_repo || (local.github_first_time && local.manageCicdRepoAccess_gh) ? 1 : 0
  repository   = local.create_cicd_repo ? module.gh_cicd_repository[0].repository_name : local.cicdRepoName_gh
  access_level = "organization"
}
