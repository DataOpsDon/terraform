# =============================================================================
# Azure DevOps (cicdPlatform: ado)
# Everything that talks to Azure DevOps lives in this file, including the provider.
# The azuredevops provider contacts the organisation as soon as it is configured,
# even when every resource here has count = 0, so `ign bootstrap` leaves this file
# out of the run when cicdPlatform is github (it is set aside as ado.tf.disabled
# for the duration of the run and restored afterwards). The provider's version pin
# stays in providers.tf - a required provider with no configuration or resources is
# never configured.
# =============================================================================

# org_service_url is set via environment variable AZDO_ORG_SERVICE_URL by the CLI (takes precedence)
# The CLI ensures AZDO_ORG_SERVICE_URL is set when adoOrgUrl is configured in config.yaml
# Provider block value is used as fallback if env var is not set
provider "azuredevops" {
  # Use value from config.yaml if set, otherwise empty string
  # Environment variable AZDO_ORG_SERVICE_URL takes precedence when set
  org_service_url = local.adoOrgUrl != null ? local.adoOrgUrl : ""
  # PAT token is read from AZDO_PERSONAL_ACCESS_TOKEN environment variable
  # This is set securely by the CLI and never stored in files
  #use_cli = true
  personal_access_token = local.adoPAT
}

data "azuredevops_project" "name" {
  count = local.ado_configured && local.adoCreateProject == false ? 1 : 0
  name  = local.adoProjectName
}

module "build_federated_service_connection" {
  source = "./modules/ado-service-connection"
  count  = local.ado_configured ? 1 : 0

  adoProjectId                 = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  serviceConnectionName        = local.serviceConnectionName_Build
  scDescription                = local.scDescription
  umiPrincipalId               = module.umi_tf_build.client_id
  tenantId                     = data.azurerm_client_config.current.tenant_id
  subscriptionId_Application   = local.subscriptionId_Application
  subscriptionName_Application = local.subscriptionName_Application
  rgName_umiComplete           = local.rgName_umi
  umiResourceId                = module.umi_tf_build.resource_id
}

module "deploy_federated_service_connection" {
  source = "./modules/ado-service-connection"
  count  = local.ado_configured ? 1 : 0

  adoProjectId                 = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  serviceConnectionName        = local.serviceConnectionName_Deploy
  scDescription                = local.scDescription
  umiPrincipalId               = module.umi_tf_deploy.client_id
  tenantId                     = data.azurerm_client_config.current.tenant_id
  subscriptionId_Application   = local.subscriptionId_Application
  subscriptionName_Application = local.subscriptionName_Application
  rgName_umiComplete           = local.rgName_umi
  umiResourceId                = module.umi_tf_deploy.resource_id
  deployApprovalRequired       = local.deployApprovalRequired
  preventSelfReviewDeploy_ado  = local.preventSelfReviewDeploy_ado
  #platformAdminApprovalRequired               = true
  #platformAdminGroupDescriptorDeployApprovers = module.ado_platform_admin_project_permissions[0].ado_project_group_descriptor
}

resource "azuredevops_project" "ado_project" {
  count              = local.ado_configured && local.adoCreateProject == true && local.isFirstTimeDeployToADO == true ? 1 : 0
  name               = local.adoProjectName
  visibility         = "private"
  version_control    = "Git"
  work_item_template = var.ado_work_item_template
  description        = local.adoProjectDescription
  features           = var.ado_project_features
}

resource "azuredevops_environment" "deployment_environment" {
  count      = local.ado_configured ? 1 : 0
  project_id = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  name       = local.environment
}

resource "azuredevops_variable_group" "ado_variable_group" {
  count        = local.ado_configured ? 1 : 0
  project_id   = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  name         = local.environment
  description  = "${local.environment} Variable Group secrets for pipeline deployment"
  allow_access = false

  variable {
    name  = "setup"
    value = "setup"
  }
}

module "ado_platform_admin_project_permissions" {
  source = "./modules/ado-project-permissions"
  count  = local.ado_configured && local.createPlatformAdminGroup == true && local.isFirstTimeDeployToADO == true ? 1 : 0

  project_id                       = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  project_name                     = local.adoProjectName
  project_group_name               = "Platform Admin"
  project_group_description        = "Platform Admin group with elevated permissions for project management and configuration."
  project_permissions              = var.platform_admin_project_permissions
  area_permissions                 = var.platform_admin_area_permissions
  build_permissions                = var.platform_admin_build_permissions
  git_permissions                  = var.platform_admin_git_permissions
  iteration_permissions            = var.platform_admin_iteration_permissions
  library_permissions              = var.platform_admin_library_permissions
  tagging_permissions              = var.platform_admin_tagging_permissions
  shared_query_permissions         = var.platform_admin_shared_query_permissions
  is_group_team_admin              = true
  environment_permission_role      = "Administrator"
  service_endpoint_permission_role = "Administrator"
}

module "ado_lead_engineer_project_permissions" {
  source = "./modules/ado-project-permissions"
  count  = local.ado_configured && local.createLeadEngineerGroup == true && local.isFirstTimeDeployToADO == true ? 1 : 0

  project_id                       = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  project_name                     = local.adoProjectName
  project_group_name               = "Lead Engineers"
  project_group_description        = "Lead Engineers group with elevated permissions for project management and configuration."
  project_permissions              = var.lead_engineer_project_permissions
  area_permissions                 = var.lead_engineer_area_permissions
  build_permissions                = var.lead_engineer_build_permissions
  git_permissions                  = var.lead_engineer_git_permissions
  iteration_permissions            = var.lead_engineer_iteration_permissions
  library_permissions              = var.lead_engineer_library_permissions
  tagging_permissions              = var.lead_engineer_tagging_permissions
  shared_query_permissions         = var.lead_engineer_shared_query_permissions
  is_group_team_admin              = true
  environment_permission_role      = "Administrator"
  service_endpoint_permission_role = "Administrator"
}

module "ado_engineer_project_permissions" {
  source = "./modules/ado-project-permissions"
  count  = local.ado_configured && local.createEngineerGroup == true && local.isFirstTimeDeployToADO == true ? 1 : 0

  project_id                       = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  project_name                     = local.adoProjectName
  project_group_name               = "Engineers"
  project_group_description        = "Engineers group with elevated permissions for project management and configuration."
  project_permissions              = var.engineer_project_permissions
  area_permissions                 = var.engineer_area_permissions
  build_permissions                = var.engineer_build_permissions
  git_permissions                  = var.engineer_git_permissions
  iteration_permissions            = var.engineer_iteration_permissions
  library_permissions              = var.engineer_library_permissions
  tagging_permissions              = var.engineer_tagging_permissions
  shared_query_permissions         = var.engineer_shared_query_permissions
  environment_permission_role      = "User"
  service_endpoint_permission_role = "User"
}

module "ado_pm_project_permissions" {
  source = "./modules/ado-project-permissions"
  count  = local.ado_configured && local.createPMGroup == true && local.isFirstTimeDeployToADO == true ? 1 : 0

  project_id                       = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  project_name                     = local.adoProjectName
  project_group_name               = "Project Managers"
  project_group_description        = "Project Managers group with elevated permissions for project management and configuration."
  project_permissions              = var.pm_project_permissions
  area_permissions                 = var.pm_area_permissions
  build_permissions                = var.pm_build_permissions
  git_permissions                  = var.pm_git_permissions
  iteration_permissions            = var.pm_iteration_permissions
  library_permissions              = var.pm_library_permissions
  tagging_permissions              = var.pm_tagging_permissions
  shared_query_permissions         = var.pm_shared_query_permissions
  is_group_team_admin              = true
  environment_permission_role      = "Reader"
  service_endpoint_permission_role = "Reader"
}

module "ado_lead_tester_project_permissions" {
  source = "./modules/ado-project-permissions"
  count  = local.ado_configured && local.createLeadTesterGroup == true && local.isFirstTimeDeployToADO == true ? 1 : 0

  project_id                       = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  project_name                     = local.adoProjectName
  project_group_name               = "Lead Testers"
  project_group_description        = "Lead Testers group with elevated permissions for project management and configuration."
  project_permissions              = var.lead_tester_project_permissions
  area_permissions                 = var.lead_tester_area_permissions
  build_permissions                = var.lead_tester_build_permissions
  git_permissions                  = var.lead_tester_git_permissions
  iteration_permissions            = var.lead_tester_iteration_permissions
  library_permissions              = var.lead_tester_library_permissions
  tagging_permissions              = var.lead_tester_tagging_permissions
  shared_query_permissions         = var.lead_tester_shared_query_permissions
  is_group_team_admin              = true
  environment_permission_role      = "Reader"
  service_endpoint_permission_role = "Reader"
}

module "ado_tester_project_permissions" {
  source = "./modules/ado-project-permissions"
  count  = local.ado_configured && local.createTesterGroup == true && local.isFirstTimeDeployToADO == true ? 1 : 0

  project_id                       = local.adoCreateProject == true ? azuredevops_project.ado_project[0].id : data.azuredevops_project.name[0].id
  project_name                     = local.adoProjectName
  project_group_name               = "Testers"
  project_group_description        = "Testers group with elevated permissions for project management and configuration."
  project_permissions              = var.tester_project_permissions
  area_permissions                 = var.tester_area_permissions
  build_permissions                = var.tester_build_permissions
  git_permissions                  = var.tester_git_permissions
  iteration_permissions            = var.tester_iteration_permissions
  library_permissions              = var.tester_library_permissions
  tagging_permissions              = var.tester_tagging_permissions
  shared_query_permissions         = var.tester_shared_query_permissions
  environment_permission_role      = "Reader"
  service_endpoint_permission_role = "Reader"
}
