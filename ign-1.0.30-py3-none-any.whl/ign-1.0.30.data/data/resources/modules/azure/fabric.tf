# Azure Fabric Module
# Description: Azure Fabric resources


# Currently no Fabric AVM module to call so using standard Terraformresources

# Set up the Fabric Capacity resource
resource "azurerm_fabric_capacity" "fb_capacity" {
  name                = module.naming.name.fabric_capacity
  resource_group_name = module.resource_group.name
  location            = module.resource_group.resource.location

  administration_members = [data.azurerm_client_config.current.object_id]

  sku {
    name = "F32"
    tier = "Fabric"
  }

  #tags = {}
}

data "fabric_capacity" "fc" {
  display_name = module.naming.name.fabric_capacity
}

# Create the fabric workspace
resource "fabric_workspace" "fb_workspace" {
  display_name = "Fabric Workspace"
  description  = "Fabric Workspace provisioned" #TODO - add description
  capacity_id  = data.fabric_capacity.fc.id
}

# Create a Lakehouse inside the Workspace
resource "fabric_lakehouse" "fb_lakehouse" {
  workspace_id = fabric_workspace.fb_workspace.id
  display_name = "lakehouse1"
  description  = "Lakehouse storing Delta tables and files in OneLake." #TODO - add description
}

# Assign roles
resource "fabric_workspace_role_assignment" "fb_workspace_role_assignment" {
  workspace_id = fabric_workspace.fb_workspace.id
  principal = {
    id   = ""
    type = "User"
  }
  role = "Member" # Role types {Admin, Contributor, Member, Viewer}
}