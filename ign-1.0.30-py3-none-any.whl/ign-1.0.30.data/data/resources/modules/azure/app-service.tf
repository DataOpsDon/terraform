# Azure App Service Module
# Description: Azure App Service for web applications

module "{{resource_name}}" {
  source                        = "Azure/avm-res-web-site/azurerm"
  version                       = "0.20.0"
  name                          = "${module.naming.name.app_service}-{{resource_name}}"
  location                      = module.resource_group.location
  parent_id                     = module.resource_group.resource_id
  enable_telemetry              = var.enable_telemetry
  tags                          = var.tags
  kind                          = "webapp"
  os_type                       = "Linux"
  service_plan_resource_id      = module.app_service_plan.resource_id
  https_only                    = true
  public_network_access_enabled = false
  virtual_network_subnet_id     = ""

  managed_identities = {
    system_assigned = true
  }

  # Add application settings, connection strings, and other configuration as needed

  site_config = {}

  app_settings = {}

  # Code block for private endpoint within the app service
  private_endpoints = {
    primary = {
      subnet_resource_id            = module.vnet_west.subnets["subnet_pe"].resource_id
      private_dns_zone_resource_ids = [] # eg [data.azurerm_private_dns_zone.app_service_private_dns.id]
    }
  }
}

