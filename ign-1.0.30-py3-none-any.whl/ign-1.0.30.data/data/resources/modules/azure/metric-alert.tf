# Azure Monitor Metric Alert
# Description: Manages a Metric Alert within Azure Monitor
# Note: Temporary raw Terraform until AVM module is available

resource "azurerm_monitor_metric_alert" "{{resource_name}}" {
  name                = module.naming.name.metric_alert
  resource_group_name = module.resource_group.name

  # Resource(s) monitored by the alert.
  # This can be a resource, resource group or subscription scope.
  scopes = [
    module.resource_group.id
  ]

  description = "Describe the condition and purpose of this alert."

  # Alert configuration
  enabled       = true
  severity      = 3
  frequency     = "PT5M"
  window_size   = "PT5M"
  auto_mitigate = true

  # Required when using resource group, subscription or multiple-resource scopes.
  # target_resource_type     = "Microsoft.Storage/storageAccounts"
  # target_resource_location = module.resource_group.location

  criteria {
    # Update these values for the Azure resource/metric being monitored.
    metric_namespace = "Microsoft.Storage/storageAccounts"
    metric_name      = "Transactions"

    aggregation = "Total"
    operator    = "GreaterThan"
    threshold   = 50

    # Optional metric dimension filtering.
    dimension {
      name     = "ApiName"
      operator = "Include"
      values   = ["*"]
    }

    # Set to true when creating an alert for a custom metric that may not have been emitted yet.
    # skip_metric_validation = false
  }

  # Additional criteria blocks can be added where required.

  action {
    action_group_id = module.action_group.id

    # Optional custom properties supplied to webhook receivers.
    # webhook_properties = {
    #   environment = var.environment
    # }
  }

  tags = var.tags
}