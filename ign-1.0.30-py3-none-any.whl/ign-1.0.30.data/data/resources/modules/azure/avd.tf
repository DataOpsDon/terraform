# Azure Virtual Desktop Module
# Description: Azure Virtual Desktop (AVD) management plane including host pool, application group, workspace, and scaling plan
# You will need to uncomment the VM extensions for AVD to work
/*
# Assign the Azure AD group to the application group to allow access to the AVD VM
resource "azurerm_role_assignment" "vm_vm_user_login" {
  principal_id                     = data.azuread_group.avd_users.object_id # Data block lookup for the Azure AD group
  scope                            = module.resource_group.resource_id
  role_definition_name             = "Virtual Machine User Login"
  skip_service_principal_aad_check = false
}*/

########### Policy Exemption for AVD VMs to allow public network access ############
resource "azurerm_resource_group_policy_exemption" "avd" {
  name                 = "AVDExemption"
  resource_group_id    = module.resource_group.resource_id
  policy_assignment_id = data.azurerm_policy_assignment.paas_private_link.id
  exemption_category   = "Mitigated"
  policy_definition_reference_ids = [
    "deny-workspace-publicnetworkaccess",
    "deny-hostpool-publicnetworkaccess"
  ]
}

# Intiative "Public network access should be disabled for PaaS services" scoped at "corp"
data "azurerm_policy_assignment" "paas_private_link" {
  scope_id = data.azurerm_management_group.corp.id #Resolves to "/providers/Microsoft.Management/managementGroups/corp"
  name     = "deny-public-endpoints"
}

data "azurerm_management_group" "corp" {
  name = "corp"
}

########### end of policy exemption for AVD VMs to allow public network access ############


##################################

module "{{resource_name}}" {
  source  = "Azure/avm-ptn-avd-lza-managementplane/azurerm"
  version = "0.3.2"

  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  managed_identities = {
    system_assigned = true
  }

  # Application Group
  virtual_desktop_application_group_resource_group_name          = module.resource_group.name
  virtual_desktop_application_group_location                     = var.location
  virtual_desktop_application_group_name                         = module.naming.name.application_group
  virtual_desktop_application_group_type                         = "Desktop"
  virtual_desktop_application_group_default_desktop_display_name = "AVD Desktop" # This is what the user sees in the windows app
  virtual_desktop_application_group_description                  = "AVD group"
  virtual_desktop_application_group_friendly_name                = "AVD Application"
  virtual_desktop_application_group_tags                         = var.tags

  # Host Pool
  virtual_desktop_host_pool_load_balancer_type       = "DepthFirst"
  virtual_desktop_host_pool_location                 = var.location
  virtual_desktop_host_pool_name                     = module.naming.name.host_pool
  virtual_desktop_host_pool_resource_group_name      = module.resource_group.name
  virtual_desktop_host_pool_type                     = "Pooled"
  virtual_desktop_host_pool_description              = "AVD host pool"
  virtual_desktop_host_pool_friendly_name            = "AVD Host Pool"
  virtual_desktop_host_pool_maximum_sessions_allowed = 8
  virtual_desktop_host_pool_tags                     = var.tags

  virtual_desktop_host_pool_custom_rdp_properties = {
    "audiomode" : 0,
    "custom_properties" : {
      "enablerdsaadauth:i" : 1
    },
    "devicestoredirect" : "*",
    "drivestoredirect" : "*",
    "enablecredsspsupport" : 1,
    "redirectclipboard" : 1,
    "redirectcomports" : 1,
    "redirectprinters" : 1,
    "redirectsmartcards" : 1,
    "usbdevicestoredirect" : "*",
    "use_multimon" : 0,
    "videoplaybackmode" : 1
  }

  # Scaling Plan
  virtual_desktop_scaling_plan_location            = var.location
  virtual_desktop_scaling_plan_name                = module.naming.name.scaling_plan
  virtual_desktop_scaling_plan_resource_group_name = module.resource_group.name
  virtual_desktop_scaling_plan_time_zone           = "GMT Standard Time"
  virtual_desktop_workspace_location               = var.location
  virtual_desktop_workspace_name                   = module.naming.name.workspace
  virtual_desktop_scaling_plan_friendly_name       = "AVD Scaling Plan"
  virtual_desktop_scaling_plan_tags                = var.tags
  virtual_desktop_scaling_plan_host_pool = {
    hostpool_id          = module.host_pool.resource_id
    scaling_plan_enabled = true
  }
  virtual_desktop_scaling_plan_schedule = [
    {
      name                                 = "Weekday"
      days_of_week                         = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
      ramp_up_start_time                   = "09:00"
      ramp_up_load_balancing_algorithm     = "BreadthFirst"
      ramp_up_minimum_hosts_percent        = 50
      ramp_up_capacity_threshold_percent   = 80
      peak_start_time                      = "10:00"
      peak_load_balancing_algorithm        = "DepthFirst"
      ramp_down_start_time                 = "17:00"
      ramp_down_load_balancing_algorithm   = "BreadthFirst"
      ramp_down_minimum_hosts_percent      = 50
      ramp_down_force_logoff_users         = true
      ramp_down_wait_time_minutes          = 15
      ramp_down_notification_message       = "The session will end in 15 minutes."
      ramp_down_capacity_threshold_percent = 50
      ramp_down_stop_hosts_when            = "ZeroActiveSessions"
      off_peak_start_time                  = "18:00"
      off_peak_load_balancing_algorithm    = "BreadthFirst"
    },
    {
      name                                 = "Weekend"
      days_of_week                         = ["Saturday", "Sunday"]
      ramp_up_start_time                   = "09:00"
      ramp_up_load_balancing_algorithm     = "BreadthFirst"
      ramp_up_minimum_hosts_percent        = 50
      ramp_up_capacity_threshold_percent   = 80
      peak_start_time                      = "10:00"
      peak_load_balancing_algorithm        = "DepthFirst"
      ramp_down_start_time                 = "17:00"
      ramp_down_load_balancing_algorithm   = "BreadthFirst"
      ramp_down_minimum_hosts_percent      = 50
      ramp_down_force_logoff_users         = true
      ramp_down_wait_time_minutes          = 15
      ramp_down_notification_message       = "The session will end in 15 minutes."
      ramp_down_capacity_threshold_percent = 50
      ramp_down_stop_hosts_when            = "ZeroActiveSessions"
      off_peak_start_time                  = "18:00"
      off_peak_load_balancing_algorithm    = "BreadthFirst"
    }
  ]

  # Workspace
  virtual_desktop_workspace_friendly_name = "AVD Workspace"
  virtual_desktop_workspace_tags          = var.tags
}