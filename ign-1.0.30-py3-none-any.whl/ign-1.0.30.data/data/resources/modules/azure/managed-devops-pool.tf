# Azure Managed DevOps Pool & Dev Center Module
# Description: Azure Dev Center project and Managed DevOps pool resources for developer environment provisioning

module "avm-res-devopsinfrastructure-pool" {
  source                                    = "Azure/avm-res-devopsinfrastructure-pool/azurerm"
  version                                   = "0.3.1"
  resource_group_name                       = "x"
  location                                  = "x"
  name                                      = module.naming.name.managed_devops_pool
  enable_telemetry                          = true
  dev_center_project_resource_id            = azurerm_dev_center_project.this.id
  tags                                      = {}
  agent_profile_resource_prediction_profile = "Manual"
  agent_profile_resource_predictions_manual = "x"
  subnet_id                                 = module.virtual_network.subnets["devops"].resource.id
  maximum_concurrency                       = 2
  organization_profile = {
    kind = "AzureDevOps"
    organizations = [

    ]
    permission_profile = {
      kind = "Inherit"
    }
  }
}

resource "azurerm_dev_center_project" "this" {
  dev_center_id       = module.avm-res-devcenter-devcenter.resource_id
  location            = module.ado_resource_group.resource.location
  name                = module.naming.name.dev_center_project
  resource_group_name = module.ado_resource_group.name
}

module "avm-res-devcenter-devcenter" {
  source              = "Azure/avm-res-devcenter-devcenter/azurerm"
  version             = "0.1.0"
  location            = module.networking_resource_group.resource.location
  resource_group_name = module.ado_resource_group.name
  dev_center_name     = module.naming.name.dev_center
}
