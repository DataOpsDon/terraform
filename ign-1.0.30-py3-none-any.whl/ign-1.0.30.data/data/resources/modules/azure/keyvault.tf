# Azure Key Vault Module
# Description: Azure Key Vault for secrets management

module "{{resource_name}}" {
  source                   = "Azure/avm-res-keyvault-vault/azurerm"
  version                  = "0.11.2"
  name                     = module.naming.name.key_vault
  location                 = module.resource_group.resource.location
  resource_group_name      = module.resource_group.name
  tenant_id                = data.azurerm_client_config.current.tenant_id
  sku_name                 = "standard"
  purge_protection_enabled = false
  enable_telemetry         = var.enable_telemetry
  tags                     = var.tags

  # Network configuration
  public_network_access_enabled = false
  network_acls = {
    default_action = "Deny"
    bypass         = "AzureServices"
    # Add your IP addresses or virtual network rules here
    # ip_rules       = ["YOUR_IP_HERE"]
  }

  # Add secrets, keys, and access policies as needed
}

