# Azure Databricks Workspace Module
# Description: Azure Databricks workspace for data processing and analytics

module "{{resource_name}}" {
  source              = "Azure/avm-res-databricks-workspace/azurerm"
  version             = "0.5.2"
  name                = "${module.naming.name.databricks_workspace}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  sku                 = "premium"
  enable_telemetry    = var.enable_telemetry
  tags                = var.tags

  # Network configuration
  public_network_access_enabled = false

  # Add custom configuration as needed
}

