# Azure Logic App Module
# Description: Azure Logic App (Standard) workflow for event-driven automation and integration

module "{{resource_name}}" {
  source  = "Azure/avm-res-logic-workflow/azurerm"
  version = "0.1.2"

  enable_telemetry    = var.enable_telemetry
  name                = "logic-${var.location_short}-${var.project}-${var.environment}"
  location            = module.resource_group.location
  resource_group_name = module.resource_group.name
  resource_group_id   = module.resource_group.resource_id
  tags                = var.tags

  logic_app_definition = jsondecode(
    templatefile("${path.module}/logicapp-definition.json", {

      # Parameters needed for workflow definitons can be defined here e.g.
      #serviceBusQueueName = local.servicebus_queue_name
      #keyVaultName        = local.key_vault_name
      #tenantId            = data.azurerm_client_config.current.tenant_id
      #d365BaseUrl         = var.d365_base_url
    })
  )

  managed_identities = {
    system_assigned = true
  }
}