# Azure Virtual Network Module
# Description: Azure Virtual Network with configurable address space, subnets, and custom DNS servers

module "{{resource_name}}" {
  source        = "Azure/avm-res-network-virtualnetwork/azurerm"
  version       = "0.15.0"
  name          = var.name
  location      = module.resource_group.resource.location
  parent_id     = module.resource_group.resource_id
  address_space = var.address_space
  dns_servers = {
    dns_servers = var.dns_servers
  }
}
# insert the 2 required variables here
variable "dns_servers" {
  type        = list(string)
  description = "List of Custom DNS Servers for Virtual Network (leave blank if using Azure Provided DNS)"
  default     = []
}

variable "address_space" {
  type        = list(string)
  description = "Address Space of the Virtual Network"
}

variable "name" {
  type        = string
  description = "The resource name of the Virtual Network"
}