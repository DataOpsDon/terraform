# Private DNS Zones Helper
# Description: Shared data source lookups for private DNS zones used by private endpoints (Key Vault, Blob, ACR, App Service, Cognitive Services, Cosmos, OpenAI)

# Private  DNS Zone for KeyVault
data "azurerm_private_dns_zone" "key_vault_private_dns" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "blob_private_dns" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "acr_private_dns" {
  name                = "privatelink.azurecr.io"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "app_service_private_dns" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "cognitives_services_private_dns" {
  name                = "privatelink.cognitiveservices.azure.com"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "mongo_cluster_private_dns" {
  name                = "privatelink.mongocluster.cosmos.azure.com"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}

data "azurerm_private_dns_zone" "openai_private_dns" {
  name                = "privatelink.openai.azure.com"
  resource_group_name = var.hub_dns_resource_group_name
  provider            = azurerm.connectivity
}