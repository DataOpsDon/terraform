# Azure Private Endpoint Module
# Description: Private Endpoint for secure private access to Azure services

module "{{resource_name}}" {
  source                         = "Azure/avm-res-network-privateendpoint/azurerm"
  version                        = "0.2.0"
  enable_telemetry               = var.enable_telemetry # see variables.tf
  name                           = module.naming.private_endpoint.name
  location                       = module.resource_group.location
  resource_group_name            = module.resource_group.name
  network_interface_name         = module.naming.network_interface.name_unique
  private_connection_resource_id = var.resource_id
  subnet_resource_id             = var.subnet_id
  subresource_names              = ["${var.sub_resource_name}"]
}

variable "enable_telemetry" {
  type        = bool
  description = "Flag to enable AVM Telemtry"
}

variable "resource_id" {
  type        = string
  description = "The parent resource id of the services assoociated with the Private Endpoint"
}

variable "subnet_id" {
  type        = string
  description = "The Azure Resource Id of the parent resource that the Private Endpoint is associated with"
}

variable "sub_resource_name" {
  type        = string
  description = "The name of the sub-resource name of the parent associated with the Private Endpoint"
}

