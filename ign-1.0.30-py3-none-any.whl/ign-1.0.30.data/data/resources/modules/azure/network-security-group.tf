# Azure Network Security Group Module
# Description: Network Security Group to control inbound and outbound traffic

module "{{resource_name}}" {
  source  = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version = "0.5.0"
  # insert the 3 required variables here
}