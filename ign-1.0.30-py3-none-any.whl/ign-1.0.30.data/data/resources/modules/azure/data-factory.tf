# Azure Data Factory Module
# Description: Azure Data Factory for data integration and orchestration

module "{{resource_name}}" {
  source  = "Azure/avm-res-datafactory-factory/azurerm"
  version = "0.1.0"
  # insert the 3 required variables here
}