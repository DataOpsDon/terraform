# Azure Recovery Services Vault Module
# Description: Recovery Services Vault for backup and disaster recovery

module "{{resource_name}}" {
  source              = "Azure/avm-res-recoveryservices-vault/azurerm"
  version             = "0.3.2"
  name                = "${module.naming.name.recovery_services_vault}{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Recovery vault configuration
  sku                   = "Standard"
  storage_mode_type     = "GeoRedundant"
  cross_region_restore  = true
  soft_delete_enabled   = true
  public_network_access = "Disabled"

  # Identity configuration
  identity = {
    type = "SystemAssigned"
  }

  # Backup policies
  backup_policies = {
    # daily_vm_policy = {
    #   name      = "daily-vm-backup"
    #   type      = "V2"
    #   timezone  = "UTC"
    #   backup = {
    #     frequency = "Daily"
    #     time      = "23:00"
    #   }
    #   retention_daily = {
    #     count = 30
    #   }
    # }
  }
}