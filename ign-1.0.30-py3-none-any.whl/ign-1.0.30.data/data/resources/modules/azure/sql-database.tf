# Azure SQL Database Module
# Description: Azure SQL Server and Database

module "{{resource_name}}" {
  source              = "Azure/avm-res-sql-server/azurerm"
  version             = "0.4.0"
  name                = "${module.naming.name.sql_server}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  tags                = var.tags

  # Administrator credentials (use Key Vault references in production!)
  administrator_login          = "sqladmin"
  administrator_login_password = "P@ssw0rd123!" # TODO: Move to Key Vault

  # Add databases, firewall rules, and other configuration as needed
}

