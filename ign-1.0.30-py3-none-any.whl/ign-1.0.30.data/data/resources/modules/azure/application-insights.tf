# Azure Application Insights Module
# Description: Azure Application Insights resource for monitoring and telemetry

module "{{resource_name}}" {
  source              = "Azure/avm-res-insights-component/azurerm"
  version             = "0.3.0"
  name                = "${module.naming.name.application_insights}{{resource_name}}"
  location            = module.resource_group.location
  resource_group_name = module.resource_group.name
  workspace_id        = "" #The ID of the Log Analytics workspace to send data to.
}