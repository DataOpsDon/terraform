# Azure Event Hubs Namespace Module
# Description: Azure Event Hubs high-throughput data streaming platform

module "{{resource_name}}" {
  source  = "Azure/avm-res-eventhub-namespace/azurerm"
  version = "0.1.0"
  # insert the 3 required variables here

  name                = "${module.naming.name.event_hub_namespace}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
  sku                 = "Standard"
}