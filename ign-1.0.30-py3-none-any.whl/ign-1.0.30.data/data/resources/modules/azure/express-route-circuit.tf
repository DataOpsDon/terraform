# Azure ExpressRoute Circuit Module
# Description: ExpressRoute Circuit for dedicated private network connectivity to Azure

module "{{resource_name}}" {
  source              = "Azure/avm-res-network-expressroutecircuit/azurerm"
  version             = "0.3.3"
  name                = "${module.naming.name.express_route_circuit}{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # ExpressRoute Circuit configuration
  sku = {
    tier   = "Standard"
    family = "MeteredData"
  }

  service_provider_name = "{{service_provider_name}}"
  peering_location      = "{{peering_location}}"
  bandwidth_in_mbps     = 50

  # Add peering configurations as needed
  # peerings = {
  #   private = {
  #     peering_type = "AzurePrivatePeering"
  #     vlan_id      = 100
  #   }
  # }
}