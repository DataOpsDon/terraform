# Azure Resource Group Module
# Description: Resource Group for organizing Azure resources

module "{{resource_name}}" {
  source   = "Azure/avm-res-resources-resourcegroup/azurerm"
  version  = "0.2.2"
  name     = "rg-${var.location_short}-${var.project}-{{resource_name}}"
  location = var.location
  tags     = var.tags
  #insert required variables here
}