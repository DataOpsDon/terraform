# Azure Monitor Action Group
# Description: Action group for Azure Monitor alert notifications
# Note: Temporary raw Terraform until AVM module is available

resource "azurerm_monitor_action_group" "{{resource_name}}" {
  name                = module.naming.name.action_group
  resource_group_name = module.resource_group.name
  short_name          = "EmailGrp"
  enabled             = true
  tags                = var.tags

  email_receiver {
    name                    = "alertsupport"
    email_address           = "support@exampledomain.com"
    use_common_alert_schema = true
  }

  # Add additional receivers if required
}

