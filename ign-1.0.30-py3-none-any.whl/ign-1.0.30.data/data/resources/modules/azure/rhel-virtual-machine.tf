# Azure RHEL Virtual Machine Module
# Contributor: Simon Day
# Description: RHEL virtual machine with Compute Gallery and Marketplace image options and SSH key authentication

module "{{resource_name}}" {
  source                       = "Azure/avm-res-compute-virtualmachine/azurerm"
  version                      = "0.21.0"
  name                         = var.name
  location                     = module.resource_group.resource.location
  resource_group_name          = module.resource_group.name
  zone                         = var.availability_zone
  availability_set_resource_id = var.availability_set_resource_id
  os_type                      = "Linux"
  sku_size                     = var.vm_sku
  source_image_resource_id     = var.gallery_image_version_id
  source_image_reference       = var.rhel_marketplace_image_reference
  enable_telemetry             = var.enable_telemetry
  tags                         = var.tags

  account_credentials = {
    admin_credentials = {
      username                           = var.admin_username
      ssh_keys                           = [var.admin_ssh_public_key]
      generate_admin_password_or_ssh_key = false
    }
    password_authentication_disabled = true
  }

  managed_identities = {
    system_assigned = true
  }

  network_interfaces = {
    main = {
      name       = "nic-${var.name}"
      is_primary = true
      ip_configurations = {
        main = {
          name                          = "ipconfig1"
          private_ip_subnet_resource_id = var.subnet_id
        }
      }
    }
  }

  os_disk = {
    name                 = "os-disk-${var.name}"
    storage_account_type = "Premium_LRS"
    caching              = "ReadWrite"
    disk_size_gb         = 250
  }

  data_disk_managed_disks = {
    data = {
      name                 = "data-disk-${var.name}"
      create_option        = "Empty"
      disk_size_gb         = 500
      lun                  = 0
      storage_account_type = "Premium_LRS"
      caching              = "None"
    }
  }
}

variable "name" {
  type        = string
  description = "Name of the RHEL virtual machine"
}

variable "gallery_image_version_id" {
  type        = string
  description = "Optional full resource ID of a generalized RHEL Compute Gallery image version using a numeric major.minor.patch version"
  default     = null

  validation {
    condition = var.gallery_image_version_id == null || can(regex(
      "(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft.Compute/galleries/[^/]+/images/[^/]+/versions/[0-9]+\\.[0-9]+\\.[0-9]+$",
      var.gallery_image_version_id
    ))
    error_message = "gallery_image_version_id must be a full Compute Gallery image version resource ID with an explicit numeric major.minor.patch version; latest is not allowed."
  }

  validation {
    condition     = (var.gallery_image_version_id == null) != (var.rhel_marketplace_image_reference == null)
    error_message = "Set exactly one of gallery_image_version_id or rhel_marketplace_image_reference."
  }
}

variable "rhel_marketplace_image_reference" {
  type = object({
    publisher = string
    offer     = string
    sku       = string
    version   = string
  })
  description = "Optional explicit-version Red Hat Enterprise Linux Marketplace image reference; do not use latest"
  default     = null

  validation {
    condition = var.rhel_marketplace_image_reference == null || (
      lower(var.rhel_marketplace_image_reference.publisher) == "redhat" &&
      lower(var.rhel_marketplace_image_reference.offer) == "rhel" &&
      length(trimspace(var.rhel_marketplace_image_reference.version)) > 0 &&
      lower(trimspace(var.rhel_marketplace_image_reference.version)) != "latest" &&
      !strcontains(var.rhel_marketplace_image_reference.version, "*")
    )
    error_message = "The Marketplace reference must use publisher RedHat, offer RHEL, and a pinned version other than latest or a wildcard."
  }
}

variable "vm_sku" {
  type        = string
  description = "Azure VM size, such as Standard_D2s_v5"
  default     = "Standard_D2s_v5"
}

variable "admin_username" {
  type        = string
  description = "Linux administrator username for SSH access"
  default     = "azureuser"
}

variable "admin_ssh_public_key" {
  type        = string
  description = "SSH public key installed for the Linux administrator"
}

variable "subnet_id" {
  type        = string
  description = "Resource ID of the subnet for the VM network interface"
}

variable "availability_zone" {
  type        = string
  description = "Availability zone for the VM, or null for a region without zones"
  default     = null

  validation {
    condition     = var.availability_zone == null || var.availability_set_resource_id == null
    error_message = "availability_zone and availability_set_resource_id cannot both be set."
  }
}

variable "availability_set_resource_id" {
  type        = string
  description = "Optional resource ID of an existing availability set for the VM; mutually exclusive with availability_zone"
  default     = null
}