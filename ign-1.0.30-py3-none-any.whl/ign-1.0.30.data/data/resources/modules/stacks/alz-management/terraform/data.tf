data "azurerm_client_config" "main" {}

data "terraform_remote_state" "connectivity" { //change this
  backend = "azurerm"
  config = {
    subscription_id      = var.subscription_id
    resource_group_name  = "rg-"
    storage_account_name = "st"
    container_name       = "connectivity"
    key                  = "state"
  }
}
