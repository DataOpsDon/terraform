variable "subscription_id" {
  description = "The subscription ID to use for the AzureRM provider."
  type        = string
}

variable "connectivity_subscription_id" {
  description = "The subscription ID for the connectivity resources."
  type        = string
}

variable "location" {
  description = "The Azure region where resources will be deployed."
  type        = string
}

variable "tags" {
  type = map(string)
}

variable "location_short" {
  description = "Short code for the Azure region, used in resource names."
  type        = string
}

variable "enable_telemetry" {
  description = "Flag to enable or disable telemetry."
  type        = bool
}

variable "vnet_address_space" {
  description = "The address space for the virtual network."
  type        = string
}

variable "dns_servers" {
  description = "List of DNS servers to be used in the virtual network."
  type        = list(string)
}

variable "nsgs" {
  description = "Map of NSG names to their respective security rules."
  type = map(object({
    security_rules = map(object({
      name                       = string
      priority                   = number
      direction                  = string
      access                     = string
      protocol                   = string
      source_port_range          = optional(string, "*")
      destination_port_range     = optional(string, "*")
      source_address_prefix      = optional(string, "*")
      destination_address_prefix = optional(string, "*")
    }))
  }))
}


variable "route_tables_routes" {
  description = "Map of route table keys to their list of route definitions."
  type = map(object({
    routes = map(object({
      name                   = string
      address_prefix         = string
      next_hop_type          = string
      next_hop_in_ip_address = optional(string)
    }))
  }))
}

// adding stand-by times for managed devops pool agent
variable "agent_profile_resource_predictions_manual" {
  type = object({
    time_zone = optional(string)
    days_data = list(map(number))
  })
  description = "Manual stand-by times for agent per day"
}