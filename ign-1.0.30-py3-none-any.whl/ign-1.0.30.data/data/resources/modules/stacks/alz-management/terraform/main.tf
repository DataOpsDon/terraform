// ---------------------------------------------------------------------------------------------------------------------
// ALZ Management Stack - Logging, DevCenter/Managed DevOps, Databricks Workspace, Monitoring Private Link Scope
// This Terraform file orchestrates management plane resources for the EDP platform: resource groups for segmentation,
// networking (VNet, NSGs, route tables) for secure Databricks & DevOps pools, DevCenter project/pool integration,
// Databricks workspace (private), Azure Monitor Private Link Scope & Private Endpoints, and optional ALZ management pattern.
//
// Notes:
// - Naming centralized via `naming` module for consistent base names (RGs, VNet, workspace, devcenter, pool, PLS resources).
// - Resource groups split by concern: networking, ADO (DevOps), logging, Databricks workspace.
// - NSGs & route tables applied per subnet for traffic control (Databricks host/container, DevOps agents, private endpoints).
// - VNet subnets CIDR carved deterministically via cidrsubnet; consider externalising counts / newbits if future scaling.
// - Remote state (connectivity stack) consumed for DNS zones & VNet peering values.
// - DevOps Infrastructure Pool integrates Azure DevCenter projects; agent concurrency limited (adjust maximum_concurrency).
// - Databricks workspace uses private endpoints & delegated subnets; ensure firewall/DNS rules exist upstream.
// - ALZ management pattern module conditionally deployed only in uksouth (log analytics, automation, DCRs - mostly disabled placeholders).
// - Private Link Scope locks down ingestion to private only (query remains open); consider tightening based on compliance.
// ---------------------------------------------------------------------------------------------------------------------

// Module: naming
// Purpose: Provides consistent naming primitives across all management resources.
// Notes: Adjust suffix/lz if deploying additional management stacks (e.g., h1s02). lz_short currently reused.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = "edp"
  lz       = "h1s01"
  suffix   = "sec"
  lz_short = "connect"
}



// Module: networking_resource_group
// Purpose: Core RG hosting VNet, NSGs, route tables for management plane networking (Databricks, DevOps, Private Endpoints).
// Notes: Consider enabling delete lock (commented).
module "networking_resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  location         = var.location
  enable_telemetry = var.enable_telemetry
  name             = module.naming.name.resource_group
  //lock             = local.rg_no_delete_lock
  tags = var.tags
}

// Module: ado_resource_group
// Purpose: Dedicated RG for Azure DevCenter project and DevOps infrastructure pool resources.
// Notes: Segregates DevOps agent-managed identities & related artifacts from networking/logging RGs.


// Module: logging_resource_group
// Purpose: Holds logging/monitoring assets (Log Analytics, Private Link Scope, related PE). Enables isolated RBAC & retention policies.
// Notes: Delete lock active via local value; service-specific tag applied for cost allocation.
module "logging_resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  location         = var.location
  enable_telemetry = var.enable_telemetry
  name             = "${module.naming.name.resource_group}-log"
  lock             = local.rg_no_delete_lock
  tags = merge(var.tags, {
    "ServiceName" = "Logging"
  })
}

// Module: dbw_resource_group
// Purpose: Resource group for Databricks workspace (main workspace RG plus managed RG created via module parameters).
// Notes: Keep separate for lifecycle management. Lock optional.


// Module: nsg
// Purpose: Deploy NSGs per subnet (Databricks host/container, DevOps, PEP) using for_each map variable.
// Notes: security_rules provided via var.nsgs allowing environment tailoring. Name pattern currently hardcoded (TODO parameterise).
module "nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  for_each            = var.nsgs
  version             = "0.4.0"
  resource_group_name = module.networking_resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-uks-edp-h1s00-sec-${each.key}" // CHANGE THIS (parameterise)
  security_rules      = each.value.security_rules
  tags                = var.tags
}


// Module: route_tables
// Purpose: Custom route tables per subnet (databricks host/container/devops/pep) controlling egress/inspection paths.
// Notes: Provided routes from var.route_tables_routes; BGP propagation disabled for deterministic routing via firewall.
module "route_tables" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  for_each                      = var.route_tables_routes
  resource_group_name           = module.networking_resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-uks-edp-h1s00-sec-${each.key}" // CHANGE THIS (parameterise)
  bgp_route_propagation_enabled = false
  tags                          = var.tags
  routes                        = each.value.routes
}


// Module: virtual_network
// Purpose: Management VNet with subnets for Databricks host/container, DevOps pool, and private endpoints; peered to hub.
// Notes: CIDRs derived via cidrsubnet for deterministic segmentation; hardcoded names flagged for future parameterisation.
module "virtual_network" {
  source           = "Azure/avm-res-network-virtualnetwork/azurerm"
  version          = "0.9.0"
  name             = module.naming.name.virtual_network
  enable_telemetry = var.enable_telemetry
  location         = module.networking_resource_group.resource.location
  dns_servers = {
    dns_servers = ["${data.terraform_remote_state.connectivity.outputs.dns_ip_address}"]
  }
  resource_group_name = module.networking_resource_group.name
  address_space       = ["${var.vnet_address_space}"]
  subnets = {
    "databricks_host" = {
      name                   = "snet-uks-edp-h1s00-sec-dbwhost" // CHANGE THIS (parameterise)
      address_prefixes       = [cidrsubnet(var.vnet_address_space, 2, 0)]
      network_security_group = { id = module.nsg["dbwhost"].resource_id }
      route_table            = { id = module.route_tables["dbwhost"].resource_id }
      delegation = [{
        name               = "Microsoft.Databricks/workspaces"
        service_delegation = { name = "Microsoft.Databricks/workspaces" }
      }]
    }
    "databricks_cont" = {
      name                   = "snet-uks-edp-h1s00-sec-dbwcont" // CHANGE THIS (parameterise)
      address_prefixes       = [cidrsubnet(var.vnet_address_space, 2, 1)]
      network_security_group = { id = module.nsg["dbwcont"].resource_id }
      route_table            = { id = module.route_tables["dbwcont"].resource_id }
      delegation = [{
        name               = "Microsoft.Databricks/workspaces"
        service_delegation = { name = "Microsoft.Databricks/workspaces" }
      }]
    }
    "devops" = {
      name                   = "snet-uks-edp-h1s00-sec-ado" // CHANGE THIS (parameterise)
      address_prefixes       = [cidrsubnet(var.vnet_address_space, 3, 4)]
      network_security_group = { id = module.nsg["ado"].resource_id }
      route_table            = { id = module.route_tables["ado"].resource_id }
      delegation = [{
        name               = "Microsoft.DevOpsInfrastructure/pools"
        service_delegation = { name = "Microsoft.DevOpsInfrastructure/pools" }
      }]
    }
    "private_endpoints" = {
      name                   = "snet-uks-edp-h1s00-sec-pep" // CHANGE THIS (parameterise)
      address_prefixes       = [cidrsubnet(var.vnet_address_space, 3, 5)]
      network_security_group = { id = module.nsg["pep"].resource_id }
      route_table            = { id = module.route_tables["pep"].resource_id }
    }
  }
  peerings = {
    "hub" = {
      name                               = "${module.naming.name.virtual_network}-peer-${data.terraform_remote_state.connectivity.outputs.hub_virtual_network_name}"
      remote_virtual_network_resource_id = data.terraform_remote_state.connectivity.outputs.hub_virtual_network_id
      allow_forwarded_traffic            = true
      allow_gateway_transit              = false // keep this off
      use_remote_gateways                = false
      allow_virtual_network_access       = true
      do_not_verify_remote_gateways      = false
      peer_complete_vnets                = true
      create_reverse_peering             = true
      reverse_name                       = "${data.terraform_remote_state.connectivity.outputs.hub_virtual_network_name}-peer-${module.naming.name.virtual_network}"
      reverse_allow_forwarded_traffic    = true
      reverse_allow_gateway_transit      = true
      reverse_peer_complete_vnets        = true
    }
  }
  tags = var.tags
}

// Module: avm-res-devcenter-devcenter
// Purpose: Deploys Azure DevCenter instance used to manage DevOps pools and developer environments.
// Notes: Name derived from naming module; consider adding diagnostics settings & RBAC assignments separately.



// Module: avm-res-devopsinfrastructure-pool
// Purpose: Creates managed DevOps pool (agents) tied to DevCenter project; supports Azure DevOps pipelines execution.
// Notes: Subnet integration ensures isolation.


// Module: databricks
// Purpose: Deploys private Databricks workspace integrated with VNet subnets and private endpoint for browser auth.
// Notes: Managed RG name derived; custom parameters disable public IP & map NSGs. Private endpoint DNS zones drawn from connectivity remote state.



// Module: avm_ptn_alz_management
// Purpose: Optional ALZ management pattern (Log Analytics, Automation Account, Data Collection Rules placeholders).
// Notes: Deployed only in uksouth; most DCRs & identities disabled (toggle later). Sentinel onboarding currently null.
module "avm_ptn_alz_management" {
  count                                      = var.location == "uksouth" ? 1 : 0
  source                                     = "Azure/avm-ptn-alz-management/azurerm"
  version                                    = "0.7.0"
  enable_telemetry                           = var.enable_telemetry
  location                                   = var.location
  resource_group_creation_enabled            = false
  resource_group_name                        = module.logging_resource_group.name
  log_analytics_workspace_name               = module.naming.name.log_analytics_workspace
  automation_account_name                    = "atm-${var.location_short}-group-management-pr"
  linked_automation_account_creation_enabled = false
  sentinel_onboarding                        = null
  automation_account_sku_name                = "Basic"
  user_assigned_managed_identities = {
    "ama" = {
      name    = "uami-ama"
      enabled = false
    }
  }
  data_collection_rules = {
    change_tracking = {
      name    = "dcr-change-tracking"
      enabled = false
    }
    defender_sql = {
      name    = "dcr-defender-sql"
      enabled = false
    }
    vm_insights = {
      name    = "dcr-vm-insights"
      enabled = false
    }
  }
  tags = var.tags
}

// Resource: azurerm_monitor_private_link_scope.example
// Purpose: Restricts Azure Monitor ingestion via Private Link while leaving query access open for flexibility.
// Notes: Consider tightening query_access_mode to PrivateOnly if compliance demands. 
resource "azurerm_monitor_private_link_scope" "example" {
  name                  = module.naming.name.private_link_scope
  resource_group_name   = module.logging_resource_group.name
  ingestion_access_mode = "PrivateOnly"
  query_access_mode     = "Open"
}

// Resource: azurerm_monitor_private_link_scoped_service.example
// Purpose: Links Log Analytics workspace (via ALZ management module resource) into Private Link Scope for private ingestion.
// Notes: Resource ID sourced from management module (index 0); ensure count > 0 when location condition met.
resource "azurerm_monitor_private_link_scoped_service" "example" {
  name                = module.naming.name.private_link_scoped_service
  resource_group_name = module.logging_resource_group.name
  scope_name          = azurerm_monitor_private_link_scope.example.name
  linked_resource_id  = module.avm_ptn_alz_management[0].resource_id
}

// Module: avm-res-network-privateendpoint
// Purpose: Establishes Private Endpoint for Azure Monitor (Log Analytics, Monitor Agent, Storage) enabling private ingestion.
// Notes: DNS zones IDs sourced from connectivity remote state; NIC name prefixed for clarity. Extend subresource_names if needed.
module "avm-res-network-privateendpoint" {
  source                         = "Azure/avm-res-network-privateendpoint/azurerm"
  version                        = "0.2.0"
  name                           = module.naming.name.private_endpoint
  location                       = var.location
  resource_group_name            = module.logging_resource_group.name
  network_interface_name         = "nic-${module.naming.name.private_endpoint}"
  private_connection_resource_id = azurerm_monitor_private_link_scope.example.id
  subresource_names              = ["azuremonitor"]
  subnet_resource_id             = module.virtual_network.subnets["private_endpoints"].resource_id
  private_dns_zone_group_name    = "pls-dns"
  private_dns_zone_resource_ids = [
    data.terraform_remote_state.connectivity.outputs.dns_zones_ids[0]["azure_monitor"],
    data.terraform_remote_state.connectivity.outputs.dns_zones_ids[0]["azure_log_analytics"],
    data.terraform_remote_state.connectivity.outputs.dns_zones_ids[0]["azure_log_analytics_data"],
    data.terraform_remote_state.connectivity.outputs.dns_zones_ids[0]["azure_monitor_agent"],
    data.terraform_remote_state.connectivity.outputs.dns_zones_ids[0]["azure_storage_blob"]
  ]
}
