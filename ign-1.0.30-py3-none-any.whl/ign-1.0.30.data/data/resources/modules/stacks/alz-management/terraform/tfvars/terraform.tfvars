subscription_id              = "1e1f62ac-0120-4c72-b6a7-87eb14060fb9" // CHANGE THIS 
connectivity_subscription_id = "1e1f62ac-0120-4c72-b6a7-87eb14060fb9" // CHANGE THIS 
enable_telemetry             = false
tags = { // CHANGE THIS 
  costcentre = "EDP"
  wbscode    = "H1S00"
  owner      = "IT Networks"
  status     = "Production"
}
