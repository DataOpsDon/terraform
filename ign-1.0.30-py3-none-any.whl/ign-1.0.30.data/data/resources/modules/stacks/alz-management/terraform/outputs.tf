output "log_analytics_workspace_id" {
  description = "Id of the Log Analytics Workspace"
  value       = module.avm_ptn_alz_management[0].resource_id
}