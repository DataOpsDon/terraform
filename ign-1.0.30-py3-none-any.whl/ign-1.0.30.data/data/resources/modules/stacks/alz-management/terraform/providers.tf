// ---------------------------------------------------------------------------------------------------------------------
// Providers & Backend configuration for ALZ Management stack.
// Purpose:
//   Define AzureRM provider and remote state backend used for management plane resources (DevCenter, Databricks, Logging).
// Notes:
//   - Only AzureRM provider required (modules leverage AVM published modules).
//   - backend "azurerm": details (storage account, container, key) supplied externally via pipeline/env variables.
//   - OIDC (workload identity) authentication: avoids storing client secrets; requires federated credential on SP.
//   - Subscription ID passed as variable for portability across environments/tenants.
// ---------------------------------------------------------------------------------------------------------------------
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm" // Core Azure provider
    }
  }
  backend "azurerm" {}
}
// AzureRM provider: workload identity (OIDC) authentication.
provider "azurerm" {
  features {}                               // Enables provider feature sets (defaults)
  use_oidc            = true                // Federated identity from pipeline instead of client secret
  subscription_id     = var.subscription_id // Target subscription for management resources
  storage_use_azuread = true
}
