output "firewall_policy_id" {
  description = "The ID of the firewall policy"
  value       = module.firewall_policy.resource_id
}