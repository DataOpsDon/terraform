firewall_policy_name = "" // change this
location             = "uksouth"
resource_group_name  = "" // change this
subscription_id      = "" // change this