// ---------------------------------------------------------------------------------------------------------------------
// Azure Firewall Policy & Rule Collections Stack
// This Terraform file provisions an Azure Firewall Policy and attaches rule collection groups (network, application, NAT)
// using Azure Verified Modules (AVM). Collections are driven by input variables allowing flexible rule definition
// without modifying module blocks.
//
// Notes:
// - Policy module creates the logical container; rule collection groups are added separately for clearer lifecycle.
// - Rule definitions are sourced from CSV files in ./generate-firewall-input (e.g. NetworkFirewallRules.csv, ApplicationFirewallRules.csv, NATFirewallRules.csv)
//   which are transformed into the variable structures feeding the modules.
// - for_each loops convert the parsed CSV-derived maps into discrete module instances (network vs application vs NAT).
// - Keep CSVs minimal: one row per rule; collections/groups inferred by columns (see README/process if present).
// - NAT rule collection group currently commented out as it does NOT work.
// ---------------------------------------------------------------------------------------------------------------------

// Module: firewall_policy
// Purpose: Creates Azure Firewall Policy resource to host rule collections (network/application/NAT).
// Notes: Name, location & RG passed via variables; consider adding tags.
module "firewall_policy" {
  source              = "Azure/avm-res-network-firewallpolicy/azurerm"
  location            = var.location
  resource_group_name = var.resource_group_name
  name                = var.firewall_policy_name
}

// Module: network_rule_collection_group
// Purpose: Attaches one or more Network Rule Collection Groups (L3/L4) to the firewall policy.
// Notes: Rules populated from NetworkFirewallRules.csv via preprocessing; empty collections default when CSV absent.
module "network_rule_collection_group" {
  source                                                            = "Azure/avm-res-network-firewallpolicy/azurerm//modules/rule_collection_groups"
  firewall_policy_rule_collection_group_firewall_policy_id          = module.firewall_policy.resource.id // reference policy
  for_each                                                          = { for rcg in var.network_rule_collection_group : rcg.name => rcg }
  firewall_policy_rule_collection_group_name                        = each.value.name
  firewall_policy_rule_collection_group_priority                    = each.value.priority
  firewall_policy_rule_collection_group_network_rule_collection     = try(each.value.network_rule_collections, [])
  firewall_policy_rule_collection_group_application_rule_collection = try(each.value.application_rule_collections, [])
  firewall_policy_rule_collection_group_nat_rule_collection         = try(each.value.nat_rule_collections, [])
}

// Module: application_rule_collection_group
// Purpose: Attaches Application Rule Collections (FQDN / URL / Web categories) to the firewall policy.
// Notes: Rules populated from ApplicationFirewallRules.csv; depends on network group for ordering; priorities must not clash.
module "application_rule_collection_group" {
  source                                                            = "Azure/avm-res-network-firewallpolicy/azurerm//modules/rule_collection_groups"
  depends_on                                                        = [module.network_rule_collection_group]
  firewall_policy_rule_collection_group_firewall_policy_id          = module.firewall_policy.resource.id
  for_each                                                          = { for rcg in var.application_rule_collection_group : rcg.name => rcg }
  firewall_policy_rule_collection_group_name                        = each.value.name
  firewall_policy_rule_collection_group_priority                    = each.value.priority
  firewall_policy_rule_collection_group_network_rule_collection     = try(each.value.network_rule_collections, [])
  firewall_policy_rule_collection_group_application_rule_collection = try(each.value.application_rule_collections, [])
  firewall_policy_rule_collection_group_nat_rule_collection         = try(each.value.nat_rule_collections, [])
}

// Module: nat_rule_collection_group (Does not work)
// Purpose: (Optional) Attach NAT rule collections for DNAT scenarios (e.g., inbound published services).
// Notes: Intended to consume NATFirewallRules.csv.
# module "nat_rule_collection_group" {
#   source                                                            = "Azure/avm-res-network-firewallpolicy/azurerm//modules/rule_collection_groups"
#   depends_on                                                        = [module.application_rule_collection_group]
#   firewall_policy_rule_collection_group_firewall_policy_id          = module.firewall_policy.resource.id
#   for_each                                                          = { for rcg in var.nat_rule_collection_group : rcg.name => rcg }
#   firewall_policy_rule_collection_group_name                        = each.value.name
#   firewall_policy_rule_collection_group_priority                    = each.value.priority
#   firewall_policy_rule_collection_group_network_rule_collection     = []
#   firewall_policy_rule_collection_group_application_rule_collection = []
#   firewall_policy_rule_collection_group_nat_rule_collection         = try(each.value.nat_rule_collections, [])
# }