variable "subscription_id" {
  description = "The subscription ID to use for the AzureRM provider."
  type        = string
}

// general variables
variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "uksouth"
}

variable "resource_group_name" {
  description = "Resource group for deployment"
  type        = string
}

// fw policy variables
variable "firewall_policy_name" {
  description = "Resource group for deployment"
  type        = string
}

// fw rule collection variables
variable "application_rule_collection_group" {
  type = list(object({
    name                         = string
    priority                     = number
    network_rule_collections     = optional(list(any))
    application_rule_collections = optional(list(any))
    nat_rule_collections         = optional(list(any))
  }))
}

// fw rule collection variables
variable "network_rule_collection_group" {
  type = list(object({
    name                         = string
    priority                     = number
    network_rule_collections     = optional(list(any))
    application_rule_collections = optional(list(any))
    nat_rule_collections         = optional(list(any))
  }))
}

# // fw rule collection variables
# variable "nat_rule_collection_group" {
#   type = list(object({
#     name                         = string
#     priority                     = number
#     network_rule_collections     = optional(list(any))
#     application_rule_collections = optional(list(any))
#     nat_rule_collections         = optional(list(any))
#   }))
# }
