<#
.SYNOPSIS
  Converts an application firewall rules CSV into Terraform-compatible tfvars (Azure Firewall Policy).

.DESCRIPTION
  - Parses application rules from a structured CSV file
  - Organises them into Rule Collection Groups and Application Rule Collections
  - Outputs HCL .tfvars with correct array shapes and field names (rule, not rules)
  - Handles FQDNs and URLs (extracts host from URLs)
  - Pairs application protocols with ports into { port, type } blocks
  - Emits empty arrays for optional fields to satisfy strict module schemas

.PARAMETER CsvPath
  Path to the input CSV containing application rules.

.PARAMETER OutputPath
  Optional path to write the resulting .tfvars. Defaults to ../terraform/terraform.application.tfvars

.EXAMPLE
  .\convertApplicationFirewallRules.ps1 -CsvPath ".\ApplicationFirewallRules.csv"
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory)]
  [string]$CsvPath,
  [string]$OutputPath
)

# --- Helpers --------------------------------------------------------------------------------------------------------

function Split-List {
  param([AllowNull()][string]$Value)
  if ([string]::IsNullOrWhiteSpace($Value)) { return @() }
  $items = $Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
  return @($items | Select-Object -Unique)  # force array, even for 1 item
}

function Normalize-AppProtocol {
  param([string]$p)
  if ([string]::IsNullOrWhiteSpace($p)) { return $null }

  $clean = $p.Trim().ToUpper()

  switch ($clean) {
    'HTTP'  { return 'Http' }
    'HTTPS' { return 'Https' }
    'MSSQL' { return 'Mssql' }
    default {
      Write-Warning "Unrecognised protocol type '$p'. Treated as '$clean'"
      return $clean
    }
  }
}

function Get-Int {
  param([string]$s, [string]$fieldName = 'number')
  $out = 0
  if ([int]::TryParse($s, [ref]$out)) { return $out }
  Write-Warning "Expected integer in '$fieldName' but got '$s'. Defaulting to 0."
  return 0
}

function Extract-Hostname {
  param([string]$value)
  if ([string]::IsNullOrWhiteSpace($value)) { return $null }
  # If it looks like a URL, parse it and return the host; otherwise return as-is
  $v = $value.Trim()
  try {
    # Add a scheme if missing, to help the URI parser
    if ($v -notmatch '^[a-z][a-z0-9+\-.]*://') {
      $dummy = "http://$v"
      $u = [Uri]::new($dummy, [System.UriKind]::Absolute)
      if ($u.Host) { return $u.Host }
    } else {
      $u = [Uri]::new($v, [System.UriKind]::Absolute)
      if ($u.Host) { return $u.Host }
    }
  } catch {
    # fall through
  }
  return $v
}

function Build-ProtocolBlock {
  param(
    [string]$proto,
    [int]$port
  )
  $type = Normalize-AppProtocol $proto
  if (-not $DefaultPortByType.ContainsKey($type)) {
    Write-Warning "Unrecognised protocol type '$proto'. Using type = '$type', port = $port"
  }
  return [ordered]@{ port = $port; type = $type }
}

# Default ports for known app protocols
$DefaultPortByType = @{
  'Http'  = 80
  'Https' = 443
  'Mssql' = 1433
}

# --- Load & validate CSV --------------------------------------------------------------------------------------------

if (-not (Test-Path -LiteralPath $CsvPath)) {
  throw "CSV not found: $CsvPath"
}

$rows = Import-Csv -LiteralPath $CsvPath
if (-not $rows -or $rows.Count -eq 0) {
  throw "CSV appears empty: $CsvPath"
}

$required = @(
  'RuleCollectionGroup','RuleCollectionGroupPriority',
  'RuleCollectionName','RuleCollectionPriority','RuleCollectionAction',
  'RuleType','RuleName','SourceType','Source','Protocols','DestinationType','Destination'
)
$missing = $required | Where-Object { -not ($rows[0].PSObject.Properties.Name -contains $_) }
if ($missing) {
  throw "Missing required columns: $($missing -join ', ')"
}

# --- Build: Group -> Application Collection -> Rules ----------------------------------------------------------------

$groups = @{}

foreach ($row in $rows) {
  # Only application rules
  if ($row.RuleType -and $row.RuleType -ne 'ApplicationRule') { continue }

  $groupName  = $row.RuleCollectionGroup
  $groupPrio  = Get-Int -s $row.RuleCollectionGroupPriority -fieldName 'RuleCollectionGroupPriority'
  $collName   = $row.RuleCollectionName
  $collPrio   = Get-Int -s $row.RuleCollectionPriority -fieldName 'RuleCollectionPriority'
  $collAction = $row.RuleCollectionAction

  if ([string]::IsNullOrWhiteSpace($groupName)) { Write-Warning "Row missing RuleCollectionGroup. Skipping."; continue }
  if ([string]::IsNullOrWhiteSpace($collName))  { Write-Warning "Row missing RuleCollectionName. Skipping.";  continue }
  if ([string]::IsNullOrWhiteSpace($collAction)){ Write-Warning "Row missing RuleCollectionAction. Skipping."; continue }
  if ([string]::IsNullOrWhiteSpace($row.RuleName)) { Write-Warning "Row missing RuleName. Skipping."; continue }

  if (-not $groups.ContainsKey($groupName)) {
    $groups[$groupName] = [ordered]@{
      name                           = $groupName
      priority                       = $groupPrio
      application_rule_collections   = @{} # keyed by collection name
    }
  } else {
    if ($groups[$groupName].priority -ne $groupPrio) {
      Write-Warning "Inconsistent priority for group '$groupName'. Using first seen: $($groups[$groupName].priority), saw: $groupPrio"
    }
  }

  $collections = $groups[$groupName].application_rule_collections
  if (-not $collections.ContainsKey($collName)) {
    $collections[$collName] = [ordered]@{
      name     = $collName
      priority = $collPrio
      action   = $collAction
      rule     = @()  # note: 'rule', not 'rules'
    }
  } else {
    if ($collections[$collName].priority -ne $collPrio) {
      Write-Warning "Inconsistent priority for collection '$collName'. Using first seen: $($collections[$collName].priority), saw: $collPrio"
    }
    if ($collections[$collName].action -ne $collAction) {
      Write-Warning "Inconsistent action for collection '$collName'. Using first seen: $($collections[$collName].action), saw: $collAction"
    }
  }

  # Sources
  $srcList = Split-List -Value $row.Source
  $source = [ordered]@{
    source_addresses = @()
    source_ip_groups = @()
  }
  switch ($row.SourceType) {
    'SourceAddresses'  { $source.source_addresses = $srcList }
    'SourceIpAddress'  { $source.source_addresses = $srcList }
    'SourceIpGroups'   { $source.source_ip_groups = $srcList }
    default {
      Write-Warning "Unknown SourceType '$($row.SourceType)' for rule '$($row.RuleName)'. Treating as addresses."
      $source.source_addresses = $srcList
    }
  }

  # Destinations (FQDNs or URLs -> FQDNs)
  $dstListRaw = Split-List -Value $row.Destination
  $dstFqdns = @()
  foreach ($d in $dstListRaw) {
    $hostname = Extract-Hostname -value $d
    if ($hostname) { $dstFqdns += $hostname }
  }
  $dstFqdns = $dstFqdns | Select-Object -Unique

  # Destination ports (optional for app rules, but we’ll use to pair with protocols if provided)
  $destPortsRaw = Split-List -Value $row.DestinationPorts
  $destPorts = @()
  foreach ($p in $destPortsRaw) {
    $pi = 0
    if ([int]::TryParse($p, [ref]$pi)) {
      $destPorts += $pi
    } elseif ($p -eq '*') {
      $destPorts += '*'
    } else {
      Write-Warning "Non-numeric DestinationPort '$p' in rule '$($row.RuleName)'. Skipping this port."
    }
  }

  # Protocols (pair with ports => [{ port=int, type="Http" }])
 $protoNames = @(
  Split-List -Value $row.Protocols |
  ForEach-Object { Normalize-AppProtocol $_ } |
  Where-Object { $_ }
)

  $protocolBlocks = @()

# Pairing logic:
# - If counts match, pair by index.
# - If 1 port and many protocols, reuse the single port.
# - If no ports, use default per protocol (if known), else 0 with warning.
# - If extra ports beyond protocols, pair what we can and warn.
if ($destPorts.Count -gt 0) {
  if ($destPorts.Count -eq $protoNames.Count) {
    for ($i = 0; $i -lt $protoNames.Count; $i++) {
      $protocolBlocks += Build-ProtocolBlock $protoNames[$i] $destPorts[$i]
    }
  } elseif ($destPorts.Count -eq 1 -and $protoNames.Count -gt 1) {
    $portVal = $destPorts[0]
    if ($portVal -eq '*') {
      foreach ($t in $protoNames) {
        $portResolved = $DefaultPortByType[$(Normalize-AppProtocol $t)]
        if (-not $portResolved) { Write-Warning "No default port for protocol '$t' in rule '$($row.RuleName)'. Using 0."; $portResolved = 0 }
        $protocolBlocks += Build-ProtocolBlock $t $portResolved
      }
    } else {
      foreach ($t in $protoNames) {
        $protocolBlocks += Build-ProtocolBlock $t $portVal
      }
    }
  } else {
    $min = [Math]::Min($destPorts.Count, $protoNames.Count)
    for ($i = 0; $i -lt $min; $i++) {
      $protocolBlocks += Build-ProtocolBlock $protoNames[$i] $destPorts[$i]
    }
    if ($protoNames.Count -gt $destPorts.Count) {
      for ($i = $min; $i -lt $protoNames.Count; $i++) {
        $t = $protoNames[$i]
        $portResolved = $DefaultPortByType[$(Normalize-AppProtocol $t)]
        if (-not $portResolved) { Write-Warning "Missing port for protocol '$t' in rule '$($row.RuleName)'. Using 0."; $portResolved = 0 }
        $protocolBlocks += Build-ProtocolBlock $t $portResolved
      }
    } elseif ($destPorts.Count -gt $protoNames.Count) {
      Write-Warning "More ports than protocols in rule '$($row.RuleName)'. Extra ports will be ignored."
    }
  }
} else {
  foreach ($t in $protoNames) {
    $portResolved = $DefaultPortByType[$(Normalize-AppProtocol $t)]
    if (-not $portResolved) { Write-Warning "No port provided for protocol '$t' in rule '$($row.RuleName)'. Using 0."; $portResolved = 0 }
    $protocolBlocks += Build-ProtocolBlock $t $portResolved
  }
}

  # Compose rule object
  $rule = [ordered]@{
    name               = $row.RuleName
    source_addresses   = @( $source.source_addresses | ForEach-Object { "$_" } )
    source_ip_groups   = @( $source.source_ip_groups | ForEach-Object { "$_" } )
    destination_fqdns  = @( $dstFqdns | ForEach-Object { "$_" } )
    destination_ports  = @( $destPorts | ForEach-Object { $_.ToString() } ) # keep for visibility; protocols carry typed port too
    protocols          = @()
  }
  # Ensure protocols array present (even if empty — but it shouldn't be)
  $rule.protocols = @()
  foreach ($pb in $protocolBlocks) {
    $rule.protocols += ,([ordered]@{
      port = [int]$pb.port
      type = $pb.type
    })
  }

  # Attach rule
  $collections[$collName].rule += ,$rule
}

# Finalise: convert collection maps to arrays and sort by priority
$groupArray = @()
foreach ($g in $groups.Values) {
  $collArray = $g.application_rule_collections.Values | Sort-Object priority
  $g.application_rule_collections = $collArray
  # Force HCL list brackets for application_rule_collections
  $g.application_rule_collections = @($g.application_rule_collections)
  $groupArray += ,$g
}
$groupArray = $groupArray | Sort-Object priority

# --- Convert to HCL --------------------------------------------------------------------------------------------------

function ConvertTo-HCL {
  param(
    $value,
    [int]$indent = 0
  )

  $prefix = ' ' * $indent

  if ($value -is [System.Collections.IDictionary] -or $value -is [Hashtable]) {
    $items = $value.GetEnumerator() | Sort-Object Name
    $body = ($items | ForEach-Object {
      $key = $_.Key
      $val = ConvertTo-HCL $_.Value ($indent + 2)
      "$prefix  $key = $val"
    }) -join "`n"
    return "{`n$body`n$prefix}"
  }
  elseif ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
    # Coerce to array for .Count safety
    $arr = @()
    foreach ($i in $value) { $arr += ,$i }
    if ($arr.Count -eq 0) { return "[]" }
    $lines = $arr | ForEach-Object {
      $val = ConvertTo-HCL $_ ($indent + 2)
      "$prefix  $val"
    }
    return "[`n" + ($lines -join ",`n") + "`n$prefix]"
  }
  elseif ($value -is [string]) {
    return "`"$value`""
  }
  elseif ($value -is [int] -or $value -is [long] -or $value -is [double] -or $value -is [decimal]) {
    return $value.ToString()
  }
  elseif ($null -eq $value) {
    return "null"
  }
  else {
    return $value.ToString()
  }
}

# --- Output ----------------------------------------------------------------------------------------------------------

if (-not $OutputPath) {
  $tfFolder = Resolve-Path (Join-Path $PSScriptRoot '..\..\terraform')
  $OutputPath = Join-Path $tfFolder 'application-rules.tfvars' # need to change this output
}

$hclBody = "application_rule_collection_group = " + (ConvertTo-HCL @($groupArray))
New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
Set-Content -LiteralPath $OutputPath -Value $hclBody -Encoding UTF8

Write-Host "Application HCL tfvars file written to:" -ForegroundColor Green
Write-Host "$OutputPath" -ForegroundColor Cyan