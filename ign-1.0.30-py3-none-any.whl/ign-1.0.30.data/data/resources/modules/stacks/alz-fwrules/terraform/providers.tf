// ---------------------------------------------------------------------------------------------------------------------
// Providers & Backend configuration for ALZ Firewall Rules stack.
// Purpose:
//   Define required provider(s) and remote state backend used to store the rule collection state.
// Notes:
//   - Only AzureRM provider required (rule collections attach to existing Firewall Policy via remote state outputs).
//   - backend "azurerm": configured externally (storage account/container, key) via environment or pipeline vars.
//   - OIDC (workload identity) used for CI/CD; avoids client secret distribution.
//   - Subscription passed as variable to keep this stack portable across environments.
// ---------------------------------------------------------------------------------------------------------------------
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm" // Core Azure provider
    }
  }
  backend "azurerm" {} // Remote state backend (Azure Storage)
}

// AzureRM provider: workload identity (OIDC) authentication.
provider "azurerm" {
  features {}
  use_oidc            = true                // Enables federated credentials in pipeline (no service principal secret)
  subscription_id     = var.subscription_id // Target subscription for rule resources
  storage_use_azuread = true
}
