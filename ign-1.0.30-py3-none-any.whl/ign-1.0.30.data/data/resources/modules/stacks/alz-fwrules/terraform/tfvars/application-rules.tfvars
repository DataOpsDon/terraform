application_rule_collection_group = [
  {
    name     = "DefaultApplicationRuleCollectionGroup"
    priority = 200
    # application_rule_collections = []
  }
]
