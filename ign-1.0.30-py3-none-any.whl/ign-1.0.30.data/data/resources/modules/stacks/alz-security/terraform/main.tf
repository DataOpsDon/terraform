// ---------------------------------------------------------------------------------------------------------------------
// ALZ Security Stack - Security Operations & Monitoring Components
// This Terraform file deploys the security subscription infrastructure including SIEM, threat protection,
// and security operations components using Azure Verified Modules (AVM) pattern + resource modules.
//
// Notes:
// - Naming centralised via `naming` for consistent resource names across security assets.
// - Microsoft Sentinel for SIEM and security orchestration with data connectors and analytics rules.
// - Log Analytics workspace optimized for security data ingestion and retention.
// - Key Vault for security secrets, certificates, and encryption key management.
// - Virtual network with dedicated subnets for security tools, management, and private endpoints.
// - Storage accounts for security data retention, threat intelligence, and forensic analysis.
// - Application Security Groups for micro-segmentation of security workloads.
// - Private DNS zones for secure service connectivity.
// ---------------------------------------------------------------------------------------------------------------------

// Module: naming
// Purpose: Provides consistent base naming primitives used across security resources.
// Notes: Values are currently static for this stack; adjust if introducing environment-driven variability.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = "lz"
  lz       = "sec"      // Security landing zone code
  suffix   = "prd"      // Suffix distinguishes security assets
  lz_short = "security" // Short descriptor for security
}

// Module: resource_group
// Purpose: Resource group for all security components (Sentinel, Log Analytics, Key Vault, security tools, NSGs).
// Notes: Consider enabling lock if required for production environments
module "resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = module.naming.name.resource_group
  //lock             = local.rg_no_delete_lock 
  tags = var.tags
}

// Module: security_services_nsg
// Purpose: Network Security Group for security services subnet with security-specific rules
// Notes: Includes rules for security services communication, monitoring, and log collection
module "security_services_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-s1s00-security-services"
  security_rules      = local.security_services_rules
  tags                = var.tags
}

// Module: monitoring_nsg  
// Purpose: Network Security Group for monitoring infrastructure subnet
// Notes: Allows monitoring agent communication and security tool access
module "monitoring_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-s1s00-security-monitoring"
  security_rules      = local.monitoring_rules
  tags                = var.tags
}

// Module: management_nsg
// Purpose: Network Security Group for management subnet (analysts, incident response)
// Notes: Restricts access to management tools and administrative systems
module "management_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-s1s00-security-mgmt"
  security_rules      = local.management_rules
  tags                = var.tags
}

// Module: private_endpoints_nsg
// Purpose: Network Security Group applied to private endpoint subnet
// Notes: Allows traffic for private endpoints while maintaining security
module "private_endpoints_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-s1s00-security-pep"
  security_rules      = local.private_endpoint_rules
  tags                = var.tags
}

// Module: route_table_security_services
// Purpose: Route table for security services subnet with routes to hub network and threat intel feeds
// Notes: Enables proper routing for security data collection and analysis
module "route_table_security_services" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-s1s00-security-services"
  bgp_route_propagation_enabled = true
  routes                        = {}
  tags                          = var.tags
}

// Module: route_table_monitoring
// Purpose: Route table for monitoring infrastructure subnet
// Notes: Routes for monitoring agents and security analytics tools
module "route_table_monitoring" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-s1s00-security-monitoring"
  bgp_route_propagation_enabled = true
  routes                        = {}
  tags                          = var.tags
}

// Module: route_table_management
// Purpose: Route table for management subnet
// Notes: Routes for SOC analyst workstations and incident response tools
module "route_table_management" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-s1s00-security-mgmt"
  bgp_route_propagation_enabled = true
  routes                        = {}
  tags                          = var.tags
}

// Module: route_table_private_endpoints
// Purpose: Route table for private endpoint subnet
// Notes: Routes for private endpoint connectivity
module "route_table_private_endpoints" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-s1s00-security-pep"
  bgp_route_propagation_enabled = false
  routes                        = var.private_endpoint_routes
  tags                          = var.tags
}

// Module: security_virtual_network
// Purpose: Deploys security virtual network with subnets for security tools, management, and private endpoints
// Notes: Subnet CIDRs sourced from locals for consistency. Network optimized for security data flow.
module "security_virtual_network" {
  parent_id        = module.resource_group.resource_id
  source           = "Azure/avm-res-network-virtualnetwork/azurerm"
  version          = "0.15.0"
  enable_telemetry = var.enable_telemetry
  name             = module.naming.name.virtual_network
  address_space    = [var.vnet_address_space]
  location         = var.location
  dns_servers = {
    dns_servers = var.dns_servers
  }

  subnets = {
    security_services = {
      name                                      = "snet-${var.location_short}-edp-s1s00-security-services"
      address_prefixes                          = [local.subnet_ranges.security_services]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.security_services_nsg.resource_id
      }
      route_table = {
        id = module.route_table_security_services.resource_id
      }
    }
    monitoring = {
      name                                      = "snet-${var.location_short}-edp-s1s00-security-monitoring"
      address_prefixes                          = [local.subnet_ranges.monitoring]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.monitoring_nsg.resource_id
      }
      route_table = {
        id = module.route_table_monitoring.resource_id
      }
    }
    private_endpoints = {
      name                                      = "snet-${var.location_short}-edp-s1s00-security-pep"
      address_prefixes                          = [local.subnet_ranges.private_endpoints]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.private_endpoints_nsg.resource_id
      }
      route_table = {
        id = module.route_table_private_endpoints.resource_id
      }
    }
    management = {
      name                                      = "snet-${var.location_short}-edp-s1s00-security-mgmt"
      address_prefixes                          = [local.subnet_ranges.management]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.management_nsg.resource_id
      }
      route_table = {
        id = module.route_table_management.resource_id
      }
    }
  }

  tags = var.tags
}

// Module: log_analytics_workspace
// Purpose: Centralized logging workspace optimized for security data ingestion and Sentinel
// Notes: High retention and capacity for security logs. Foundation for Sentinel deployment.
module "log_analytics_workspace" {
  source              = "Azure/avm-res-operationalinsights-workspace/azurerm"
  version             = "0.4.2"
  name                = module.naming.name.log_analytics_workspace
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Workspace configuration optimized for security
  sku               = "PerGB2018"
  retention_in_days = 730 # 2 years for security compliance
  daily_quota_gb    = 100 # Higher capacity for security logs

  # Security features
  internet_ingestion_enabled = false
  internet_query_enabled     = false

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: microsoft_sentinel
// Purpose: Microsoft Sentinel SIEM for security monitoring, threat detection, and incident response
// Notes: Connected to Log Analytics workspace with data connectors and analytics rules
resource "azurerm_sentinel_log_analytics_workspace_onboarding" "sentinel" {
  workspace_id                 = module.log_analytics_workspace.resource_id
  customer_managed_key_enabled = false
}

// Data connectors for Sentinel - Core Microsoft Services
resource "azurerm_sentinel_data_connector_azure_active_directory" "aad_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_security_center" "asc_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_microsoft_cloud_app_security" "mcas_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_microsoft_defender_advanced_threat_protection" "mdatp_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_office_365" "office365_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  exchange_enabled           = true
  sharepoint_enabled         = true
  teams_enabled              = true
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_threat_intelligence" "threat_intel_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

// Data connectors for Azure Infrastructure Services
resource "azurerm_sentinel_data_connector_aws_cloud_trail" "aws_connector" {
  count                      = var.enable_aws_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  aws_role_arn               = var.aws_role_arn
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

// Azure service data connectors - these automatically pull logs from Azure services
resource "azurerm_sentinel_data_connector_azure_firewall" "firewall_connector" {
  count                      = var.enable_firewall_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_key_vault" "keyvault_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_kubernetes_service" "aks_connector" {
  count                      = var.enable_aks_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_sql_database" "sql_connector" {
  count                      = var.enable_sql_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_storage_account" "storage_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_application_gateway" "appgw_connector" {
  count                      = var.enable_appgw_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_network_security_group" "nsg_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_virtual_network" "vnet_connector" {
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_web_application_firewall" "waf_connector" {
  count                      = var.enable_waf_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_load_balancer" "lb_connector" {
  count                      = var.enable_lb_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_logic_apps_management" "logicapps_connector" {
  count                      = var.enable_logicapps_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

resource "azurerm_sentinel_data_connector_azure_service_fabric" "servicefabric_connector" {
  count                      = var.enable_servicefabric_connector ? 1 : 0
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id
  depends_on                 = [azurerm_sentinel_log_analytics_workspace_onboarding.sentinel]
}

// Diagnostic settings for Azure services to send logs to Sentinel
resource "azurerm_monitor_diagnostic_setting" "key_vault_diagnostics" {
  name                       = "sentinel-keyvault-diagnostics"
  target_resource_id         = module.key_vault.resource_id
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "AuditEvent"
  }

  enabled_log {
    category = "AzurePolicyEvaluationDetails"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "storage_diagnostics" {
  name                       = "sentinel-storage-diagnostics"
  target_resource_id         = module.security_storage_account.resource_id
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "StorageRead"
  }

  enabled_log {
    category = "StorageWrite"
  }

  enabled_log {
    category = "StorageDelete"
  }

  metric {
    category = "Transaction"
    enabled  = true
  }

  metric {
    category = "Capacity"
    enabled  = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "vnet_diagnostics" {
  name                       = "sentinel-vnet-diagnostics"
  target_resource_id         = module.security_virtual_network.resource_id
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "VMProtectionAlerts"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "nsg_diagnostics" {
  for_each = {
    "security_services" = module.security_services_nsg.resource_id
    "monitoring"        = module.monitoring_nsg.resource_id
    "management"        = module.management_nsg.resource_id
    "private_endpoints" = module.private_endpoints_nsg.resource_id
  }
  name                       = "sentinel-nsg-${each.key}-diagnostics"
  target_resource_id         = each.value
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "NetworkSecurityGroupEvent"
  }

  enabled_log {
    category = "NetworkSecurityGroupRuleCounter"
  }
}

// Azure Activity Log diagnostics (subscription-level)
resource "azurerm_monitor_diagnostic_setting" "activity_log" {
  name                       = "sentinel-activity-log-diagnostics"
  target_resource_id         = "/subscriptions/${data.azurerm_client_config.current.subscription_id}"
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "Administrative"
  }

  enabled_log {
    category = "Security"
  }

  enabled_log {
    category = "ServiceHealth"
  }

  enabled_log {
    category = "Alert"
  }

  enabled_log {
    category = "Recommendation"
  }

  enabled_log {
    category = "Policy"
  }

  enabled_log {
    category = "Autoscale"
  }

  enabled_log {
    category = "ResourceHealth"
  }
}

// Azure Firewall diagnostics (optional - requires existing firewall)
resource "azurerm_monitor_diagnostic_setting" "firewall_diagnostics" {
  count                      = var.enable_firewall_diagnostics ? 1 : 0
  name                       = "sentinel-firewall-diagnostics"
  target_resource_id         = var.firewall_resource_id
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "AzureFirewallApplicationRule"
  }

  enabled_log {
    category = "AzureFirewallNetworkRule"
  }

  enabled_log {
    category = "AzureFirewallDnsProxy"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

// Recovery Services Vault diagnostics
resource "azurerm_monitor_diagnostic_setting" "recovery_vault_diagnostics" {
  name                       = "sentinel-recovery-vault-diagnostics"
  target_resource_id         = module.recovery_services_vault.resource_id
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category = "CoreAzureBackup"
  }

  enabled_log {
    category = "AddonAzureBackupJobs"
  }

  enabled_log {
    category = "AddonAzureBackupAlerts"
  }

  enabled_log {
    category = "AddonAzureBackupPolicy"
  }

  enabled_log {
    category = "AddonAzureBackupStorage"
  }

  enabled_log {
    category = "AddonAzureBackupProtectedInstance"
  }
}

// Network Watcher diagnostics
resource "azurerm_monitor_diagnostic_setting" "network_watcher_diagnostics" {
  name                       = "sentinel-network-watcher-diagnostics"
  target_resource_id         = azurerm_network_watcher.security_network_watcher.id
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

// Module: key_vault
// Purpose: Azure Key Vault for storing security secrets, certificates, and encryption keys
// Notes: Private endpoint enabled for secure access. RBAC enabled for modern access control.
module "key_vault" {
  source              = "Azure/avm-res-keyvault-vault/azurerm"
  version             = "0.10.2"
  name                = module.naming.name.key_vault
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = "premium"

  # Security configuration
  purge_protection_enabled      = true
  soft_delete_retention_days    = 90
  public_network_access_enabled = false
  enable_rbac_authorization     = true

  # Network configuration
  network_acls = {
    default_action = "Deny"
    bypass         = "AzureServices"
  }

  # Private endpoint configuration
  private_endpoints = {
    key_vault_pe = {
      name                          = "pe-${module.naming.name.key_vault}"
      subnet_resource_id            = module.security_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = [module.private_dns_zone_keyvault.resource_id]
      private_service_connection = {
        name                           = "psc-${module.naming.name.key_vault}"
        private_connection_resource_id = null
        subresource_names              = ["vault"]
      }
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: recovery_services_vault
// Purpose: Recovery Services Vault for backup and disaster recovery of security infrastructure
// Notes: Geo-redundant storage for cross-region protection. Critical for security tool continuity.
module "recovery_services_vault" {
  source              = "Azure/avm-res-recoveryservices-vault/azurerm"
  version             = "0.3.2"
  name                = module.naming.name.recovery_services_vault
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Vault configuration
  sku                   = "Standard"
  storage_mode_type     = "GeoRedundant"
  cross_region_restore  = true
  soft_delete_enabled   = true
  public_network_access = "Disabled"

  # Identity configuration for encryption
  identity = {
    type = "SystemAssigned"
  }

  # VM backup policy for security tools
  backup_policies = {
    daily_security_vm_policy = {
      name     = "daily-security-tools-backup"
      type     = "V2"
      timezone = "UTC"
      backup = {
        frequency = "Daily"
        time      = "01:00" # Earlier backup for security tools
      }
      retention_daily = {
        count = 60 # Longer retention for security compliance
      }
      retention_weekly = {
        count    = 24
        weekdays = ["Sunday"]
      }
      retention_monthly = {
        count    = 24
        weekdays = ["Sunday"]
        weeks    = ["First"]
      }
      retention_yearly = {
        count    = 7
        weekdays = ["Sunday"]
        weeks    = ["First"]
        months   = ["January"]
      }
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: network_watcher
// Purpose: Network Watcher for network security monitoring and traffic analysis
// Notes: Enables flow logs, connection monitoring, and network diagnostics
resource "azurerm_network_watcher" "security_network_watcher" {
  name                = "nw-${var.location_short}-edp-s1s00-security"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

// Module: defender_for_cloud
// Purpose: Microsoft Defender for Cloud configuration for enhanced threat protection
// Notes: Enables advanced security features across subscriptions
resource "azurerm_security_center_subscription_pricing" "defender_servers" {
  tier          = "Standard"
  resource_type = "VirtualMachines"
}

resource "azurerm_security_center_subscription_pricing" "defender_storage" {
  tier          = "Standard"
  resource_type = "StorageAccounts"
}

resource "azurerm_security_center_subscription_pricing" "defender_keyvault" {
  tier          = "Standard"
  resource_type = "KeyVaults"
}


// Module: security_storage_account
// Purpose: Primary storage account for security logs, threat intelligence, and forensic data
// Notes: High-security configuration with immutable storage for compliance
module "security_storage_account" {
  source              = "Azure/avm-res-storage-storageaccount/azurerm"
  version             = "0.6.4"
  name                = module.naming.name.storage_account
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Storage configuration optimized for security data
  account_tier                  = "Standard"
  account_replication_type      = "RAGRS" # Read-access geo-redundant for availability
  public_network_access_enabled = false
  shared_access_key_enabled     = true

  # Security features
  blob_properties = {
    versioning_enabled = true
    delete_retention_policy = {
      days = 365 # 1 year retention for security compliance
    }
    container_delete_retention_policy = {
      days = 365
    }
  }

  # Network security
  network_rules = {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }

  # Private endpoint for secure access
  private_endpoints = {
    storage_pe = {
      name                          = "pe-${module.naming.name.storage_account}"
      subnet_resource_id            = module.security_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = [module.private_dns_zone_storage.resource_id]
      private_service_connection = {
        name                           = "psc-${module.naming.name.storage_account}"
        private_connection_resource_id = null
        subresource_names              = ["blob"]
      }
    }
  }

  # Containers for different security data types
  containers = {
    security_logs = {
      name = "security-logs"
    }
    threat_intelligence = {
      name = "threat-intelligence"
    }
    forensic_data = {
      name = "forensic-data"
    }
    incident_response = {
      name = "incident-response"
    }
    playbooks = {
      name = "playbooks"
    }
    backup = {
      name = "backup"
    }
    diagnostics = {
      name = "diagnostics"
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: application_security_groups
// Purpose: Application Security Groups for micro-segmentation of security workloads
// Notes: Used in NSG rules for more granular traffic control based on security roles
resource "azurerm_application_security_group" "sentinel_collectors" {
  name                = "asg-${var.location_short}-edp-s1s00-security-sentinel"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "soc_analysts" {
  name                = "asg-${var.location_short}-edp-s1s00-security-soc"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "threat_hunters" {
  name                = "asg-${var.location_short}-edp-s1s00-security-hunt"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

// Module: evidence_storage_account
// Purpose: Dedicated storage account for security evidence, forensics, and long-term retention
// Notes: Immutable storage with legal hold capabilities for compliance and forensics
module "evidence_storage_account" {
  source              = "Azure/avm-res-storage-storageaccount/azurerm"
  version             = "0.6.4"
  name                = "${module.naming.name.storage_account}ev"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Storage configuration for evidence retention
  account_tier                  = var.storage_account_tier
  account_replication_type      = var.storage_replication_type
  public_network_access_enabled = false
  shared_access_key_enabled     = true

  # Security configuration
  network_rules = {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }

  # Private endpoint for secure access
  private_endpoints = {
    evidence_storage_pe = {
      name                          = "pe-${module.naming.name.storage_account}ev"
      subnet_resource_id            = module.security_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = [module.private_dns_zone_storage.resource_id]
      private_service_connection = {
        name                           = "psc-${module.naming.name.storage_account}ev"
        private_connection_resource_id = null
        subresource_names              = ["blob"]
      }
    }
  }

  # Containers for evidence management
  containers = {
    evidence = {
      name = "evidence"
    }
    forensics = {
      name = "forensics"
    }
    compliance = {
      name = "compliance"
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: automation_account
// Purpose: Azure Automation Account for security operations, incident response, and maintenance
// Notes: Provides runbooks for security automation, response procedures, and maintenance tasks
module "automation_account" {
  count = var.enable_automation_account ? 1 : 0

  source              = "Azure/avm-res-automation-automationaccount/azurerm"
  version             = "0.2.0"
  name                = module.naming.name.automation_account
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Basic configuration
  sku_name                      = "Basic"
  public_network_access_enabled = false

  # Identity configuration
  identity = {
    type = "SystemAssigned"
  }

  # Link to Log Analytics workspace for enhanced monitoring
  linked_workspace_id = module.log_analytics_workspace.resource_id

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Resource: Virtual network peering to hub (conditional)
// Purpose: Establishes connectivity to hub network for centralized security monitoring
// Notes: Enable only if hub connectivity is required
resource "azurerm_virtual_network_peering" "security_to_hub" {
  count = var.enable_hub_peering ? 1 : 0

  name                      = "peer-${module.naming.name.virtual_network}-to-hub"
  resource_group_name       = module.resource_group.name
  virtual_network_name      = module.security_virtual_network.name
  remote_virtual_network_id = var.hub_virtual_network_id

  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = var.use_hub_gateway
}

// Module: Application Security Groups
// Purpose: Application Security Groups for micro-segmentation of security workloads
// Notes: Used in NSG rules for more granular traffic control based on security roles
resource "azurerm_application_security_group" "incident_responders" {
  name                = "asg-${var.location_short}-edp-s1s00-security-ir"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "security_tools" {
  name                = "asg-${var.location_short}-edp-s1s00-security-tools"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

// Module: private_dns_zone_storage
// Purpose: Private DNS zone for storage account private endpoints
// Notes: Enables DNS resolution for private endpoint connectivity to storage
module "private_dns_zone_storage" {
  source              = "Azure/avm-res-network-privatednszone/azurerm"
  version             = "0.3.1"
  domain_name         = "privatelink.blob.core.windows.net"
  resource_group_name = module.resource_group.name

  virtual_network_links = {
    security_vnet_link = {
      vnetlinkname = "link-${module.naming.name.virtual_network}-storage"
      vnet_id      = module.security_virtual_network.resource_id
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: private_dns_zone_keyvault
// Purpose: Private DNS zone for Key Vault private endpoints
// Notes: Enables DNS resolution for private endpoint connectivity to Key Vault
module "private_dns_zone_keyvault" {
  source              = "Azure/avm-res-network-privatednszone/azurerm"
  version             = "0.3.1"
  domain_name         = "privatelink.vaultcore.azure.net"
  resource_group_name = module.resource_group.name

  virtual_network_links = {
    security_vnet_link = {
      vnetlinkname = "link-${module.naming.name.virtual_network}-keyvault"
      vnet_id      = module.security_virtual_network.resource_id
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}


