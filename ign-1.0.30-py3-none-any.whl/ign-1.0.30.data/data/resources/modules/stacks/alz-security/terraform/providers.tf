# =============================================================================
# ALZ Security Stack - Providers & Backend Configuration
# =============================================================================
# This file configures the Terraform providers and backend for the security
# stack deployment. Uses OIDC authentication for secure pipeline execution.
# =============================================================================
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm" // Core Azure provider
    }
  }
  backend "azurerm" {} // Remote state backend
}

// AzureRM provider: workload identity (OIDC) authentication.
provider "azurerm" {
  features {}
  use_oidc            = true
  subscription_id     = var.subscription_id
  storage_use_azuread = true
}
