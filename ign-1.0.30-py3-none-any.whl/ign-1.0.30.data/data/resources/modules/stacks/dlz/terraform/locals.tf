locals {
  rg_no_delete_lock = {
    kind = "CanNotDelete"
    name = "No Delete Lock"
  }

  tags = {
    BusinessUnit     = "Group"
    Environment      = "Production"
    TechnicalContact = "IT Networks"
  }

  data_factory_git_config = {
    account_name       = "telefonicatechuki-is"
    branch_name        = "develop"
    repository_name    = "DataPlatform-DataLandingZone-Hub"
    root_folder        = "data-factory/src/data-factory"
    publishing_enabled = true
    project_name       = "Data%20and%20AI%20Framework"
    tenant_id          = data.azurerm_client_config.main.tenant_id
  }
}
