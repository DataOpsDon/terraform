// General Variables
project          = "fwk"
lz               = "hub"
enable_telemetry = true

// Deployment Location
location       = "uksouth"
location_short = "uks"

// Databricks Service Principal
// The Service Principal for the Azure Databricks enterprise application.
// - Created automatically by Microsoft at the *account level* when you enable Databricks.
// - Typically displayed in Entra ID as "AzureDatabricks" with a well-known appId (2ff8d...).
// - The value here is the **objectId** of that SPN in *your tenant*.
// ---------------------------------------------------------------------------------------------------------------------
databricks_spn_id = "075ba86e-bcca-4aa3-b8d6-2de84f09dd58"
