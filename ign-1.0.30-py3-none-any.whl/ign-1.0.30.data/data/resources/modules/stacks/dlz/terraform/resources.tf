// ---------------------------------------------------------------------------------------------------------------------
// Role Assignments (RBAC) for DLZ Platform Components
// 
// Notes:
// - Applies least-privilege RBAC for Databricks, Data Factory, Key Vault, ADLS Gen2, Log Analytics, and Resource Groups.
// ---------------------------------------------------------------------------------------------------------------------

// =====================================================================================================================
// RESOURCE GROUP
// =====================================================================================================================

// Readers: read-only access to resources
resource "azurerm_role_assignment" "rg_reader_rdr" {
  scope                = module.resource_group.resource_id
  role_definition_name = "Reader"
  principal_id         = var.datareaders_group_principal_id
}

// Engineers: read-only access to resources
resource "azurerm_role_assignment" "rg_reader_eng" {
  scope                = module.resource_group.resource_id
  role_definition_name = "Reader"
  principal_id         = var.dataengineers_group_principal_id
}

// Admins: contributor access for full management
resource "azurerm_role_assignment" "rg_contributor_adm" {
  scope                = module.resource_group.resource_id
  role_definition_name = "Contributor"
  principal_id         = var.dataadmins_group_principal_id
}

// =====================================================================================================================
// STORAGE ACCOUNT
// =====================================================================================================================

// Databricks Storage Access Connector: Unity Catalog storage access with least privilege
resource "azurerm_role_assignment" "adls_contributor_dbw_storage" {
  scope                = module.storage_account.resource_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = module.databricks.databricks_access_connector_principal_ids["storage"]
}

// Data Factory Managed Identity: contributor for pipeline integration
resource "azurerm_role_assignment" "adls_contributor_adfmai" {
  scope                = module.storage_account.resource_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = module.data_factory.resource.identity[0].principal_id
}

// Admins: contributor access for direct data operations
resource "azurerm_role_assignment" "adls_contributor_adm" {
  scope                = module.storage_account.resource_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = var.dataadmins_group_principal_id
}

// =====================================================================================================================
// DATABRICKS
// =====================================================================================================================

// Engineers: workspace contributor role
resource "azurerm_role_assignment" "dbw_contributor_eng" {
  scope                = module.databricks.resource_id
  role_definition_name = "Contributor"
  principal_id         = var.dataengineers_group_principal_id
}

// Admins: workspace contributor role
resource "azurerm_role_assignment" "dbw_contributor_adm" {
  scope                = module.databricks.resource_id
  role_definition_name = "Contributor"
  principal_id         = var.dataadmins_group_principal_id
}

// =====================================================================================================================
// KEY VAULT
// =====================================================================================================================

// Pipeline/Deployer principal: secrets officer for deployment automation
resource "azurerm_role_assignment" "kv_kvso_pl" {
  scope                = module.key_vault.resource_id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = data.azurerm_client_config.main.object_id
}

// Databricks SPN: secrets officer for workspace authentication
resource "azurerm_role_assignment" "kv_kvso_dbws" {
  scope                = module.key_vault.resource_id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = var.databricks_spn_id
}

// Admins: secrets officer role
resource "azurerm_role_assignment" "kv_kvso_adm" {
  scope                = module.key_vault.resource_id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = var.dataadmins_group_principal_id
}

// Data Factory Managed Identity: Key Vault Secrets User role
resource "azurerm_role_assignment" "kv_kvsu_adf" {
  scope                = module.key_vault.resource_id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = module.data_factory.resource.identity[0].principal_id
}


// =====================================================================================================================
// DATA FACTORY
// =====================================================================================================================

// Engineers: contributor role to author and manage pipelines
resource "azurerm_role_assignment" "adf_contributor_eng" {
  scope                = module.data_factory.resource_id
  role_definition_name = "Contributor"
  principal_id         = var.dataengineers_group_principal_id
}

// Admins: contributor role for broader management
resource "azurerm_role_assignment" "adf_contributor_adm" {
  scope                = module.data_factory.resource_id
  role_definition_name = "Contributor"
  principal_id         = var.dataadmins_group_principal_id
}

// Databricks Service Access Connector: contributor role for service-to-service authentication with ADF
resource "azurerm_role_assignment" "adf_contributor_dac_service" {
  scope                = module.data_factory.resource_id
  role_definition_name = "Data Factory Contributor"
  principal_id         = module.databricks.databricks_access_connector_principal_ids["service"]
}

// =====================================================================================================================
// LOG ANALYTICS
// =====================================================================================================================

// Admins: contributor access to manage workspace settings and queries
resource "azurerm_role_assignment" "law_contributor_adm" {
  scope                = module.log_analytics_workspace.resource_id
  role_definition_name = "Log Analytics Contributor"
  principal_id         = var.dataadmins_group_principal_id
}

// Engineers: read-only access to logs and metrics
resource "azurerm_role_assignment" "law_reader_eng" {
  scope                = module.log_analytics_workspace.resource_id
  role_definition_name = "Log Analytics Reader"
  principal_id         = var.dataengineers_group_principal_id
}
