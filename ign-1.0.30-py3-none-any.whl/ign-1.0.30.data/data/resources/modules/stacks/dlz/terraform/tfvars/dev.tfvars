// Environment
subscription_id = "d5797584-a55d-49db-99fb-43e80779a615"
environment     = "dev"

// Entra Groups
dataengineers_group_principal_id = "9f1b8c20-c59a-45f1-8a14-657e6b3a2776"
dataadmins_group_principal_id    = "706ff256-8d35-4d73-98eb-753e6f51da9e"
datareaders_group_principal_id   = "7825f76f-9fab-442d-84f0-484334cedc1f"