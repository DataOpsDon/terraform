// Environment
subscription_id = ""
environment     = "preprod"

// Entra Groups
dataengineers_group_principal_id = ""
dataadmins_group_principal_id    = ""
datareaders_group_principal_id   = ""