// =====================================================================================================================
// ENVIRONMENT & PLATFORM SECRETS
// =====================================================================================================================

// Environment name secret
resource "azurerm_key_vault_secret" "env_name" {
  name         = "EnvironmentName"
  value        = var.environment
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// DLZ Resource Group name secret
resource "azurerm_key_vault_secret" "dlz_resource_group" {
  name         = "DLZ-ResourceGroup"
  value        = module.resource_group.name
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// DLZ Subscription ID secret
resource "azurerm_key_vault_secret" "dlz_subscription" {
  name         = "DLZ-SubscriptionId"
  value        = data.azurerm_client_config.main.subscription_id
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// Data Factory name secret
resource "azurerm_key_vault_secret" "adf_name" {
  name         = "ADF-Name"
  value        = module.data_factory.name
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// =====================================================================================================================
// DATA LAKE PATH SECRETS
// =====================================================================================================================

// Bronze Data Lake path secret
resource "azurerm_key_vault_secret" "this_connection_to_data_lake_bronze" {
  name         = "ConnectionTo-BronzeDataLake"
  value        = "abfss://bronze@${module.storage_account.name}.dfs.core.windows.net/"
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// Silver Data Lake path secret
resource "azurerm_key_vault_secret" "this_connection_to_data_lake_silver" {
  name         = "ConnectionTo-SilverDataLake"
  value        = "abfss://silver@${module.storage_account.name}.dfs.core.windows.net/"
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// Gold Data Lake path secret
resource "azurerm_key_vault_secret" "this_connection_to_data_lake_gold" {
  name         = "ConnectionTo-GoldDataLake"
  value        = "abfss://gold@${module.storage_account.name}.dfs.core.windows.net/"
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}

// Landing Data Lake path secret
resource "azurerm_key_vault_secret" "this_connection_to_data_lake_landing" {
  name         = "ConnectionTo-LandingDataLake"
  value        = "abfss://landing@${module.storage_account.name}.dfs.core.windows.net/"
  key_vault_id = module.key_vault.resource_id
  depends_on   = [azurerm_role_assignment.kv_kvso_pl]
}
