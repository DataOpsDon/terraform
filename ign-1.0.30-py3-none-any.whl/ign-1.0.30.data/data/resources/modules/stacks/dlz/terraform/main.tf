// ---------------------------------------------------------------------------------------------------------------------
// Data Landing Zone (DLZ) - Core infrastructure
// This Terraform file provisions the resource group, Databricks workspace (with VNet injection),
// storage account (ADLS Gen2), Key Vault, and Data Factory for the DLZ.
//
// Notes:
// - Naming is centralised via the `naming` module to ensure consistent resource names across environments.


// Module: naming
// Purpose: Centralised naming standards for resources (location, project, environment, LZ short code).
// Notes: Maps environment -> LZ code for consistent names.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = var.project
  lz       = var.lz
  suffix   = var.environment
}

// Module: resource_group
// Purpose: Creates the DLZ resource group to contain all resources in this stack.
module "resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = "${module.naming.name.resource_group}-dlz"
  //lock           = local.rg_no_delete_lock
  tags = local.tags
}

// Module: databricks
// Purpose: Azure Databricks workspace with VNet injection and system-assigned access connector.
// Notes: premium SKU; no public IPs on nodes; VNet/subnet/NSG references via data sources; depends on RG.
module "databricks" {
  source                        = "Azure/avm-res-databricks-workspace/azurerm"
  version                       = "0.3.0"
  name                          = "${module.naming.name.databricks_workspace}-dlz"
  managed_resource_group_name   = "${module.resource_group.name}-mng"
  sku                           = "premium"
  resource_group_name           = module.resource_group.name
  location                      = var.location
  public_network_access_enabled = true // disable when using private endpoints
  enable_telemetry              = var.enable_telemetry
  tags                          = local.tags
  access_connector = {
    "storage" = {
      name                = "ac-${module.naming.name.databricks_workspace}-dlz-storage"
      resource_group_name = module.resource_group.name
      location            = var.location
      identity = {
        type = "SystemAssigned"
      }
    }
    "service" = {
      name                = "ac-${module.naming.name.databricks_workspace}-dlz-service"
      resource_group_name = module.resource_group.name
      location            = var.location
      identity = {
        type = "SystemAssigned"
      }
    }
    "ingest" = {
      name                = "ac-${module.naming.name.databricks_workspace}-dlz-ingest"
      resource_group_name = module.resource_group.name
      location            = var.location
      identity = {
        type = "SystemAssigned"
      }
    }
  }
  diagnostic_settings = {
    to_la = {
      name                  = "${module.naming.name.databricks_workspace}-dlz-diag"
      workspace_resource_id = module.log_analytics_workspace.resource_id
      log_groups            = ["allLogs"]
      metric_categories     = ["AllMetrics"]
    }
  }
  /*
  custom_parameters = {
    public_subnet_name                                   = "snet-uks-${var.project}-${module.naming.lz}-${var.environment}-dbwhost"
    private_subnet_name                                  = "snet-uks-${var.project}-${module.naming.lz}-${var.environment}-dbwcont"
    no_public_ip                                         = true
    virtual_network_id                                   = data.azurerm_virtual_network.this.id
    private_subnet_network_security_group_association_id = data.azurerm_network_security_group.host_this.id
    public_subnet_network_security_group_association_id  = data.azurerm_network_security_group.cont_this.id
  }
  */
  depends_on = [module.resource_group]
}

// Module: storage_account
// Purpose: Datalake for DLZ datasets with private endpoints only.
// Notes: HNS enabled; PEs for blob and dfs; standard containers created.
module "storage_account" {
  source                                  = "Azure/avm-res-storage-storageaccount/azurerm"
  version                                 = "0.6.4"
  name                                    = "${module.naming.name.storage_account}dlz"
  location                                = module.resource_group.resource.location
  resource_group_name                     = module.resource_group.name
  account_replication_type                = "LRS"
  public_network_access_enabled           = true // disable when using private endpoints
  shared_access_key_enabled               = true
  tags                                    = local.tags
  is_hns_enabled                          = true
  private_endpoints_manage_dns_zone_group = false
  network_rules = {
    default_action = "Allow" // disable when using private endpoints
  }
  containers = {
    landing = {
      name = "landing"
    }
    bronze = {
      name = "bronze"
    }
    silver = {
      name = "silver"
    }
    gold = {
      name = "gold"
    }
    unity_catalog = {
      name = "unity-catalog"
    }
  }
  diagnostic_settings_storage_account = {
    to_la = {
      name                  = "${module.naming.name.storage_account}dlz-diag"
      workspace_resource_id = module.log_analytics_workspace.resource_id
      log_categories        = ["allLogs"]
      metric_categories     = ["Transaction"]
    }
  }
  diagnostic_settings_blob = {
    to_la = {
      name                  = "${module.naming.name.storage_account}dlz-blob-diag"
      workspace_resource_id = module.log_analytics_workspace.resource_id
      log_categories        = ["allLogs"]
      metric_categories     = ["Transaction"]
    }
  }
  /*
  private_endpoints = {
    blob = {
      name                   = "pe-blob-${module.naming.name.storage_account}dlz"
      subnet_resource_id     = data.azurerm_subnet.dlz.id
      subresource_name       = "blob"
      network_interface_name = "nic-blob-${module.naming.name.storage_account}dlz"
    }
    dfs = {
      name                   = "pe-dfs-${module.naming.name.storage_account}dlz"
      subnet_resource_id     = data.azurerm_subnet.dlz.id
      subresource_name       = "dfs"
      network_interface_name = "nic-dfs-${module.naming.name.storage_account}dlz"
    }
  }
  */
}

// Module: key_vault
// Purpose: Key Vault for secrets with private endpoint access.
module "key_vault" {
  source                          = "Azure/avm-res-keyvault-vault/azurerm"
  version                         = "0.10.1"
  name                            = "${module.naming.name.key_vault}-dlz"
  location                        = module.resource_group.resource.location
  resource_group_name             = module.resource_group.name
  tenant_id                       = data.azurerm_client_config.main.tenant_id
  public_network_access_enabled   = true // disable when using private endpoints
  enabled_for_template_deployment = true
  tags                            = local.tags
  #private_endpoints_manage_dns_zone_group = false
  network_acls = {
    bypass         = "AzureServices"
    default_action = "Allow"
  }
  diagnostic_settings = {
    to_la = {
      name                  = "${module.naming.name.key_vault}-dlz-diag"
      workspace_resource_id = module.log_analytics_workspace.resource_id
      log_categories        = ["AuditEvent"]
      log_groups            = []
      metric_categories     = ["AllMetrics"]
    }
  }
  /*
  private_endpoints = {
    primary = {
      subnet_resource_id     = data.azurerm_subnet.dlz.id
      network_interface_name = "nic-${module.naming.name.key_vault}-dlz"
    }
  }
  */
}

// Module: log_analytics_workspace
// Purpose: Log Analytics workspace for diagnostics aggregation across DLZ resources.
// Notes: Retention set to 90 days;
module "log_analytics_workspace" {
  source                                    = "Azure/avm-res-operationalinsights-workspace/azurerm"
  version                                   = "0.4.2"
  enable_telemetry                          = var.enable_telemetry
  location                                  = var.location
  resource_group_name                       = module.resource_group.name
  name                                      = module.naming.name.log_analytics_workspace
  log_analytics_workspace_sku               = "PerGB2018"
  log_analytics_workspace_retention_in_days = 90
  tags                                      = local.tags
}

// Module: data_factory
// Purpose: Azure Data Factory with managed VNet and private endpoint.
// Notes: System-assigned identity; Git integration enabled in dev only (config in locals.tf); diagnostics to central Log Analytics.
module "data_factory" {
  source              = "Azure/avm-res-datafactory-factory/azurerm"
  version             = "0.1.0"
  name                = "${module.naming.name.data_factory}-dlz"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  /*
  private_endpoints_manage_dns_zone_group = false
  private_endpoints = {
    primary = {
      name                   = "pe-${module.naming.name.data_factory}-dlz"
      subnet_resource_id     = data.azurerm_subnet.dlz.id
      subresource_name       = "dataFactory"
      network_interface_name = "nic-${module.naming.name.data_factory}-dlz"
    }
  }
  managed_virtual_network_enabled = true
  */
  managed_identities = {
    system_assigned = true
  }
  vsts_configuration = var.environment == "dev" ? local.data_factory_git_config : null
  tags               = local.tags
  diagnostic_settings = {
    to_la = {
      name                  = "${module.naming.name.data_factory}-dlz-diag"
      workspace_resource_id = module.log_analytics_workspace.resource_id
      log_categories        = []
    }
  }
}
