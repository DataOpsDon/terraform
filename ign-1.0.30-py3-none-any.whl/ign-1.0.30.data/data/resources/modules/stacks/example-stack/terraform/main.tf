#
# Example Stack - Main Configuration
#
# This is a sample stack template showing a basic Azure deployment
# with resource group, storage account, and Key Vault.
#

# Naming module for standardized resource names
module "naming" {
  source = "../../../templates/utils"

  location = var.location
  project  = var.project
  lz       = "example"
  suffix   = var.environment
}

# Resource Group
resource "azurerm_resource_group" "main" {
  name     = module.naming.name.resource_group
  location = var.location

  tags = local.tags
}

# Storage Account
resource "azurerm_storage_account" "main" {
  name                     = module.naming.name.storage_account
  resource_group_name      = azurerm_resource_group.main.name
  location                 = azurerm_resource_group.main.location
  account_tier             = "Standard"
  account_replication_type = "LRS"

  tags = local.tags
}

# Key Vault
resource "azurerm_key_vault" "main" {
  name                = module.naming.name.key_vault
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = "standard"

  tags = local.tags
}

