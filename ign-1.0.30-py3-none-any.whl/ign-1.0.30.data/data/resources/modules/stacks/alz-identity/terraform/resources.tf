# ---------------------------------------------------------------------------------------------------------------------
# ALZ Identity Stack - Additional Resources
# This file contains standalone resources not encapsulated by AVM modules for identity infrastructure:
#   1. Active Directory diagnostic settings for security monitoring
#   2. VM extensions for domain controllers (when VMs are deployed)
#   3. Custom security policies and compliance monitoring
#   4. Resource locks for critical identity infrastructure
#
# Notes:
# - Update subscription scope and principal IDs with appropriate variables
# - Extend diagnostic settings for comprehensive AD security monitoring
# ---------------------------------------------------------------------------------------------------------------------

# Optional: Resource lock for critical identity infrastructure (uncomment if needed)
/*
resource "azurerm_management_lock" "identity_infrastructure_lock" {
  name       = "identity-infrastructure-no-delete"
  scope      = module.resource_group.resource_id
  lock_level = "CanNotDelete"
  notes      = "Prevents accidental deletion of critical identity infrastructure"
}
*/

# Optional: Activity log diagnostic settings for identity subscription (uncomment if needed)
/*
resource "azurerm_monitor_diagnostic_setting" "identity_subscription_activity_log" {
  name                       = "identity-subscription-activity-log"
  target_resource_id         = "/subscriptions/${var.subscription_id}"
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category_group = "Audit"
  }
  
  enabled_log {
    category_group = "Administrative"
  }
  
  enabled_log {
    category_group = "Security"
  }
}
*/

# Optional: Azure Security Center settings for identity subscription
/*
resource "azurerm_security_center_subscription_pricing" "identity_vm_protection" {
  tier          = "Standard"
  resource_type = "VirtualMachines"
}

resource "azurerm_security_center_subscription_pricing" "identity_key_vault_protection" {
  tier          = "Standard"
  resource_type = "KeyVaults"
}

resource "azurerm_security_center_subscription_pricing" "identity_storage_protection" {
  tier          = "Standard"
  resource_type = "StorageAccounts"
}
*/

# Optional: Role assignment for identity management (uncomment if needed)
/*
resource "azurerm_role_assignment" "identity_reader" {
  scope                = "/subscriptions/${var.subscription_id}"
  role_definition_name = "Reader"
  principal_id         = "00000000-0000-0000-0000-000000000000" # Update with actual principal ID
}
*/