# ---------------------------------------------------------------------------------------------------------------------
# ALZ Identity Stack Local Values
# Local values for consistent configuration across the identity infrastructure
# ---------------------------------------------------------------------------------------------------------------------

locals {
  # Resource Group Lock Configuration
  rg_no_delete_lock = {
    kind = "CanNotDelete"
    name = "Identity Infrastructure Protection Lock"
  }

  # Subnet Configuration for Identity Stack
  # Based on a /24 VNet, creates appropriately sized subnets for identity services
  subnet_ranges = {
    domain_controllers = cidrsubnet(var.vnet_address_space, 3, 0)                                                   # /27 - 32 IPs for domain controllers
    management         = cidrsubnet(var.vnet_address_space, 3, 1)                                                   # /27 - 32 IPs for management servers
    private_endpoints  = cidrsubnet(var.vnet_address_space, 4, 4)                                                   # /28 - 16 IPs for private endpoints
    paw_subnet         = var.enable_privileged_access_workstation ? cidrsubnet(var.vnet_address_space, 4, 5) : null # /28 - Optional PAW subnet
  }

  # Active Directory Configuration
  ad_config = {
    domain_name         = var.domain_name
    domain_netbios_name = var.domain_netbios_name
    forest_mode         = var.forest_mode
    domain_mode         = var.domain_mode
    safe_mode_password  = "P@ssw0rd123!" # Should be stored in Key Vault in production
  }

  # Domain Controller IP Configuration
  dc_config = {
    primary_dc_ip   = cidrhost(local.subnet_ranges.domain_controllers, 4) # .4 - Primary DC
    secondary_dc_ip = cidrhost(local.subnet_ranges.domain_controllers, 5) # .5 - Secondary DC
    dns_forwarders  = ["168.63.129.16", "8.8.8.8"]                        # Azure DNS + Google DNS for forwarding
  }

  # Backup Policy Settings for Domain Controllers
  backup_policy_settings = {
    timezone            = "UTC"
    backup_time         = "01:00" # Early morning backup
    backup_frequency    = "Daily"
    system_state_backup = true # Include system state for AD recovery
  }

  # NSG Rules for Active Directory Traffic
  ad_security_rules = {
    # DNS
    allow_dns_tcp = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowDNSTCP"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "53"
    }
    allow_dns_udp = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowDNSUDP"
      priority                   = 1001
      protocol                   = "Udp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "53"
    }
    # Kerberos
    allow_kerberos = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowKerberos"
      priority                   = 1010
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "88"
    }
    # LDAP
    allow_ldap = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowLDAP"
      priority                   = 1020
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["389", "636", "3268", "3269"]
    }
    # SMB for SYSVOL
    allow_smb = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowSMB"
      priority                   = 1030
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "445"
    }
    # RPC Endpoint Mapper
    allow_rpc_endpoint = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRPCEndpoint"
      priority                   = 1040
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "135"
    }
    # RPC Dynamic Ports
    allow_rpc_dynamic = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRPCDynamic"
      priority                   = 1050
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "49152-65535"
    }
    # Windows Time Service
    allow_ntp = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowNTP"
      priority                   = 1060
      protocol                   = "Udp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "123"
    }
  }

  # Key Vault Configuration for Identity Services
  key_vault_config = {
    sku_name                      = "premium"
    soft_delete_retention_days    = 90
    purge_protection_enabled      = true
    public_network_access_enabled = false
    enable_rbac_authorization     = true
  }

  # Recovery Services Vault Configuration
  recovery_vault_config = {
    sku                   = "Standard"
    storage_mode_type     = "GeoRedundant"
    cross_region_restore  = true
    soft_delete_enabled   = true
    public_network_access = "Disabled"
  }

  # Log Analytics Configuration for Identity
  log_analytics_config = {
    sku                        = "PerGB2018"
    retention_in_days          = var.log_analytics_retention_days
    daily_quota_gb             = var.log_analytics_daily_quota_gb
    internet_ingestion_enabled = false
    internet_query_enabled     = false
  }

  # Storage Account Configuration
  storage_config = {
    account_tier             = "Standard"
    account_replication_type = var.storage_account_replication_type
    access_tier              = "Cool" # Identity data accessed less frequently
  }
}
