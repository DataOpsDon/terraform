# ALZ Pattern Module Usage Guide

This guide explains how to use the Azure Landing Zone (ALZ) pattern module and customize it for your organization's needs.

## Table of Contents

1. [Overview](#overview)
2. [Module Configuration](#module-configuration)
3. [Architecture Definition File](#architecture-definition-file)
4. [Customizing Management Group Structure](#customizing-management-group-structure)
5. [Renaming the Architecture Definition](#renaming-the-architecture-definition)
6. [Policy Configuration via Archetype Overrides](#policy-configuration-via-archetype-overrides)
7. [Examples](#examples)

## Overview

The ALZ pattern module (`avm-ptn-alz`) deploys a complete Azure Landing Zone structure including:
- Management group hierarchy
- Policy assignments
- Role definitions
- Subscription placement

The module uses the Azure Verified Modules (AVM) pattern and integrates with the ALZ pattern library to provide a standardized, scalable Azure governance structure.

## Module Configuration

The ALZ pattern module is configured in `main.tf`:

```hcl
module "avm-ptn-alz" {
  source                 = "Azure/avm-ptn-alz/azurerm"
  version                = "0.18.0"
  parent_resource_id     = data.azurerm_client_config.main.tenant_id
  location               = var.location
  architecture_name      = "alz"
  subscription_placement = local.subscription_placement
  policy_default_values  = {}
}
```

### Key Parameters

- **`architecture_name`**: Must match the name in your architecture definition JSON file (see below)
- **`subscription_placement`**: Maps workloads to subscriptions and management groups (configured in `locals.tf`)
- **`policy_default_values`**: Allows you to set default parameter values for policies (e.g., allowed locations, tag requirements)

## Architecture Definition File

The architecture definition file (`edp.alz_architecture_definition.json`) defines your management group hierarchy and which archetypes (policy sets) are applied to each management group.

### File Location

The architecture definition file must be located at:
```
terraform/lib/architecture_definitions/<name>.alz_architecture_definition.json
```

The ALZ provider (configured in `providers.tf`) automatically discovers files in the `lib` directory and merges them with the remote ALZ pattern library.

### File Structure

The architecture definition file contains:

1. **`name`**: The architecture name (must match `architecture_name` in `main.tf`)
2. **`management_groups`**: Array of management group definitions

Each management group definition includes:
- **`id`**: Unique identifier for the management group (e.g., `"tt"`, `"tt-platform"`)
- **`display_name`**: Human-readable name shown in Azure Portal
- **`parent_id`**: ID of the parent management group (use `null` for root)
- **`exists`**: Whether the management group already exists (`false` to create it)
- **`archetypes`**: Array of archetype names to apply (e.g., `["root_custom"]`, `["platform_custom"]`)

## Customizing Management Group Structure

### Adding a New Management Group

To add a new management group, add an entry to the `management_groups` array in `edp.alz_architecture_definition.json`:

```json
{
    "archetypes": ["custom_archetype_name"],
    "display_name": "My New Management Group",
    "exists": false,
    "id": "tt-mynewmg",
    "parent_id": "tt-platform"
}
```

**Important considerations:**
- The `id` must be unique and follow Azure naming conventions (lowercase, alphanumeric, hyphens)
- The `parent_id` must reference an existing management group's `id`
- You'll need to create a corresponding archetype override file (see [Policy Configuration](#policy-configuration-via-archetype-overrides))

### Modifying Existing Management Groups

You can modify any management group by editing its entry in the architecture definition file:

- **Change display name**: Update the `display_name` field
- **Move to different parent**: Change the `parent_id` (be careful with existing subscriptions)
- **Change archetypes**: Modify the `archetypes` array to apply different policy sets
- **Change ID**: Update the `id` field (requires careful migration planning)

### Example: Current Structure

The default structure includes:
- **Root** (`tt`): Company root management group
- **Platform** (`tt-platform`): Platform services
  - **Management** (`tt-management`): Management and monitoring
  - **Connectivity** (`tt-connectivity`): Network connectivity
  - **Identity** (`tt-identity`): Identity services
- **Landing Zones** (`tt-landingzones`): Workload landing zones
  - **Corp** (`tt-corp`): Corporate workloads
  - **Online** (`tt-online`): Online/public-facing workloads
  - **Legacy** (`tt-legacy`): Legacy workloads
- **Sandboxes** (`tt-sandboxes`): Development and testing
- **Decommissioned** (`tt-decommissioned`): Resources being decommissioned

## Renaming the Architecture Definition

If you want to rename the architecture definition file (e.g., from `edp` to your organization name):

### Step 1: Rename the File

Rename the architecture definition file:
```bash
mv lib/architecture_definitions/edp.alz_architecture_definition.json \
   lib/architecture_definitions/myorg.alz_architecture_definition.json
```

### Step 2: Update the Architecture Name

Update the `name` field inside the JSON file to match your new name:
```json
{
    "$schema": "...",
    "name": "myorg",  // Changed from "alz"
    "management_groups": [...]
}
```

### Step 3: Update main.tf

Update the `architecture_name` parameter in `main.tf`:
```hcl
module "avm-ptn-alz" {
  // ... other parameters
  architecture_name = "myorg"  // Changed from "alz"
  // ...
}
```

**Note**: The `architecture_name` in `main.tf` must match the `name` field in the JSON file, not the filename prefix.

## Policy Configuration via Archetype Overrides

Each archetype referenced in the architecture definition has a corresponding override file that allows you to customize which policies are applied.

### Archetype Override Files

Archetype override files are located at:
```
terraform/lib/architecture_definitions/<archetype_name>.alz_archetype_override.json
```

For example:
- `root_custom` → `root.alz_archetype_override.json`
- `platform_custom` → `platform.alz_archetype_override.json`
- `corp_custom` → `corp.alz_archetype_override.json`

### Override File Structure

Each override file contains:

```json
{
  "$schema": "https://raw.githubusercontent.com/Azure/Azure-Landing-Zones-Library/main/schemas/archetype_override.json",
  "name": "archetype_name_custom",
  "base_archetype": "base_archetype_name",
  "policy_assignments_to_add": [],
  "policy_definitions_to_add": [],
  "policy_set_definitions_to_add": [],
  "role_definitions_to_add": [],
  "policy_assignments_to_remove": [],
  "policy_definitions_to_remove": [],
  "policy_set_definitions_to_remove": [],
  "role_definitions_to_remove": []
}
```

### Key Fields

- **`name`**: Must match the archetype name used in the architecture definition (e.g., `"root_custom"`)
- **`base_archetype`**: The base ALZ archetype to inherit from (e.g., `"root"`, `"platform"`, `"corp"`)
- **`*_to_add`**: Arrays of resources to add beyond the base archetype
- **`*_to_remove`**: Arrays of resources to remove from the base archetype

### Adding Policies

To add a custom policy assignment:

```json
{
  "policy_assignments_to_add": [
    {
      "name": "MyCustomPolicy",
      "display_name": "My Custom Policy Assignment",
      "description": "Description of the policy",
      "policy_definition_id": "/providers/Microsoft.Management/managementGroups/tt/providers/Microsoft.Authorization/policyDefinitions/MyPolicy",
      "parameters": {
        "allowedLocations": {
          "value": ["uksouth", "ukwest"]
        }
      }
    }
  ]
}
```

### Removing Policies

To remove a policy that comes with the base archetype, add it to the removal array:

```json
{
  "policy_assignments_to_remove": [
    "Enable-DDoS-VNET",
    "Deny-Privileged-AKS"
  ]
}
```

**Example**: The `connectivity.alz_archetype_override.json` file removes the DDoS policy:

```json
{
  "policy_assignments_to_remove": [
    "Enable-DDoS-VNET"
  ]
}
```

### Available Override Files

The following archetype override files are available for customization:

- **`root.alz_archetype_override.json`**: Root management group policies
- **`platform.alz_archetype_override.json`**: Platform management group policies
- **`landing_zones.alz_archetype_override.json`**: Landing zones management group policies
- **`corp.alz_archetype_override.json`**: Corporate workload policies
- **`online.alz_archetype_override.json`**: Online/public workload policies
- **`sandbox.alz_archetype_override.json`**: Sandbox environment policies
- **`management.alz_archetype_override.json`**: Management and monitoring policies
- **`connectivity.alz_archetype_override.json`**: Connectivity policies
- **`identity.alz_archetype_override.json`**: Identity policies
- **`decommissioned.alz_archetype_override.json`**: Decommissioned resource policies

## Examples

### Example 1: Remove a Policy from Landing Zones

Edit `landing_zones.alz_archetype_override.json`:

```json
{
  "$schema": "https://raw.githubusercontent.com/Azure/Azure-Landing-Zones-Library/main/schemas/archetype_override.json",
  "name": "landing_zones_custom",
  "base_archetype": "landing_zones",
  "policy_assignments_to_add": [],
  "policy_assignments_to_remove": [
    "Deny-Subnet-Without-Nsg"
  ],
  // ... other fields
}
```

### Example 2: Add a Custom Policy to Platform

Edit `platform.alz_archetype_override.json`:

```json
{
  "$schema": "https://raw.githubusercontent.com/Azure/Azure-Landing-Zones-Library/main/schemas/archetype_override.json",
  "name": "platform_custom",
  "base_archetype": "platform",
  "policy_assignments_to_add": [
    {
      "name": "Enforce-Tag-Requirement",
      "display_name": "Enforce Required Tags",
      "description": "Ensures all resources have required tags",
      "policy_definition_id": "/providers/Microsoft.Authorization/policyDefinitions/...",
      "parameters": {
        "tagName1": {
          "value": "Environment"
        },
        "tagName2": {
          "value": "CostCenter"
        }
      }
    }
  ],
  // ... other fields
}
```

### Example 3: Add a New Management Group for Compliance

1. Add to `edp.alz_architecture_definition.json`:

```json
{
    "archetypes": ["compliance_custom"],
    "display_name": "Compliance",
    "exists": false,
    "id": "tt-compliance",
    "parent_id": "tt-platform"
}
```

2. Create `compliance.alz_archetype_override.json`:

```json
{
  "$schema": "https://raw.githubusercontent.com/Azure/Azure-Landing-Zones-Library/main/schemas/archetype_override.json",
  "name": "compliance_custom",
  "base_archetype": "platform",
  "policy_assignments_to_add": [
    {
      "name": "Compliance-Audit-Policy",
      // ... policy definition
    }
  ],
  "policy_assignments_to_remove": [],
  // ... other fields
}
```

## Best Practices

1. **Version Control**: Always commit changes to architecture definition and override files to version control
2. **Testing**: Test changes in a non-production environment first
3. **Documentation**: Document why policies are added or removed
4. **Naming Consistency**: Use consistent naming conventions for management group IDs
5. **Incremental Changes**: Make small, incremental changes rather than large sweeping modifications
6. **Review ALZ Library**: Check the ALZ pattern library documentation for available base archetypes and policies before creating custom ones

## Troubleshooting

### Architecture Definition Not Found

If Terraform can't find your architecture definition:
- Verify the file is in `terraform/lib/architecture_definitions/`
- Ensure the `name` field in the JSON matches `architecture_name` in `main.tf`
- Check that the ALZ provider is configured correctly in `providers.tf`

### Policies Not Applied

If policies aren't being applied as expected:
- Verify the archetype name in the override file matches the name used in the architecture definition
- Check that the base archetype exists in the ALZ pattern library
- Ensure policy names in `*_to_remove` arrays match the exact names from the base archetype

### Management Group Creation Issues

If management groups aren't being created:
- Verify the `exists` field is set to `false` for new management groups
- Check that parent management groups are created before child groups (order matters)
- Ensure management group IDs follow Azure naming requirements

## Additional Resources

- [Azure Landing Zones Library](https://github.com/Azure/Azure-Landing-Zones-Library)
- [AVM Pattern ALZ Module Documentation](https://registry.terraform.io/modules/Azure/avm-ptn-alz/azurerm/latest)
- [ALZ Pattern Library Schemas](https://github.com/Azure/Azure-Landing-Zones-Library/tree/main/schemas)

