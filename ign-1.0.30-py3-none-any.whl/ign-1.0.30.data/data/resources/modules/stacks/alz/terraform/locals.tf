locals {
  subscription_placement = {
    #   connectivity = {
    #     subscription_id       = var.subscription_id
    #     management_group_name = ""
    #   }
    #   security = {
    #     subscription_id       = var.subscription_id
    #     management_group_name = ""
    #   }
    #   datadev = {
    #     subscription_id       = var.subscription_id
    #     management_group_name = ""
    #   }
    #   dataTest = {
    #     subscription_id       = var.subscription_id
    #     management_group_name = ""
    #   }
    #   dataUAT = {
    #     subscription_id       = var.subscription_id
    #     management_group_name = ""
    #   }
    #   dataProd = {
    #     subscription_id       = var.subscription_id
    #     management_group_name = ""
    #   }
  }
  root_management_group_name = keys(module.avm-ptn-alz.management_group_resource_ids)[2] // for AMBA
}