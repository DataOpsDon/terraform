// ---------------------------------------------------------------------------------------------------------------------
// Providers & Backend configuration for ALZ stack.
//   - terraform.required_providers: pins AzureRM + ALZ modules sources (ALZ provider adds pattern library support).
//   - backend "azurerm": remote state (configured via env vars / partial backend config outside this file).
//   - azurerm provider: OIDC auth for pipeline runs; subscription passed via variable.
//   - alz provider: Allows referencing ALZ pattern library plus local overrides in ./lib.
// ---------------------------------------------------------------------------------------------------------------------
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"

    }
    alz = {
      source = "Azure/alz" // Provider exposing ALZ pattern library
    }

  }
  backend "azurerm" {} // State stored in Azure Storage
}

// AzureRM provider: uses workload identity (OIDC) instead of service principal secret.
provider "azurerm" {
  features {}
  use_oidc            = true
  subscription_id     = var.subscription_id
  storage_use_azuread = true
}

// ALZ provider: merges remote pattern library (tagged ref) with local customisations under ./lib.
provider "alz" {
  library_overwrite_enabled = true // Allow local lib to override upstream definitions
  library_references = [
    {
      path = "platform/alz" // Remote library path reference
      ref  = "2025.09.3"    // Tag/version of ALZ pattern library
    },
    {
      custom_url = "${path.root}/lib" // Local overrides / extensions
    }
  ]
}

