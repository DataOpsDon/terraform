# ---------------------------------------------------------------------------------------------------------------------
# UK West Regional Configuration for ALZ Baseline Spoke
# ---------------------------------------------------------------------------------------------------------------------

location           = "ukwest"
location_short     = "ukw"
vnet_address_space = "10.2.0.0/24"
dns_servers        = []

# Optional: Hub VNet resource ID for peering (update with your hub VNet)
# hub_vnet_resource_id = "/subscriptions/your-sub-id/resourceGroups/rg-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub"

# Custom routes (add specific routes if needed)
application_routes      = {}
data_routes             = {}
management_routes       = {}
private_endpoint_routes = {}

# Uncomment and modify these examples if you need custom routing:

# Example: Route traffic through a firewall/NVA
/*
application_routes = {
  to_hub_via_firewall = {
    name                   = "ToHubViaFirewall"
    address_prefix         = "10.0.0.0/16"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.0.1.4"  # Firewall IP in hub
  }
}
*/

# Example: Force internet traffic through hub firewall
/*
management_routes = {
  internet_via_hub = {
    name                   = "InternetViaHub"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.0.1.4"  # Firewall IP in hub
  }
}
*/

# Example: Direct internet access for specific subnets
/*
data_routes = {
  direct_internet = {
    name           = "DirectInternet"
    address_prefix = "0.0.0.0/0"
    next_hop_type  = "Internet"
  }
}
*/