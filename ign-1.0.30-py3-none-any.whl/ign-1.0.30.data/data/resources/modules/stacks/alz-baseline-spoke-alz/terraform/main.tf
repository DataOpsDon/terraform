# ---------------------------------------------------------------
# Azure Landing Zone | Baseline Spoke Stack  
# ---------------------------------------------------------------
# This module deploys a comprehensive baseline spoke infrastructure 
# for standard workload hosting in an Azure Landing Zone. It includes:
#
# • 3-tier network architecture (Application/Data/Management)
# • Private endpoint subnet for secure service connectivity
# • Network security groups with baseline security rules
# • Recovery Services Vault with Site Recovery and Backup
# • Key Vault for application secrets and certificate management
# • Automation Account for operational tasks and maintenance
# • Log Analytics workspace for monitoring and diagnostics
# • Storage accounts for ASR replication and diagnostics
# • Application Security Groups for workload segmentation
# • Network Watcher for network monitoring and troubleshooting
#
# The configuration follows Microsoft's recommended ALZ baseline
# patterns and integrates with hub connectivity and security stacks.
# ---------------------------------------------------------------

variable "backup_retention_weekly" {
  description = "Number of weeks to retain weekly backups"
  type        = number
  default     = 12
}

variable "backup_retention_monthly" {
  description = "Number of months to retain monthly backups"
  type        = number
  default     = 12
}

variable "backup_retention_yearly" {
  description = "Number of years to retain yearly backups"
  type        = number
  default     = 3
}

// Data source for current Azure configuration
data "azurerm_client_config" "current" {}

// Local values for baseline spoke configuration
locals {
  # Subnet ranges for baseline spoke (adjust based on your VNet CIDR)
  subnet_ranges = {
    application       = cidrsubnet(var.vnet_address_space, 2, 0) # /26 for applications
    data              = cidrsubnet(var.vnet_address_space, 2, 1) # /26 for data tier
    management        = cidrsubnet(var.vnet_address_space, 4, 8) # /28 for management
    private_endpoints = cidrsubnet(var.vnet_address_space, 4, 9) # /28 for private endpoints
  }

  # Common backup policy configuration
  backup_policy_settings = {
    timezone    = "UTC"
    backup_time = "02:00"
  }
}

// Module: naming
// Purpose: Provides consistent base naming primitives used across baseline spoke resources.
// Notes: Values are currently static for this stack; adjust if introducing environment-driven variability.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = "edp"
  lz       = "b1s00"    // Baseline spoke landing zone code
  suffix   = "baseline" // Suffix distinguishes baseline assets
  lz_short = "baseline" // Short descriptor for baseline spoke
}

// Module: resource_group
// Purpose: Resource group for all baseline spoke components (VNet, Recovery Vault, Key Vault, Storage, Automation, NSGs).
// Notes: Consider enabling lock if required for production environments
module "resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = module.naming.name.resource_group
  //lock             = local.rg_no_delete_lock 
  tags = var.tags
}

// Module: application_subnet_nsg
// Purpose: Network Security Group for application subnet with standard web and app tier rules
// Notes: Includes rules for HTTP/HTTPS, database access, and internal communication
module "application_subnet_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-b1s00-baseline-app"
  security_rules = {
    allow_http_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowHTTPInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "Internet"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "80"
    }
    allow_https_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowHTTPSInbound"
      priority                   = 1100
      protocol                   = "Tcp"
      source_address_prefix      = "Internet"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "443"
    }
    allow_vnet_internal = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowVNetInternal"
      priority                   = 1200
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "VirtualNetwork"
      destination_port_range     = "*"
    }
    allow_rdp_management = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRDPFromManagement"
      priority                   = 1300
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.management
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "3389"
    }
    allow_ssh_management = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowSSHFromManagement"
      priority                   = 1400
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.management
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "22"
    }
  }
  tags = var.tags
}

// Module: data_subnet_nsg
// Purpose: Network Security Group for data tier subnet with database and storage access rules
// Notes: Restricts access to database services from application tier and management
module "data_subnet_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-b1s00-baseline-data"
  security_rules = {
    allow_sql_from_app = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowSQLFromApp"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.application
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "1433"
    }
    allow_mysql_from_app = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowMySQLFromApp"
      priority                   = 1100
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.application
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "3306"
    }
    allow_postgres_from_app = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowPostgreSQLFromApp"
      priority                   = 1200
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.application
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "5432"
    }
    allow_rdp_management = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRDPFromManagement"
      priority                   = 1300
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.management
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "3389"
    }
    allow_ssh_management = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowSSHFromManagement"
      priority                   = 1400
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.management
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "22"
    }
  }
  tags = var.tags
}

// Module: management_nsg
// Purpose: Network Security Group for management subnet allowing administrative access
// Notes: Restricts access to management tools, jump boxes, and operational services
module "management_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-b1s00-baseline-mgmt"
  security_rules = {
    allow_rdp_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRDPInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "3389"
    }
    allow_ssh_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowSSHInbound"
      priority                   = 1100
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "22"
    }
    allow_winrm_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowWinRMInbound"
      priority                   = 1200
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["5985", "5986"]
    }
  }
  tags = var.tags
}

// Module: private_endpoints_nsg
// Purpose: Network Security Group applied to private endpoint subnet
// Notes: Allows traffic for private endpoints while maintaining security
module "private_endpoints_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-b1s00-baseline-pep"
  security_rules = {
    allow_https_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowHTTPSInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "443"
    }
    allow_dns_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowDNSInbound"
      priority                   = 1100
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "53"
    }
  }
  tags = var.tags
}

// Module: route_table_application
// Purpose: Route table for application subnet with routes to hub network and internet
// Notes: Enables proper routing for application traffic and hybrid connectivity
module "route_table_application" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-b1s00-baseline-app"
  bgp_route_propagation_enabled = true
  routes                        = var.application_routes
  tags                          = var.tags
}

// Module: route_table_data
// Purpose: Route table for data subnet with controlled routing
// Notes: Restricts data tier routing for security while enabling necessary connectivity
module "route_table_data" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-b1s00-baseline-data"
  bgp_route_propagation_enabled = true
  routes                        = var.data_routes
  tags                          = var.tags
}

// Module: route_table_management
// Purpose: Route table for management subnet
// Notes: Routes for management and administrative traffic
module "route_table_management" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-b1s00-baseline-mgmt"
  bgp_route_propagation_enabled = true
  routes                        = var.management_routes
  tags                          = var.tags
}

// Module: route_table_private_endpoints
// Purpose: Route table for private endpoint subnet
// Notes: Routes for private endpoint connectivity
module "route_table_private_endpoints" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-b1s00-baseline-pep"
  bgp_route_propagation_enabled = false
  routes                        = var.private_endpoint_routes
  tags                          = var.tags
}

// Module: baseline_virtual_network
// Purpose: Deploys baseline spoke virtual network with subnets for applications, data, management, and private endpoints
// Notes: Subnet CIDRs sourced from locals for consistency. Standard 3-tier architecture with management overlay.
module "baseline_virtual_network" {
  source           = "Azure/avm-res-network-virtualnetwork/azurerm"
  version          = "0.15.0"
  enable_telemetry = var.enable_telemetry
  name             = module.naming.name.virtual_network
  address_space    = [var.vnet_address_space]
  location         = var.location
  parent_id        = module.resource_group.resource_id
  dns_servers      = var.dns_servers

  subnets = {
    application = {
      name                                      = "snet-${var.location_short}-edp-b1s00-baseline-app"
      address_prefixes                          = [local.subnet_ranges.application]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.application_subnet_nsg.resource_id
      }
      route_table = {
        id = module.route_table_application.resource_id
      }
    }
    data = {
      name                                      = "snet-${var.location_short}-edp-b1s00-baseline-data"
      address_prefixes                          = [local.subnet_ranges.data]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.data_subnet_nsg.resource_id
      }
      route_table = {
        id = module.route_table_data.resource_id
      }
    }
    management = {
      name                                      = "snet-${var.location_short}-edp-b1s00-baseline-mgmt"
      address_prefixes                          = [local.subnet_ranges.management]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.management_nsg.resource_id
      }
      route_table = {
        id = module.route_table_management.resource_id
      }
    }
    private_endpoints = {
      name                                      = "snet-${var.location_short}-edp-b1s00-baseline-pep"
      address_prefixes                          = [local.subnet_ranges.private_endpoints]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.private_endpoints_nsg.resource_id
      }
      route_table = {
        id = module.route_table_private_endpoints.resource_id
      }
    }
  }

  tags = var.tags
}

// Module: key_vault
// Purpose: Azure Key Vault for storing secrets, certificates, and encryption keys for identity services
// Notes: Private endpoint enabled for secure access. RBAC enabled for modern access control.
module "key_vault" {
  source              = "Azure/avm-res-keyvault-vault/azurerm"
  version             = "0.11.2"
  name                = module.naming.name.key_vault
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = "premium"

  # Security configuration
  purge_protection_enabled      = true
  soft_delete_retention_days    = 90
  public_network_access_enabled = false
  enable_rbac_authorization     = true

  # Network configuration
  network_acls = {
    default_action = "Deny"
    bypass         = "AzureServices"
  }

  # Private endpoint configuration
  private_endpoints = {
    key_vault_pe = {
      name                          = "pe-${module.naming.name.key_vault}"
      subnet_resource_id            = module.baseline_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = []
      private_service_connection = {
        name                           = "psc-${module.naming.name.key_vault}"
        private_connection_resource_id = null
        subresource_names              = ["vault"]
      }
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: recovery_services_vault
// Purpose: Recovery Services Vault for backup and disaster recovery of identity infrastructure
// Notes: Geo-redundant storage for cross-region protection. Soft delete enabled for protection against accidental deletion.
module "recovery_services_vault" {
  source              = "Azure/avm-res-recoveryservices-vault/azurerm"
  version             = "0.3.2"
  name                = module.naming.name.recovery_services_vault
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Vault configuration
  sku                   = "Standard"
  storage_mode_type     = "GeoRedundant"
  cross_region_restore  = true
  soft_delete_enabled   = true
  public_network_access = "Disabled"

  # Identity configuration for encryption
  identity = {
    type = "SystemAssigned"
  }

  # VM backup policy for workloads
  backup_policies = {
    daily_vm_policy = {
      name     = "daily-baseline-backup"
      type     = "V2"
      timezone = "UTC"
      backup = {
        frequency = "Daily"
        time      = "02:00"
      }
      retention_daily = {
        count = var.backup_retention_daily
      }
      retention_weekly = {
        count    = var.backup_retention_weekly
        weekdays = ["Sunday"]
      }
      retention_monthly = {
        count    = var.backup_retention_monthly
        weekdays = ["Sunday"]
        weeks    = ["First"]
      }
      retention_yearly = {
        count    = var.backup_retention_yearly
        weekdays = ["Sunday"]
        weeks    = ["First"]
        months   = ["January"]
      }
    }
    hourly_vm_policy = {
      name     = "hourly-baseline-backup"
      type     = "V2"
      timezone = "UTC"
      backup = {
        frequency = "Hourly"
        time      = "02:00"
        hourly = {
          interval = 4
          schedule_policy = {
            days_of_week           = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
            schedule_run_frequency = "Hourly"
          }
        }
      }
      retention_daily = {
        count = 7
      }
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}


// Module: baseline_storage_account
// Purpose: Primary storage account for diagnostics, logs, and operational data
// Notes: Secure configuration with private endpoints and network restrictions
module "baseline_storage_account" {
  source              = "Azure/avm-res-storage-storageaccount/azurerm"
  version             = "0.6.4"
  name                = module.naming.name.storage_account
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Storage configuration
  account_tier                  = "Standard"
  account_replication_type      = "GRS"
  public_network_access_enabled = false
  shared_access_key_enabled     = true

  # Security configuration
  network_rules = {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }

  # Private endpoint for secure access
  private_endpoints = {
    storage_pe = {
      name                          = "pe-${module.naming.name.storage_account}"
      subnet_resource_id            = module.baseline_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = []
      private_service_connection = {
        name                           = "psc-${module.naming.name.storage_account}"
        private_connection_resource_id = null
        subresource_names              = ["blob"]
      }
    }
  }

  # Containers for different purposes
  containers = {
    backup = {
      name = "backup"
    }
    diagnostics = {
      name = "diagnostics"
    }
    logs = {
      name = "logs"
    }
    vm-images = {
      name = "vm-images"
    }
    deployment-artifacts = {
      name = "deployment-artifacts"
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: asr_storage_account
// Purpose: Dedicated storage account for Azure Site Recovery replication and cache
// Notes: Premium storage with zone-redundant storage for high performance and availability
module "asr_storage_account" {
  count               = var.enable_site_recovery ? 1 : 0
  source              = "Azure/avm-res-storage-storageaccount/azurerm"
  version             = "0.6.4"
  name                = "${substr(module.naming.name.storage_account, 0, 18)}asr"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Storage configuration optimized for ASR
  account_tier                  = "Standard"
  account_replication_type      = "ZRS"
  public_network_access_enabled = false
  shared_access_key_enabled     = true

  # Security configuration
  network_rules = {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }

  # Private endpoint for secure access
  private_endpoints = {
    storage_pe = {
      name                          = "pe-${substr(module.naming.name.storage_account, 0, 18)}asr"
      subnet_resource_id            = module.baseline_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = []
      private_service_connection = {
        name                           = "psc-${substr(module.naming.name.storage_account, 0, 18)}asr"
        private_connection_resource_id = null
        subresource_names              = ["blob"]
      }
    }
  }

  # Containers for ASR operations
  containers = {
    asr-cache = {
      name = "asr-cache"
    }
    asr-recovery-points = {
      name = "asr-recovery-points"
    }
    asr-scripts = {
      name = "asr-scripts"
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: automation_account
// Purpose: Azure Automation Account for ASR operations, update management, and operational tasks
// Notes: Enables runbooks, configuration management, and update management for baseline workloads
module "automation_account" {
  count               = var.enable_automation ? 1 : 0
  source              = "Azure/avm-res-automation-automationaccount/azurerm"
  version             = "0.3.1"
  name                = module.naming.name.automation_account
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Automation account configuration
  sku_name                      = "Basic"
  public_network_access_enabled = false

  # Identity configuration for accessing other resources
  identity = {
    type = "SystemAssigned"
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: log_analytics_workspace
// Purpose: Log Analytics workspace for centralized logging and monitoring
// Notes: Connected to automation account for update management and monitoring solutions
module "log_analytics_workspace" {
  source              = "Azure/avm-res-operationalinsights-workspace/azurerm"
  version             = "0.6.0"
  name                = module.naming.name.log_analytics_workspace
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Workspace configuration
  sku                        = "PerGB2018"
  retention_in_days          = 90
  daily_quota_gb             = 10
  internet_ingestion_enabled = false
  internet_query_enabled     = false

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: network_watcher
// Purpose: Network Watcher for network monitoring and diagnostics
// Notes: Enables flow logs, connection monitoring, and network troubleshooting
module "network_watcher" {
  source              = "Azure/avm-res-network-networkwatcher/azurerm"
  version             = "0.2.0"
  name                = "nw-${var.location_short}-${module.naming.name.resource_group}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// VNet Peering to Hub (if hub VNet resource ID provided)
resource "azurerm_virtual_network_peering" "baseline_to_hub" {
  count                        = var.hub_vnet_resource_id != "" ? 1 : 0
  name                         = "peer-baseline-to-hub"
  resource_group_name          = module.resource_group.name
  virtual_network_name         = module.baseline_virtual_network.name
  remote_virtual_network_id    = var.hub_vnet_resource_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = false
}

// Module: application_security_groups
// Purpose: Application Security Groups for micro-segmentation of baseline workloads
// Notes: Used in NSG rules for more granular traffic control based on application roles
resource "azurerm_application_security_group" "web_servers" {
  name                = "asg-${var.location_short}-edp-b1s00-baseline-web"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "app_servers" {
  name                = "asg-${var.location_short}-edp-b1s00-baseline-app"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "database_servers" {
  name                = "asg-${var.location_short}-edp-b1s00-baseline-db"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "management_servers" {
  name                = "asg-${var.location_short}-edp-b1s00-baseline-mgmt"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "monitoring_agents" {
  name                = "asg-${var.location_short}-edp-b1s00-baseline-mon"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

// Data source for current Azure client configuration
data "azurerm_client_config" "current" {}
