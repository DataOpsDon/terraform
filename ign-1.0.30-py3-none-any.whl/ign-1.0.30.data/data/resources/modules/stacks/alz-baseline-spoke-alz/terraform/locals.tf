# ---------------------------------------------------------------------------------------------------------------------
# ALZ Baseline Spoke Local Values
# Local values for consistent configuration across the baseline spoke infrastructure
# ---------------------------------------------------------------------------------------------------------------------

locals {
  # Resource Group Lock Configuration
  rg_no_delete_lock = {
    kind = "CanNotDelete"
    name = "Baseline Spoke Protection Lock"
  }

  # Subnet Configuration for Baseline Spoke
  # Based on a /24 VNet, creates appropriately sized subnets for each tier
  subnet_ranges = {
    application       = cidrsubnet(var.vnet_address_space, 2, 0) # /26 - 64 IPs for application tier
    data              = cidrsubnet(var.vnet_address_space, 2, 1) # /26 - 64 IPs for data tier
    management        = cidrsubnet(var.vnet_address_space, 4, 8) # /28 - 16 IPs for management
    private_endpoints = cidrsubnet(var.vnet_address_space, 4, 9) # /28 - 16 IPs for private endpoints
  }

  # Backup Policy Common Settings
  backup_policy_settings = {
    timezone         = "UTC"
    backup_time      = "02:00"
    backup_frequency = "Daily"
  }

  # Common Security Rules for NSGs
  common_security_rules = {
    deny_all_inbound = {
      access                     = "Deny"
      direction                  = "Inbound"
      name                       = "DenyAllInbound"
      priority                   = 4096
      protocol                   = "*"
      source_address_prefix      = "*"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "*"
    }
  }

  # Storage Account Configuration
  storage_config = {
    account_tier             = "Standard"
    account_replication_type = var.storage_account_replication_type
    access_tier              = "Hot"
  }

  # ASR Storage Account Configuration  
  asr_storage_config = {
    account_tier             = "Standard"
    account_replication_type = var.asr_storage_replication_type
    access_tier              = "Hot"
  }

  # Key Vault Configuration
  key_vault_config = {
    sku_name                      = "premium"
    soft_delete_retention_days    = 90
    purge_protection_enabled      = true
    public_network_access_enabled = false
    enable_rbac_authorization     = true
  }

  # Log Analytics Configuration
  log_analytics_config = {
    sku                        = "PerGB2018"
    retention_in_days          = var.log_analytics_retention_days
    daily_quota_gb             = var.log_analytics_daily_quota_gb
    internet_ingestion_enabled = false
    internet_query_enabled     = false
  }

  # Recovery Services Vault Configuration
  recovery_vault_config = {
    sku                   = "Standard"
    storage_mode_type     = "GeoRedundant"
    cross_region_restore  = true
    soft_delete_enabled   = true
    public_network_access = "Disabled"
  }
}
