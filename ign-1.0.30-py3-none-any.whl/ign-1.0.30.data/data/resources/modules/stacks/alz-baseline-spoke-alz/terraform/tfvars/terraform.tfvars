
# ---------------------------------------------------------------------------------------------------------------------
# ALZ Baseline Spoke Configuration
# Terraform variables file for deploying baseline spoke infrastructure
# ---------------------------------------------------------------------------------------------------------------------

# Core Infrastructure Configuration
subscription_id    = "" # Update with your subscription ID
enable_telemetry   = false
vnet_address_space = "10.1.0.0/24" # Update with your VNet CIDR

# Networking Configuration
dns_servers          = [] # Leave empty to use Azure DNS, or specify custom DNS servers
hub_vnet_resource_id = "" # Optional: Resource ID of hub VNet for peering

# Feature Toggles
enable_site_recovery = true
enable_backup        = true
enable_automation    = true

# Backup Retention Configuration
backup_retention_daily   = 30
backup_retention_weekly  = 12
backup_retention_monthly = 12
backup_retention_yearly  = 3

# Log Analytics Configuration
log_analytics_retention_days = 90
log_analytics_daily_quota_gb = 10

# Storage Configuration
storage_account_replication_type = "GRS"
asr_storage_replication_type     = "ZRS"

# Route Configuration (empty by default - add custom routes as needed)
application_routes      = {}
data_routes             = {}
management_routes       = {}
private_endpoint_routes = {}

# Resource Tags
tags = {
  costcentre  = "EDP"
  wbscode     = "B1S00"
  owner       = "Platform Team"
  status      = "Production"
  environment = "Baseline"
  workload    = "Baseline Spoke"
  project     = "ALZ Implementation"
}
