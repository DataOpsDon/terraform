---
name: Bug Report
about: Report a bug in Terraform modules or CI/CD pipelines
title: '[BUG] '
labels: bug, Pending Review
assignees: ''
---

## Bug Description
A clear and concise description of the bug.

## Affected Component
<!-- Check all that apply -->
- [ ] Terraform Module (specify which module below)
- [ ] CI/CD Pipeline (Azure DevOps)
- [ ] GitHub Actions
- [ ] Bootstrap/Setup Scripts
- [ ] Terraform Backend Configuration

### Specific Module/Stack
<!-- If applicable, specify the affected module or stack -->
- Module Path: `modules/azure/` or `modules/stacks/`
- Stack Name (if applicable): 

## Environment Information

### Terraform Version
```
terraform version output here
```

### Provider Versions
```hcl
# List provider versions from your providers.tf or terraform.lock.hcl
# Example:
# azurerm = "~> 4.0"
# azuredevops = "1.13.0"
# databricks = "1.72.0"
```

### Azure/Cloud Environment
- Subscription ID: `<subscription-id>` (or mark as N/A)
- Region: `<azure-region>` (e.g., uksouth)
- Environment: `<dev/tst/ppd/prd>`

### Pipeline Information (if applicable)
- Pipeline Name/Path: 
- Agent Pool: 
- Service Connection Name: 
- Authentication Method: `<OIDC/Service Principal/Managed Identity>`

## Steps to Reproduce
1. Step 1
2. Step 2
3. Step 3
4. ...

## Expected Behavior
A clear description of what you expected to happen.

## Actual Behavior
A clear description of what actually happened.

## Error Messages/Logs
```
Paste relevant error messages, Terraform output, or pipeline logs here.
Include the full error trace if available.
```

### Terraform State Information (if relevant)
```
# Any relevant state information
# Remove sensitive data before posting
```

## Configuration Files
<!-- Provide relevant configuration snippets -->

### Terraform Configuration
```hcl
# Paste relevant .tf file content or module usage
```

### Pipeline Configuration (if applicable)
```yaml
# Paste relevant azure-pipelines.yml or GitHub Actions workflow
```

### Variables/Parameters
```hcl
# Paste relevant terraform.tfvars or variable values
# REMOVE SENSITIVE VALUES
```

## Screenshots
If applicable, add screenshots to help explain the problem.

## Additional Context
Add any other context about the problem here, such as:
- Recent changes to the codebase
- Similar issues in other environments
- Workarounds attempted
- Impact on deployment

## Possible Solution
<!-- Optional: If you have suggestions on how to fix the bug -->
