---
name: Feature Request
about: Suggest a new feature or enhancement for Terraform modules or CI/CD pipelines
title: '[FEATURE] - <Replace me>'
labels: enhancement, Pending Review
assignees: ''
---

## Feature Description
A clear and concise description of the feature or enhancement you'd like to see.

## Feature Category
<!-- Check all that apply -->
- [ ] New Terraform Module
- [ ] Enhancement to Existing Module
- [ ] CI/CD Pipeline Improvement
- [ ] New Stack/Pattern
- [ ] Documentation
- [ ] Automation/Scripts
- [ ] Testing/Validation
- [ ] Security Enhancement

## Target Component
<!-- Specify where this feature should be implemented -->
- Component: `<modules/azure | modules/stacks | templates/pipelines | bootstrap>`
- Specific Module/Stack (if applicable): 

## Use Case
Describe the problem or use case this feature would solve.

**Current Situation:**
<!-- What are you trying to accomplish now? -->

**Desired Outcome:**
<!-- What would you like to achieve with this feature? -->

## Proposed Solution
Describe how you envision this feature working.

### Terraform Module Design (if applicable)
```hcl
# Provide a sample module interface or usage example
# Example:
module "my_new_resource" {
  source = "..."
  
  # Required variables
  name                = "..."
  location            = "..."
  resource_group_name = "..."
  
  # Optional configurations
  # ...
}
```

### Pipeline Enhancement (if applicable)
```yaml
# Provide sample pipeline YAML or describe the pipeline changes
# Example:
- stage: NewStage
  jobs:
    - job: NewJob
      steps:
        - task: ...
```

## Azure Resources (if applicable)
<!-- List any Azure resources this feature would create or interact with -->
- Resource Type(s): `<e.g., Azure Data Factory, App Service, etc.>`
- Provider(s): `<e.g., azurerm, databricks, azuredevops>`
- Estimated Cost Impact: `<low/medium/high>`

## Requirements
<!-- List specific requirements for this feature -->
- [ ] Must support multiple Azure regions
- [ ] Must follow Azure Verified Modules (AVM) patterns
- [ ] Must include automated tests
- [ ] Must support OIDC authentication
- [ ] Must be compatible with existing stacks
- [ ] Other: 

## Benefits
<!-- How will this feature benefit the project? -->
- **Improved Efficiency:** 
- **Better Security:** 
- **Cost Savings:** 
- **Simplified Maintenance:** 
- **Other Benefits:** 

## Alternatives Considered
Describe any alternative solutions or features you've considered.

## Additional Context
Add any other context, mockups, diagrams, or examples about the feature request here.

### Related Resources
<!-- Links to documentation, examples, or related issues -->
- Azure Documentation: 
- Similar Implementations: 
- Related Issues: 

## Implementation Considerations
<!-- Optional: Technical considerations for implementation -->
- **Terraform Version Requirements:** 
- **Provider Version Requirements:** 
- **Breaking Changes:** Yes/No
- **Migration Path (if breaking):** 
- **Testing Strategy:** 

## Success Criteria
<!-- How will we know this feature is successfully implemented? -->
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3
