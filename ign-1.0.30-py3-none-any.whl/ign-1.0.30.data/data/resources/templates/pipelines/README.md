# Pipeline Templates

This directory contains reusable CI/CD pipeline templates for different platforms.

## Directory Structure

```
pipelines/
├── ado/           # Azure DevOps pipeline templates
│   ├── build-terraform.yml.template
│   ├── deploy-terraform.yml.template
│   ├── environments.yml.template
│   └── run-terraform-checks.yml.template
│
├── aws/           # Azure DevOps templates for AWS (AWSShellScript tasks)
│
└── github/        # GitHub Actions templates for Azure (see github/README.md)
    ├── cicd-repo/                    # Shared CI/CD repo (ign init-cicd-repo)
    ├── consumer/                     # Repo hygiene files for infra repos
    ├── scripts/setup-github-oidc.ps1
    └── stack-workflow.yml.template   # Per-stack caller workflow
```

## Azure DevOps Templates

The `ado/` directory contains reusable Azure Pipeline templates for Terraform infrastructure management:

### environments.yml.template
Main environment orchestration template that coordinates build and deployment stages across multiple environments.

**Parameters:**
- `buildTemplatePath`: Path to the build template
- `deployTemplatePath`: Path to the deploy template
- `landingZone`: Target landing zone for deployment
- `serviceConnection`: Azure service connection name

### build-terraform.yml.template
Template for building and validating Terraform configurations. Includes:
- Terraform installation and initialization
- Backend configuration
- Plan generation
- Artifact publishing

**Parameters:**
- `serviceConnection`: Azure service connection
- `environment`: Target environment (dev, test, prod)
- `landingZone`: Landing zone identifier
- `agentPool`: Build agent pool
- `location`: Azure region
- `terraformVars`: Additional Terraform variables

### deploy-terraform.yml.template
Template for deploying Terraform configurations to Azure. Includes:
- Environment-based deployment
- Terraform apply operations
- Artifact management

**Parameters:**
- `serviceConnection`: Azure service connection
- `environment`: Target environment
- `landingZone`: Landing zone identifier
- `agentPool`: Build agent pool
- `location`: Azure region
- `terraformVars`: Additional Terraform variables

### run-terraform-checks.yml.template
Template for running Terraform validation and security checks:
- Terraform format validation
- Security scanning (tfsec)

**Parameters:**
- `serviceConnection`: Azure service connection
- `landingZone`: Landing zone identifier
- `environment`: Target environment
- `agentPool`: Build agent pool

## GitHub Actions (Azure)

Selected with `ign init --cloud azure --cicd github`. A shared, versioned CI/CD repo holds a
reusable workflow (CI -> Plan -> Apply) and composite actions; each stack gets a small caller
workflow in `.github/workflows/<stack>.yml`. Authentication to Azure is OIDC. See
[`github/README.md`](github/README.md).

## Usage

These templates are automatically used by the Infrastructure CLI tool when generating new stacks or resources. The CLI loads these templates and generates stack-specific pipeline configurations.

### For Developers

To modify pipeline behavior:
1. Edit the appropriate template file in `ado/` or `github/`
2. Test your changes with the CLI: `infra add-stack --stack-name test-stack`
3. Review the generated pipeline files in your stack's `yaml/` directory

## Template Variables

All templates use Azure Pipelines YAML syntax with parameter interpolation:
- `${{ parameters.paramName }}` - Compile-time parameter substitution
- `${{ variables.varName }}` - Compile-time variable substitution
- `$(variableName)` - Runtime variable substitution

## Best Practices

1. **Keep templates generic** - Avoid hardcoding stack-specific values
2. **Use parameters** - Make templates flexible through parameters
3. **Document changes** - Update this README when adding new templates
4. **Test thoroughly** - Test template changes with multiple stack configurations

