# Terraform Templates

This directory contains reusable Terraform templates used by the CLI to generate infrastructure stacks.

## Usage

These templates are automatically loaded by `infra_cli.py`:
- **`add-stack` command**: Uses base templates + module templates
- **`add-resource` command**: Uses resource-specific templates

All 15 template files are packaged with the CLI when installed via `pip` or `uv`.

