output "name" {
  description = "Standardised names for AWS resources"
  value = {
    s3_bucket       = "${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    iam_role        = "role-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    kms_key         = "key-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    lambda_function = "fn-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    dynamodb_table  = "tbl-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    ecs_cluster     = "ecs-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    vpc             = "vpc-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
    ecr_repo        = "ecr-${var.project}-${var.lz}-${local.region_short}-${var.suffix}"
  }
}

output "lz" {
  description = "Landing zone code"
  value       = var.lz
}

output "region_short" {
  description = "Short region code"
  value       = local.region_short
}
