locals {
  region_short_map = {
    "eu-west-1"      = "ew1"
    "eu-west-2"      = "ew2"
    "eu-central-1"   = "ec1"
    "us-east-1"      = "ue1"
    "us-west-2"      = "uw2"
    "ap-southeast-1" = "as1"
  }

  region_short = lookup(local.region_short_map, var.region, "ew2")
}
