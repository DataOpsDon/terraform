# =============================================================================
# Naming Utility Module
# =============================================================================
# This module provides consistent resource naming conventions across all stacks
# =============================================================================

locals {
  # Base naming format: [resource-type]-[location]-[project]-[lz]-[suffix]
  base_name = "${var.location_short}-${var.project}-${var.lz}-${var.suffix}"

  # Name mappings for different Azure resource types
  name = {
    # Compute
    virtual_machine  = "vm-${local.base_name}"
    availability_set = "avail-${local.base_name}"

    # Networking
    virtual_network        = "vnet-${local.base_name}"
    subnet                 = "snet-${local.base_name}"
    network_security_group = "nsg-${local.base_name}"
    route_table            = "rt-${local.base_name}"
    public_ip              = "pip-${local.base_name}"
    load_balancer          = "lb-${local.base_name}"
    application_gateway    = "agw-${local.base_name}"

    # Storage
    storage_account = replace("st${var.location_short}${var.project}${var.lz}${var.suffix}", "-", "")

    # Security
    key_vault               = "kv-${local.base_name}"
    recovery_services_vault = "rsv-${local.base_name}"

    # Monitoring
    log_analytics_workspace = "log-${local.base_name}"
    automation_account      = "aa-${local.base_name}"
    action_group            = "ag-${local.base_name}"
    activity_log_alert      = "act-${local.base_name}"
    metric_alert            = "met-${local.base_name}"

    # Data
    sql_server     = "sql-${local.base_name}"
    sql_database   = "sqldb-${local.base_name}"
    cosmos_account = "cosmos-${local.base_name}"

    # Management
    resource_group = "rg-${local.base_name}"

    # AVD
    host_pool         = "vdpool-${local.base_name}"
    application_group = "vdag-${local.base_name}"
    workspace         = "vdws-${local.base_name}"
    scaling_plan      = "vdscaling-${local.base_name}"

    # App Service
    app_service_plan = "asp-${local.base_name}"
    app_service      = "app-${local.base_name}"

    # Fabric
    fabric_capacity = "fc-${local.base_name}"
  }
}