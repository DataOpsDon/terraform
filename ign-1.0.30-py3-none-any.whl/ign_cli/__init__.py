"""Command-line tool internals for ign (split out of the former single-file ignition.py)."""
