"""Root click group; registers every command."""

import click

from ign_cli.version import __version__
from ign_cli.commands.bootstrap import bootstrap
from ign_cli.commands.init import init, init_cicd_repo
from ign_cli.commands.insights import checklist, compare, cost, doctor, status, upgrade
from ign_cli.commands.quality import lint_tf, pr_check, validate
from ign_cli.commands.release import changelog, update
from ign_cli.commands.resources import add_resource, list_modules
from ign_cli.commands.security import policy, secrets, tfsec
from ign_cli.commands.stacks import (
    add_stack, add_stack_template, env_clone, list_stack_templates,
    list_stacks, rename_stack, scaffold,
)


@click.group()
@click.version_option(version=__version__)
def cli():
    """
    Infrastructure CLI - Scaffold and manage infrastructure projects.
    
    Use this tool to:
    - Initialize new infrastructure projects
    - Add new deployment stacks to existing projects
    - Manage CI/CD pipeline configurations
    """
    pass


for _command in (
    init, init_cicd_repo, add_stack, list_stacks, list_modules, bootstrap,
    add_resource, list_stack_templates, add_stack_template, validate, doctor,
    secrets, compare, status, lint_tf, upgrade, cost, checklist, scaffold,
    rename_stack, env_clone, changelog, pr_check, tfsec, policy, update,
):
    cli.add_command(_command)
