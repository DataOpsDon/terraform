"""console – part of the ign CLI (split from ignition.py)."""

from rich.console import Console
from pathlib import Path
from ign_cli.paths import LEGACY_FILE, SOURCE_ROOT


class InfrastructureCLI:
    """Main CLI class for infrastructure project management."""
    
    def __init__(self):
        self.project_root = Path.cwd()
    
    def create_directory(self, path: Path) -> None:
        """Create directory if it doesn't exist."""
        path.mkdir(parents=True, exist_ok=True)
        try:
            rel_path = path.resolve().relative_to(self.project_root)
            console.print(f"  [dim]📁 {rel_path}[/dim]")
        except ValueError:
            console.print(f"  [dim]📁 {path}[/dim]")
    
    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        try:
            rel_path = path.resolve().relative_to(self.project_root)
            console.print(f"  [dim]📄 {rel_path}[/dim]")
        except ValueError:
            console.print(f"  [dim]📄 {path}[/dim]")
    
    def load_template(self, template_path: str, **kwargs) -> str:
        """Load a template file and replace placeholders with provided values."""
        import sys
        
        locations = []
        
        # Check local sibling repo tf-iac-modules first if template starts with 'resources/'
        if template_path.startswith('resources/'):
            sub_path = template_path[len('resources/'):]
            for parent_level in [LEGACY_FILE.parents[3], LEGACY_FILE.parents[2], Path.cwd().parent, Path.cwd()]:
                locations.append(parent_level / 'tf-iac-modules' / sub_path)

        # Then try standard locations
        locations.extend([
            # 1. Development: next to ignition.py
            SOURCE_ROOT / template_path,
            # 2. Current working directory
            Path(template_path),
            # 3. Installed package: sys.prefix (for pip/uv install)
            Path(sys.prefix) / template_path,
            # 4. User install: site.USER_BASE
            Path(sys.prefix).parent / template_path,
        ])

        template_file = None
        for location in locations:
            if location.exists():
                template_file = location
                break
        
        if not template_file:
            # List tried locations for debugging
            tried = '\n  '.join(str(loc) for loc in locations)
            raise FileNotFoundError(
                f"Template not found: {template_path}\n"
                f"Tried locations:\n  {tried}"
            )
        
        template_content = template_file.read_text(encoding='utf-8')
        
        # Replace placeholders if any kwargs provided
        if kwargs:
            for key, value in kwargs.items():
                val_str = str(value)
                template_content = template_content.replace(f"{{{key}}}", val_str)
                template_content = template_content.replace(f"<{key}>", val_str)
                title_key = key.replace('_', ' ').title()
                template_content = template_content.replace(f"{{{title_key}}}", val_str)
                template_content = template_content.replace(f"<{title_key}>", val_str)
        
        return template_content


console = Console(force_terminal=True, legacy_windows=False)


# Initialize CLI
cli_helper = InfrastructureCLI()
