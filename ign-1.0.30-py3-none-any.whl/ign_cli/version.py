"""version – part of the ign CLI (split from ignition.py)."""

from ign_cli.paths import SOURCE_ROOT


# Read version from VERSION file
def get_version():
    """Read version from VERSION file."""
    # Try multiple locations for VERSION file
    locations = [
        SOURCE_ROOT / 'VERSION',  # When running from source
        SOURCE_ROOT / 'VERSION',  # When running as script
    ]
    
    for version_file in locations:
        if version_file.exists():
            try:
                return version_file.read_text(encoding='utf-8').strip()
            except Exception:
                pass
    
    # If VERSION file not found, try to get from package metadata
    try:
        import importlib.metadata
        return importlib.metadata.version('ign')
    except Exception:
        pass
    
    return '0.0.0'


__version__ = get_version()
