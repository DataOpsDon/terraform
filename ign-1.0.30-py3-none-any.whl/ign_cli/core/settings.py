"""settings – part of the ign CLI (split from ignition.py)."""

import json
from pathlib import Path
from typing import Dict, Optional

from ign_cli.console import cli_helper, console


def _prompt_cloud_provider() -> str:
    """Let the user pick a cloud provider (arrow keys / number / type to filter); returns 'aws' or 'azure'."""
    from ign_cli.core.prompts import select
    console.print()
    return select('Select cloud provider', [
        ('aws', 'AWS', 'Amazon Web Services'),
        ('azure', 'Azure', 'Microsoft Azure'),
    ])


CICD_LABELS = {
    'ado': "[bold #0078D4]⚙  Azure DevOps Pipelines[/bold #0078D4]",
    'github': "[bold white]⬢  GitHub Actions[/bold white]",
}


# Project-level settings written by `ign init` so later commands (add-stack,
# rename-stack, checklist, ...) know which CI/CD flavour the project uses.
PROJECT_SETTINGS_FILE = '.ignition.json'


DEFAULT_CICD_REPO = 'terraform-azure-cicd'


DEFAULT_CICD_REF = 'main'


def _prompt_cicd_platform() -> str:
    """Let the user pick a CI/CD tool (arrow keys / number / type to filter); returns 'ado' or 'github'."""
    from ign_cli.core.prompts import select
    console.print()
    return select('Select CI/CD tool', [
        ('ado', 'Azure DevOps', 'Azure Pipelines (ADO)'),
        ('github', 'GitHub Actions', 'Reusable workflows + OIDC'),
    ])


def _load_project_settings(root: Optional[Path] = None) -> Dict[str, str]:
    """Read .ignition.json from the project root (empty dict if absent/invalid)."""
    path = (root or Path.cwd()) / PROJECT_SETTINGS_FILE
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
    return {}


def _save_project_settings(settings: Dict[str, str]) -> None:
    cli_helper.write_file(Path(PROJECT_SETTINGS_FILE), json.dumps(settings, indent=2) + '\n')


def _detect_cicd_platform(root: Optional[Path] = None) -> str:
    """Return the project's CI/CD platform ('ado' or 'github').

    Prefers .ignition.json; falls back to the GitHub scaffold written by init,
    and otherwise assumes Azure DevOps (the behaviour before GitHub support)."""
    base = root or Path.cwd()
    cicd = str(_load_project_settings(base).get('cicd', '')).lower()
    if cicd in ('ado', 'github'):
        return cicd
    if (base / 'templates' / 'scaffold' / 'github' / 'stack-workflow.yml').exists():
        return 'github'
    return 'ado'


def _stack_pipeline_file(stack_path: Path, root: Optional[Path] = None) -> Path:
    """Path of the CI/CD definition for a stack, for the project's platform."""
    base = root or Path.cwd()
    if _detect_cicd_platform(base) == 'github':
        return base / '.github' / 'workflows' / f'{stack_path.name}.yml'
    return stack_path / 'azure-pipelines.yml'


def _detect_cloud_provider() -> str:
    """Infer cloud provider from the scaffold providers.tf written by init."""
    providers_tf = Path('templates/scaffold/terraform/providers.tf')
    if providers_tf.exists():
        content = providers_tf.read_text(encoding='utf-8')
        if 'hashicorp/aws' in content or 'backend "s3"' in content:
            return 'aws'
    return 'azure'


def _github_settings() -> Dict[str, str]:
    """GitHub settings for the current project with sensible fallbacks."""
    settings = _load_project_settings()
    return {
        'github_org': settings.get('github_org') or '<GITHUB_ORG>',
        'cicd_repo': settings.get('cicd_repo') or DEFAULT_CICD_REPO,
        'cicd_ref': settings.get('cicd_ref') or DEFAULT_CICD_REF,
    }
