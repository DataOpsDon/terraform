"""parsing – part of the ign CLI (split from ignition.py)."""

import json
import re


# =============================================================================
# ign compare  (helper + command)
# =============================================================================

def _strip_inline_comment(val: str) -> str:
    """Strip a trailing ``#`` or ``//`` inline comment that is outside quotes."""
    in_quote = None
    for i, ch in enumerate(val):
        if in_quote:
            if ch == in_quote:
                in_quote = None
        elif ch in ('"', "'"):
            in_quote = ch
        elif ch == "#":
            return val[:i]
        elif ch == "/" and i + 1 < len(val) and val[i + 1] == "/":
            return val[:i]
    return val


def _parse_tfvars(path):
    """Parse a .tfvars file into a dict of key/value strings."""
    result = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("//"):
                continue
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = _strip_inline_comment(val.strip()).strip()
            if len(val) >= 2 and val[0] in ('"', "'") and val[-1] == val[0]:
                val = val[1:-1]
            result[key] = val
    except Exception:
        pass
    return result


def _parse_providers_tf(path):
    """Extract provider entries from a providers.tf file."""
    providers = []
    try:
        content = path.read_text(encoding="utf-8")
        rp = re.search(r"required_providers\s*\{((?:[^{}]|\{[^{}]*\})*)\}", content, re.DOTALL)
        if not rp:
            return providers
        block = rp.group(1)
        for m in re.finditer(r'(\w+)\s*=\s*\{([^}]+)\}', block, re.DOTALL):
            name  = m.group(1)
            body  = m.group(2)
            src_m = re.search(r'source\s*=\s*"([^"]+)"', body)
            ver_m = re.search(r'version\s*=\s*"([^"]+)"', body)
            if src_m:
                providers.append({
                    "name":    name,
                    "source":  src_m.group(1),
                    "version": ver_m.group(1) if ver_m else "unset",
                })
    except Exception:
        pass
    return providers


def _parse_version_tuple(version: str):
    """Parse an x.y.z version string into a comparable int tuple."""
    text = version.strip().lstrip("v")
    match = re.match(r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)", text)
    if not match:
        return (-1, -1, -1)

    return (
        int(match.group("major")),
        int(match.group("minor")),
        int(match.group("patch")),
    )


def _extract_latest_tag(output: str) -> str:
    """Handle gh's JSON or line-based query output and return a single tag."""
    text = output.strip()
    if not text:
        return ""

    if text[0] in "[{":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return ""
        if isinstance(data, list):
            if not data:
                return ""
            first = data[0]
            if isinstance(first, dict):
                return str(first.get("tagName") or first.get("name") or "").strip()
            return str(first).strip()
        if isinstance(data, dict):
            return str(data.get("tagName") or data.get("name") or "").strip()
        return str(data).strip()

    return next((line.strip() for line in text.splitlines() if line.strip()), "")
