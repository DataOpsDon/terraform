"""Shared helpers: stack discovery, project settings, parsing."""
