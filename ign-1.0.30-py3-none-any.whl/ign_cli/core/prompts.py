"""Interactive pickers: arrow keys + Enter, numbered, with type-to-filter.

Every picker falls back to a plain numbered list (answer with a number or a
name) when stdin/stdout is not a terminal, so scripted use keeps working.
"""

import shutil
import sys
from typing import Any, List, NamedTuple, Optional, Sequence, Tuple, Union

import click

from ign_cli.console import console
from ign_cli.core.stacks import _iter_all_stacks

_MAX_ROWS = 12
_CLEAR = '\x1b[{}A\x1b[J'  # move the cursor up N lines and clear to the end of the screen


class Option(NamedTuple):
    """One selectable entry: `value` is returned, `label` is shown and filtered on."""
    value: Any
    label: str
    hint: str = ''


OptionLike = Union[str, Tuple[Any, str], Tuple[Any, str, str], Option]


def _normalise(options: Sequence[OptionLike]) -> List[Option]:
    out = []
    for o in options:
        if isinstance(o, Option):
            out.append(o)
        elif isinstance(o, str):
            out.append(Option(o, o))
        else:
            out.append(Option(*o))
    return out


def _read_key() -> str:
    """Return a normalised key name ('up', 'down', 'enter', ...) or the typed character."""
    ch = click.getchar()
    if ch in ('\r', '\n'):
        return 'enter'
    if ch in ('\x08', '\x7f'):
        return 'backspace'
    if ch in ('\x03', '\x04'):
        raise click.Abort()
    if ch == '\x1b':
        return 'esc'
    # Windows: special keys arrive as '\x00X' / '\xe0X'
    if ch[:1] in ('\x00', '\xe0') and len(ch) > 1:
        return {'H': 'up', 'P': 'down', 'G': 'home', 'O': 'end', 'I': 'pgup', 'Q': 'pgdn'}.get(ch[1], '')
    # POSIX: escape sequences such as '\x1b[A'
    if ch.startswith('\x1b'):
        table = {'[A': 'up', 'OA': 'up', '[B': 'down', 'OB': 'down', '[H': 'home', 'OH': 'home',
                 '[F': 'end', 'OF': 'end', '[5~': 'pgup', '[6~': 'pgdn', '[1~': 'home', '[4~': 'end'}
        return table.get(ch[1:], '')
    return ch if len(ch) == 1 and ch.isprintable() else ''


def _fit(text: str, width: int) -> str:
    return text if len(text) <= width else text[:max(width - 1, 1)] + '…'


def _select_interactive(title: str, options: List[Option], default_index: int) -> Option:
    filt = ''
    numbuf = ''
    idx = default_index
    offset = 0
    drawn = 0

    def visible() -> List[Option]:
        if not filt:
            return options
        f = filt.lower()
        return [o for o in options if f in o.label.lower() or f in o.hint.lower()]

    def render() -> None:
        nonlocal drawn, offset
        items = visible()
        width = max(shutil.get_terminal_size((80, 24)).columns - 1, 20)
        lines = [click.style(_fit(title, width), bold=True, fg='cyan')]
        status = []
        if numbuf:
            status.append(f'number: {numbuf}')
        if filt:
            status.append(f'filter: {filt}')
        help_line = '↑/↓ move · number or text to filter · Enter select · Esc cancel'
        lines.append(click.style(_fit('  ' + ('   '.join(status) if status else help_line), width), dim=True))
        if not items:
            lines.append(click.style('  (no matches - Backspace to widen the filter)', fg='yellow'))
        else:
            rows = min(_MAX_ROWS, len(items))
            if idx < offset:
                offset = idx
            elif idx >= offset + rows:
                offset = idx - rows + 1
            offset = max(0, min(offset, len(items) - rows))
            numw = len(str(len(items)))
            label_w = max(len(o.label) for o in items)
            for n in range(offset, offset + rows):
                o = items[n]
                text = f'{n + 1:>{numw}}. {o.label}'
                if o.hint:
                    text += ' ' * (label_w - len(o.label) + 2) + o.hint
                text = _fit(text, width - 2)
                if n == idx:
                    lines.append(click.style('❯ ' + text, fg='cyan', bold=True))
                else:
                    lines.append('  ' + text)
            if len(items) > rows:
                lines.append(click.style(f'  showing {offset + 1}-{offset + rows} of {len(items)}', dim=True))
        if drawn:
            click.echo(_CLEAR.format(drawn), nl=False)
        click.echo('\n'.join(lines))
        drawn = len(lines)

    render()
    while True:
        key = _read_key()
        items = visible()
        if key == 'enter':
            if items:
                break
            continue
        if key == 'esc':
            click.echo(_CLEAR.format(drawn), nl=False)
            raise click.Abort()
        if key == 'up' and items:
            idx = (idx - 1) % len(items)
        elif key == 'down' and items:
            idx = (idx + 1) % len(items)
        elif key == 'home':
            idx = 0
        elif key == 'end' and items:
            idx = len(items) - 1
        elif key == 'pgup':
            idx = max(0, idx - _MAX_ROWS)
        elif key == 'pgdn' and items:
            idx = min(len(items) - 1, idx + _MAX_ROWS)
        elif key == 'backspace':
            if numbuf:
                numbuf = numbuf[:-1]
            else:
                filt = filt[:-1]
            idx = 0
            items = visible()
            if numbuf and 1 <= int(numbuf) <= len(items):
                idx = int(numbuf) - 1
        elif len(key) == 1 and key.isdigit() and not filt:
            numbuf += key
            if not 1 <= int(numbuf) <= len(items):
                numbuf = key  # overshot the list: start a new number
            if 1 <= int(numbuf) <= len(items):
                idx = int(numbuf) - 1
        elif len(key) == 1 and (key != ' ' or filt):
            numbuf = ''
            filt += key
            idx = 0
        idx = min(idx, max(len(visible()) - 1, 0))
        render()

    chosen = visible()[idx]
    click.echo(_CLEAR.format(drawn), nl=False)
    click.echo(click.style('✔ ', fg='green') + click.style(title + ': ', dim=True) + click.style(chosen.label, bold=True))
    return chosen


def _select_plain(title: str, options: List[Option], default_index: int) -> Option:
    click.echo(title)
    numw = len(str(len(options)))
    label_w = max(len(o.label) for o in options)
    for n, o in enumerate(options, 1):
        hint = (' ' * (label_w - len(o.label) + 2) + o.hint) if o.hint else ''
        click.echo(f'  {n:>{numw}}. {o.label}{hint}')
    while True:
        answer = str(click.prompt('Choose a number or name', default=default_index + 1 if default_index else None,
                                  show_default=bool(default_index))).strip()
        if answer.isdigit() and 1 <= int(answer) <= len(options):
            return options[int(answer) - 1]
        low = answer.lower()
        exact = [o for o in options if o.label.lower() == low or str(o.value).lower() == low]
        if exact:
            return exact[0]
        partial = [o for o in options if o.label.lower().startswith(low)]
        if len(partial) == 1:
            return partial[0]
        click.echo(click.style(f"  '{answer}' is not a valid choice.", fg='red'))


def select(title: str, options: Sequence[OptionLike], default: Any = None) -> Any:
    """Let the user pick one option and return its value.

    Interactive terminals get an arrow-key picker (numbered, type to filter);
    otherwise a numbered list is printed and the answer is read as a number or name.
    Raises click.Abort on Esc / Ctrl-C.
    """
    opts = _normalise(options)
    if not opts:
        raise click.ClickException(f'Nothing to choose from for: {title}')
    default_index = next((i for i, o in enumerate(opts) if o.value == default), 0) if default is not None else 0
    if sys.stdin.isatty() and sys.stdout.isatty():
        return _select_interactive(title, opts, default_index).value
    return _select_plain(title, opts, default_index).value


def select_stack(title: str = 'Select a stack') -> str:
    """Pick one of the project's existing stacks (stacks/ and landing-zones/)."""
    stacks = _iter_all_stacks()
    if not stacks:
        console.print("[bold red]❌  No stacks found.[/bold red] "
                      "[dim]Run [bold]ign add-stack[/bold] or [bold]ign add-stack-template[/bold] first.[/dim]")
        raise click.exceptions.Exit(1)
    return select(title, [Option(p.name, p.name, f'{p.parent.name}/') for p in stacks])


def select_stack_or_all(question: str, all_label: str = 'All stacks',
                        default_all: bool = False) -> Tuple[Optional[str], bool]:
    """Ask whether to act on one stack or all of them; returns (stack_name, all_flag)."""
    scope = select(question, [
        Option('stack', 'A single stack', 'pick one from the list next'),
        Option('all', all_label),
    ], default='all' if default_all else 'stack')
    if scope == 'all':
        return None, True
    return select_stack(), False
