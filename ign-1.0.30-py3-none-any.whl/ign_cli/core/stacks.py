"""stacks – part of the ign CLI (split from ignition.py)."""

from pathlib import Path
from typing import List, Optional


# Stacks live in one of two locations: regular stacks under stacks/, and ALZ
# (Azure Landing Zone) stacks — whose names start with "alz" — under
# landing-zones/ (see add_stack_template). These helpers are the single source
# of truth for locating a stack by name and for enumerating every stack,
# regardless of which directory it lives in.
STACK_DIRS = ('stacks', 'landing-zones')


def _resolve_stack_dir(name: str, root: Optional[Path] = None) -> Optional[Path]:
    """Return the directory for a stack by name, searching both stacks/ and
    landing-zones/. Returns None if the stack isn't found in either location."""
    base = root or Path.cwd()
    for parent in STACK_DIRS:
        candidate = base / parent / name
        if candidate.is_dir():
            return candidate
    return None


def _iter_all_stacks(root: Optional[Path] = None) -> List[Path]:
    """Return the directories of every stack across stacks/ and landing-zones/,
    sorted by stack name."""
    base = root or Path.cwd()
    found = []
    for parent in STACK_DIRS:
        parent_dir = base / parent
        if parent_dir.is_dir():
            found.extend(d for d in parent_dir.iterdir() if d.is_dir())
    return sorted(found, key=lambda p: p.name)


# tfvars files are named per "target": either a lifecycle environment
# (dev/tst/uat/prd for regular stacks) or a region (uks/ukw/... for ALZ landing
# zones, which are deployed per-region rather than per-lifecycle-env). We
# auto-discover whatever <target>.tfvars files exist rather than assuming a
# fixed set, so both conventions work.

# Lifecycle names in promotion order — used only to order comparison columns
# nicely. Anything not listed (region codes, etc.) still works; it just sorts
# after these, alphabetically.
_ENV_ORDER = [
    "dev", "tst", "test", "sit", "uat", "stg", "stage", "staging",
    "preprod", "ppd", "ppe", "prd", "prod",
]


# Azure region abbreviations — the full set from the AVM Terraform library
# standard (ref: https://www.jlaundry.nz/2022/azure_region_abbreviations/).
# Used to recognise region-based tfvars values in env-clone. compare does not
# depend on this list — it discovers tfvars files directly — so an unlisted
# code still works there.
_CAF_REGION_ABBRS = {
    # Australia / Austria
    "acl", "acl2", "ae", "ase", "aue",
    # Belgium / Brazil
    "bec", "brs", "bse", "bru",
    # Canada
    "cnc", "cne",
    # India
    "inc", "ins", "inw", "jic", "jiw",
    # United States (incl. EUAP)
    "cus", "ccy", "eus", "eus2", "ecy", "ncus", "scus", "wcus",
    "wus", "wus2", "wus3",
    # Chile / Denmark
    "clc", "dke",
    # Asia
    "ea", "sea",
    # France
    "frc", "frs",
    # Germany (public + legacy sovereign)
    "gn", "gwc", "gec", "gne",
    # Indonesia / Israel / Italy
    "idc", "ilc", "itn",
    # Japan / Korea
    "jpe", "jpw", "krc", "krs",
    # Malaysia / Mexico / New Zealand
    "mys", "myw", "mxc", "nzn",
    # Europe / Norway / Poland / Qatar
    "ne", "we", "nwe", "nww", "plc", "qac",
    # South Africa / Spain / Sweden / Switzerland
    "san", "saw", "spc", "sdc", "sds", "szn", "szw",
    # UAE / UK
    "uac", "uan", "uks", "ukw",
    # China (sovereign)
    "sha", "cne2", "sha3", "bjb", "cnn2", "bjb3",
    # US Government / DoD / Nat / Sec (sovereign)
    "udc", "ude", "uga", "ugi", "ugtx", "ugva", "exe", "exw", "rxe", "rxw",
}


def _is_env_tfvars(name: str) -> bool:
    """True if a filename is an environment/region tfvars file — i.e. a
    ``<target>.tfvars`` that is not one of Terraform's auto-loaded specials
    (``terraform.tfvars`` / ``*.auto.tfvars``)."""
    lower = name.lower()
    if not lower.endswith(".tfvars"):
        return False
    if lower == "terraform.tfvars" or lower.endswith(".auto.tfvars"):
        return False
    return True


def _env_sort_key(target: str):
    """Order lifecycle envs first (by promotion order), then everything else
    (region codes, etc.) alphabetically."""
    low = target.lower()
    return (_ENV_ORDER.index(low) if low in _ENV_ORDER else len(_ENV_ORDER), low)


def _discover_env_tfvars(tfvars_dir: Path) -> List[str]:
    """Return the sorted list of environment/region targets (tfvars stems)
    present in a directory (e.g. ['dev','prd'] or ['uks','ukw'])."""
    stems = {p.stem for p in tfvars_dir.glob("*.tfvars") if _is_env_tfvars(p.name)}
    return sorted(stems, key=_env_sort_key)


def _detect_stack_platform(stack_path: Path) -> str:
    """Detect whether a stack template targets AWS or Azure by inspecting its providers.tf."""
    for candidate in [
        stack_path / 'terraform' / 'providers.tf',
        stack_path / 'terraform' / 'main.tf',
    ]:
        if candidate.exists():
            content = candidate.read_text(encoding='utf-8')
            if 'hashicorp/aws' in content or 'backend "s3"' in content:
                return 'aws'
            if 'hashicorp/azurerm' in content or 'backend "azurerm"' in content:
                return 'azure'
    return 'azure'


def get_location_short(location: str) -> str:
    """Convert Azure location to short code."""
    location_map = {
        "uksouth": "uks",
        "ukwest": "ukw",
        "eastus": "eus",
        "westus": "wus",
        "swedencentral": "sdc",
    }
    return location_map.get(location.lower(), "uks")
