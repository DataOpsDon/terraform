"""Filesystem anchors and bundled-resource lookup for the ign CLI."""

from pathlib import Path
from typing import Optional

# ign_cli/ lives next to ignition.py (ignition/ in a checkout, site-packages/ when installed),
# so these reproduce what Path(__file__).parent / .resolve().parents[N] meant in the old
# single-file ignition.py.
SOURCE_ROOT = Path(__file__).resolve().parent.parent
LEGACY_FILE = SOURCE_ROOT / 'ignition.py'


def _find_resource_dir(rel_path: str) -> Optional[Path]:
    """Locate a directory bundled under resources/ (source checkout or installed package)."""
    import sys
    import site

    rel = Path(rel_path)
    candidates = [
        SOURCE_ROOT / rel,
        SOURCE_ROOT / rel,
        Path.cwd() / rel,
        Path(sys.prefix) / rel,
        Path(sys.prefix) / 'share' / rel,
    ]
    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            candidates.append(Path(site.USER_BASE) / rel)
        for site_dir in site.getsitepackages():
            candidates.append(Path(site_dir) / rel)
    except (AttributeError, OSError):
        pass
    for c in candidates:
        if c.is_dir():
            return c
    return None
