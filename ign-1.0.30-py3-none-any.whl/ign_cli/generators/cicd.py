"""cicd – part of the ign CLI (split from ignition.py)."""

from pathlib import Path
from typing import Optional
from ign_cli.console import cli_helper, console
from ign_cli.core.settings import _github_settings


def _render_cicd_repo(source: Path, target: Path, github_org: str, cicd_repo: str, cicd_ref: str) -> int:
    """Render the shared CI/CD repo templates for an organisation into target. Returns the file count."""
    count = 0
    for src in sorted(source.rglob('*')):
        if not src.is_file() or '__pycache__' in src.parts:
            continue
        content = src.read_text(encoding='utf-8')
        for key, value in (('github_org', github_org), ('cicd_repo', cicd_repo), ('cicd_ref', cicd_ref)):
            content = content.replace('{' + key + '}', value)
        out = target / src.relative_to(source)
        out.parent.mkdir(parents=True, exist_ok=True)
        # LF endings: these files run on Linux runners and are committed as-is by bootstrap.
        with open(out, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(content)
        count += 1
    return count


def _github_repo_exists(org: str, repo: str, token: str) -> Optional[bool]:
    """True/False if the repository exists, None if GitHub could not be asked."""
    import os
    import urllib.request
    import urllib.error
    api = os.environ.get('GITHUB_API_URL', 'https://api.github.com').rstrip('/')
    req = urllib.request.Request(f"{api}/repos/{org}/{repo}", headers={
        'Authorization': f'Bearer {token}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'ignition-cli',
    })
    try:
        with urllib.request.urlopen(req, timeout=20):
            return True
    except urllib.error.HTTPError as err:
        return False if err.code == 404 else None
    except (urllib.error.URLError, TimeoutError, OSError):
        return None


def create_aws_pipeline_templates(aws_region: str) -> None:
    """Create AWS-specific CI/CD pipeline templates using AWSShellScript@1 tasks."""
    yaml_dir = Path('templates/yaml')

    cli_helper.write_file(yaml_dir / 'build-terraform.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/build-terraform.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'deploy-terraform.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/deploy-terraform.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'environments.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/environments.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'alz-environments.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/alz-environments.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'run-terraform-checks.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/run-terraform-checks.yml.template'))

    cli_helper.write_file(yaml_dir / 'create-s3-backend.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/create-s3-backend.yml.template'))


def create_pipeline_templates():
    """Create CI/CD pipeline templates."""
    
    yaml_dir = Path('templates/yaml')
    
    # Load ADO pipeline templates from files
    environments_content = cli_helper.load_template('resources/templates/pipelines/ado/environments.yml.template')
    cli_helper.write_file(yaml_dir / 'environments.yml', environments_content)
    
    build_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/build-terraform.yml.template')
    cli_helper.write_file(yaml_dir / 'build-terraform.yml', build_terraform_content)
    
    deploy_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/deploy-terraform.yml.template')
    cli_helper.write_file(yaml_dir / 'deploy-terraform.yml', deploy_terraform_content)
    
    checks_content = cli_helper.load_template('resources/templates/pipelines/ado/run-terraform-checks.yml.template')
    cli_helper.write_file(yaml_dir / 'run-terraform-checks.yml', checks_content)
    
    alz_environments_content = cli_helper.load_template('resources/templates/pipelines/ado/alz-environments.yml.template')
    cli_helper.write_file(yaml_dir / 'alz-environments.yml', alz_environments_content)

    copy_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/copy-terraform-code.yml.template')
    cli_helper.write_file(yaml_dir / 'copy-terraform-code.yml', copy_terraform_content)

    environment_sign_off_content = cli_helper.load_template('resources/templates/pipelines/ado/environments-sign-off.yml.template')
    cli_helper.write_file(yaml_dir / 'environments-sign-off.yml', environment_sign_off_content)

    pr_sign_off_content = cli_helper.load_template('resources/templates/pipelines/ado/pr-validation.yml.template')
    cli_helper.write_file(yaml_dir / 'pr-validation.yml', pr_sign_off_content)

    summary_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/summary-terraform.yml.template')
    cli_helper.write_file(yaml_dir / 'summary-terraform.yml', summary_terraform_content)


def create_github_pipeline_templates(github_org: str, cicd_repo: str, cicd_ref: str,
                                     github_repo: Optional[str] = None) -> None:
    """Write the GitHub Actions scaffold used by add-stack, plus the manual OIDC setup script."""
    workflow = cli_helper.load_template(
        'resources/templates/pipelines/github/stack-workflow.yml.template',
        github_org=github_org, cicd_repo=cicd_repo, cicd_ref=cicd_ref,
    )
    # {stack_name} is intentionally left in place - it is filled in by add-stack.
    cli_helper.write_file(Path('templates/scaffold/github/stack-workflow.yml'), workflow)

    cli_helper.write_file(
        Path('scripts/setup-github-oidc.ps1'),
        cli_helper.load_template('resources/templates/pipelines/github/scripts/setup-github-oidc.ps1'),
    )

    # Repo hygiene files - never overwrite ones the team already has.
    # .gitattributes matters: the tf-*.sh scripts run on Linux runners and
    # must be committed with LF line endings.
    for name in ('.gitattributes', '.gitignore', 'CODEOWNERS'):
        target = Path(name)
        if target.exists():
            console.print(f"  [dim]↷ {name} exists - left unchanged[/dim]")
            continue
        cli_helper.write_file(target, cli_helper.load_template(
            f'resources/templates/pipelines/github/consumer/{name}', github_org=github_org,
            github_repo=github_repo or Path.cwd().name))


def generate_github_workflow(stack_name: str) -> Path:
    """Create .github/workflows/<stack>.yml for a stack.

    Uses the project's scaffold (templates/scaffold/github/stack-workflow.yml)
    when present so teams can customise it, else the bundled template."""
    gh = _github_settings()
    scaffold = Path('templates/scaffold/github/stack-workflow.yml')
    if scaffold.exists():
        content = scaffold.read_text(encoding='utf-8')
    else:
        content = cli_helper.load_template('resources/templates/pipelines/github/stack-workflow.yml.template', **gh)
    content = content.replace('{stack_name}', stack_name)
    workflow_path = Path('.github/workflows') / f'{stack_name}.yml'
    cli_helper.write_file(workflow_path, content)
    return workflow_path


def generate_azure_pipelines(stack_dir: Path, stack_name: str, service_connection: str):
    """Generate Azure Pipelines YAML for a stack."""
    
    pipeline_content = cli_helper.load_template(
        'resources/templates/yaml/azure-pipelines.yml.template',
        stack_name=stack_name,
        service_connection=service_connection
    )
    cli_helper.write_file(stack_dir / 'azure-pipelines.yml', pipeline_content)
