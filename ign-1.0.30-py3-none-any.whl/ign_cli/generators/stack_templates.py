"""stack_templates – part of the ign CLI (split from ignition.py)."""

from pathlib import Path
from typing import Dict
from ign_cli.console import cli_helper, console
from ign_cli.core.settings import _detect_cicd_platform, _detect_cloud_provider, _github_settings
from ign_cli.core.stacks import _detect_stack_platform
from ign_cli.paths import SOURCE_ROOT


def discover_stack_templates(cloud: str = 'azure') -> Dict[str, Path]:
    """
    Discover available stack templates from the modules/stacks directory for the given cloud.
    Returns a dict mapping stack names to their directory paths.
    """
    import sys
    import site

    stacks = {}
    stack_dirs = [
        # 1. Development: next to ignition.py
        SOURCE_ROOT / 'resources' / 'modules' / 'stacks',
        # 2. Current working directory
        Path.cwd() / 'resources' / 'modules' / 'stacks',
        # 3. Installed package: sys.prefix
        Path(sys.prefix) / 'resources' / 'modules' / 'stacks',
        Path(sys.prefix) / 'share' / 'modules' / 'stacks',
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            stack_dirs.append(Path(site.USER_BASE) / 'resources' / 'modules' / 'stacks')
            stack_dirs.append(Path(site.USER_BASE) / 'share' / 'modules' / 'stacks')
    except Exception:
        pass

    try:
        for site_dir in site.getsitepackages():
            stack_dirs.append(Path(site_dir) / 'resources' / 'modules' / 'stacks')
    except Exception:
        pass

    for stack_dir in stack_dirs:
        if not stack_dir.exists():
            continue

        for stack_path in stack_dir.iterdir():
            if stack_path.is_dir():
                stack_name = stack_path.name
                if stack_name not in stacks and _detect_stack_platform(stack_path) == cloud:
                    stacks[stack_name] = stack_path

    return stacks


def copy_stack_template(stack_name: str, destination: Path) -> bool:
    """
    Copy a stack template from modules/stacks to the destination directory.
    Handles symlinks, special files, and missing files gracefully.
    Returns True if successful, False otherwise.
    """
    available_stacks = discover_stack_templates(_detect_cloud_provider())
    
    if stack_name not in available_stacks:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Stack '{stack_name}' not found in available templates[/red]")
        return False
    
    source_dir = available_stacks[stack_name]
    
    try:
        import shutil
        
        def copy_with_handling(src: Path, dst: Path):
            """Recursively copy directory tree, handling symlinks and special files."""
            # Skip if source doesn't exist
            if not src.exists():
                console.print(f"  [yellow]⚠️   Warning: Source does not exist: {src}[/yellow]")
                return
            
            # Handle symlinks
            if src.is_symlink():
                try:
                    target = src.readlink()
                    # Resolve absolute path if relative
                    if not target.is_absolute():
                        target = src.parent / target
                    
                    if target.exists():
                        if target.is_dir():
                            # Copy the directory that symlink points to
                            copy_with_handling(target, dst)
                        else:
                            # Copy the file that symlink points to
                            shutil.copy2(target, dst, follow_symlinks=False)
                    else:
                        console.print(f"  [yellow]⚠️   Skipping broken symlink:[/yellow] [dim]{src} → {target}[/dim]")
                except Exception as e:
                    console.print(f"  [yellow]⚠️   Skipping symlink {src}:[/yellow] [dim]{e}[/dim]")
            elif src.is_dir():
                # Create directory and copy contents
                dst.mkdir(parents=True, exist_ok=True)
                for item in src.iterdir():
                    # Skip special files and directories
                    if item.name in ['.git', '__pycache__', '.DS_Store']:
                        continue
                    try:
                        copy_with_handling(item, dst / item.name)
                    except Exception as e:
                        console.print(f"  [yellow]⚠️   Skipping {item}:[/yellow] [dim]{e}[/dim]")
            elif src.is_file():
                # Copy regular file
                try:
                    shutil.copy2(src, dst, follow_symlinks=False)
                except (OSError, shutil.Error, FileNotFoundError) as e:
                    console.print(f"  [yellow]⚠️   Could not copy {src}:[/yellow] [dim]{e}[/dim]")
            else:
                # Skip special files (sockets, pipes, etc.)
                console.print(f"  [yellow]⚠️   Skipping special file:[/yellow] [dim]{src}[/dim]")
        
        # Ensure destination parent exists
        destination.parent.mkdir(parents=True, exist_ok=True)
        
        # Copy the directory tree
        copy_with_handling(source_dir, destination)
        return True
    except Exception as e:
        console.print(f"[bold red]❌  Error copying stack template:[/bold red] [red]{e}[/red]")
        import traceback
        traceback.print_exc()
        return False


def create_landing_zones_environments_file(landing_zones_dir: Path):
    """
    Create environments.yml file in the landing-zones directory root if it doesn't exist.
    """
    environments_file = landing_zones_dir / 'environments.yml'
    
    # Only create if it doesn't exist
    if environments_file.exists():
        return
    
    environments_content = """parameters:
  - name: buildTemplatePath
    default: ""
  - name: deployTemplatePath
    default: ""
  - name: landingZone
    default: ""
  - name: serviceConnection
    default: ""
  - name: UkSouth
  - name: UkWest

  
stages:
- ${{ if eq(parameters.UkSouth, 'Yes') }}:
  - stage: BuildUKSouth
    displayName: BUILD UK South - Terraform Plan
    jobs:
      - template: ${{ parameters.buildTemplatePath }}
        parameters:
          serviceConnection:  ${{ parameters.serviceConnection }}
          stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
          landingZone: ${{ parameters.landingZone }}
          environment: "uks"
          agentPool: ""
          location: "UkSouth"

- ${{ if eq(parameters.UkWest, 'Yes') }}:
  - stage: BuildUKWest
    displayName: BUILD UK West - Terraform Plan
    condition: ${{ eq(parameters.UkWest, 'Yes') }}  
    jobs:
      - template: ${{ parameters.buildTemplatePath }}
        parameters:
          serviceConnection:  ${{ parameters.serviceConnection }}
          stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
          landingZone: ${{ parameters.landingZone }}
          environment: "ukw"
          agentPool: ""
          location: "UKWest"
          

- ${{ if eq(parameters.UkSouth, 'Yes') }}:
  - stage: DeployUKSouth
    displayName: DEPLOY UK South - Terraform Apply
    dependsOn: [BuildUKSouth]
    condition: eq(variables['Build.SourceBranch'], 'refs/heads/main')
    jobs:
    - template: '${{ parameters.deployTemplatePath }}'
      parameters:
        serviceConnection:  ${{ parameters.serviceConnection }}
        stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
        landingZone: ${{ parameters.landingZone }}
        environment: "uks"
        agentPool: ""
        location: "UkSouth"



- ${{ if eq(parameters.UkWest, 'Yes') }}:
  - stage: DeployUKWest
    displayName: DEPLOY UK West - Terraform Apply
    condition: eq(variables['Build.SourceBranch'], 'refs/heads/main')
    dependsOn: [BuildUKWest]
    jobs:
    - template: '${{ parameters.deployTemplatePath }}'
      parameters:
        serviceConnection:  ${{ parameters.serviceConnection }}
        stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
        landingZone: ${{ parameters.landingZone }}
        environment: "ukw"
        agentPool: ""
        location: "UKWest"
  
"""
    cli_helper.write_file(environments_file, environments_content)


def generate_configuration_guide(stack_dir: Path, terraform_dir: Path, yaml_dir: Path):
    """
    Generate a CONFIGURATION.md file in the stack directory that lists
    all files that need to be updated with subscription IDs and other configuration.
    """
    stack_name = stack_dir.name
    cicd = _detect_cicd_platform()
    
    config_guide_lines = [
        f"# Configuration Guide - {stack_name}",
        "",
        "This document lists all files that need to be updated with your specific configuration values before deploying this stack.",
        "",
        "## ⚠️ Required Updates",
        "",
        "Before deploying this stack, you must update the following files with your Azure subscription IDs and other configuration values:",
        "",
    ]
    
    if cicd == 'github':
        gh = _github_settings()
        config_guide_lines.extend([
            "### 1. GitHub Actions (`.github/workflows/" + stack_name + ".yml`)",
            "",
            f"The workflow calls the shared reusable pipeline `{gh['github_org']}/{gh['cicd_repo']}` "
            f"pinned to `{gh['cicd_ref']}`. Pin it to a release tag (or full commit SHA) before going live.",
            "",
            "Identity and Terraform state settings are read from **GitHub environment variables**. "
            "Create these environments in the repository (Settings → Environments) and set the variables on each:",
            "",
            "| Environment | Used by | `AZURE_CLIENT_ID` |",
            "|---|---|---|",
            "| `dev`, `prd` | CI + plan jobs | build identity client ID |",
            "| `dev/apply`, `prd/apply` | apply job (add required reviewers) | deploy identity client ID |",
            "",
            "Variables required on every environment:",
            "",
            "- **`AZURE_CLIENT_ID`**: client ID of the managed identity (see table above)",
            "- **`AZURE_TENANT_ID`**: Microsoft Entra tenant ID",
            "- **`AZURE_SUBSCRIPTION_ID`**: subscription this stack deploys into",
            "- **`TF_STATE_SUBSCRIPTION_ID`**: subscription holding the Terraform state storage account",
            "- **`TF_STATE_RESOURCE_GROUP`**: resource group of the state storage account",
            "- **`TF_STATE_STORAGE_ACCOUNT`**: state storage account name",
            "- **`TF_STATE_CONTAINER`**: state blob container",
            "",
            f"The state blob key defaults to `stacks/{stack_name}/terraform/<environment>.tfstate`.",
            "",
            "`ign bootstrap --apply` writes `bootstrap/BOOTSTRAP-OUTPUTS-<env>.md` containing the exact "
            "`gh variable set` commands. Without bootstrap, use `scripts/setup-github-oidc.ps1`.",
            "",
            "Optional repository secret **`MODULE_REPO_PAT`**: read token for private Terraform module repositories.",
            "",
        ])

    # Check for state.yml file
    if cicd != 'github' and yaml_dir.exists():
        state_file = yaml_dir / 'state.yml'
        if state_file.exists():
            config_guide_lines.extend([
                "### 1. State Configuration (`yaml/state.yml`)",
                "",
                "Update the Terraform state backend configuration:",
                "",
                "- **`stateSubscriptionId`**: Your Azure subscription ID for Terraform state storage",
                "- **`stateResourceGroupName`**: Resource group name where Terraform state is stored",
                "- **`stateStorageAccountName`**: Storage account name for Terraform state",
                "- **`stateStorageAccountContainerName`**: Container name for Terraform state files",
                "",
                "Example:",
                "```yaml",
                "variables:",
                "  - name: stateSubscriptionId",
                "    value: 'your-subscription-id-here'",
                "  - name: stateResourceGroupName",
                "    value: 'rg-terraform-state'",
                "  - name: stateStorageAccountName",
                "    value: 'stterraformstate'",
                "  - name: stateStorageAccountContainerName",
                "    value: 'tfstate'",
                "```",
                "",
            ])
    
    # Find all .tfvars files
    tfvars_files = []
    tfvars_subdir = terraform_dir / 'tfvars'
    if tfvars_subdir.exists():
        tfvars_files = sorted(tfvars_subdir.glob('*.tfvars'))
    elif terraform_dir.exists():
        tfvars_files = sorted(terraform_dir.glob('*.tfvars'))
    
    if tfvars_files:
        config_guide_lines.extend([
            "### 2. Terraform Variable Files (`terraform/tfvars/*.tfvars`)",
            "",
            "Update the following `.tfvars` files with your subscription IDs:",
            "",
        ])
        
        for tfvars_file in tfvars_files:
            file_name = tfvars_file.name
            config_guide_lines.append(f"- **`terraform/tfvars/{file_name}`**")
            
            # Provide specific guidance based on file name
            if file_name in ['dev.tfvars', 'tst.tfvars', 'uat.tfvars', 'prd.tfvars']:
                env_name = file_name.replace('.tfvars', '').upper()
                config_guide_lines.extend([
                    f"  - Update `subscription_id` with your {env_name} environment subscription ID",
                    f"  - Update `management_subscription_id` if applicable",
                ])
            elif file_name in ['uks.tfvars', 'ukw.tfvars']:
                loc_name = "UK South" if 'uks' in file_name else "UK West"
                config_guide_lines.append(f"  - Location-specific variables for {loc_name}")
            elif file_name == 'terraform.tfvars':
                config_guide_lines.append("  - Common variables shared across all environments")
            else:
                config_guide_lines.append("  - Update subscription IDs and other configuration values as needed")
            
            config_guide_lines.append("")
        
        config_guide_lines.extend([
            "Example for environment-specific files (e.g., `dev.tfvars`):",
            "```hcl",
            "subscription_id            = \"your-subscription-id-here\"",
            "management_subscription_id = \"your-management-subscription-id-here\"",
            "location                   = \"uksouth\"",
            "environment                = \"dev\"",
            "```",
            "",
        ])
    
    if cicd == 'github':
        pipeline_note = (f"- **Workflow**: Review `.github/workflows/{stack_name}.yml` - branch triggers, "
                         "environments (add `tst`/`uat` jobs if needed) and the pinned CI/CD ref")
    else:
        pipeline_note = ("- **Service Connection**: Check `azure-pipelines.yml` and ensure the service connection "
                         "name matches your Azure DevOps configuration")

    # Additional configuration notes
    config_guide_lines.extend([
        "## 📝 Additional Configuration",
        "",
        "You may also need to update:",
        "",
        pipeline_note,
        "- **Resource Names**: Review and customize resource names in `terraform/main.tf` if needed",
        "- **Variables**: Review `terraform/variables.tf` for any additional variables that need values",
        "",
        "## ✅ Verification",
        "",
        "After updating the configuration files:",
        "",
        "1. Verify all subscription IDs are correct",
        "2. Ensure state backend configuration points to the correct storage account",
        "3. Review environment-specific values in `.tfvars` files",
        "4. Test with `terraform plan` before applying changes",
        "",
        "## 📚 Resources",
        "",
        "- [Azure Subscription IDs](https://docs.microsoft.com/en-us/azure/azure-portal/get-subscription-tenant-id)",
        "- [Terraform State Backend](https://www.terraform.io/docs/language/settings/backends/azurerm.html)",
        "",
    ])
    
    config_guide_content = '\n'.join(config_guide_lines)
    config_guide_path = stack_dir / 'CONFIGURATION.md'
    cli_helper.write_file(config_guide_path, config_guide_content)
