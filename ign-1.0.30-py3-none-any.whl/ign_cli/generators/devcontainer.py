"""devcontainer – part of the ign CLI (split from ignition.py)."""

import click
import re
from pathlib import Path
from typing import Optional
from ign_cli.console import console
from ign_cli.paths import _find_resource_dir


DEVCONTAINER_DIR = Path('.devcontainer')


_BINARY_SUFFIXES = {'.whl'}


def _render_devcontainer(target: Path, include_binary: bool = True) -> int:
    """Copy the bundled dev container (resources/templates/devcontainer) to target/.devcontainer.

    This includes the Ignition CLI wheel in wheels/, so the container installs ign offline
    (client environments cannot reach the Telefónica Tech GitHub releases).
    include_binary=False skips binary files such as the wheel.

    Returns the file count (0 if the templates are not in the installed package).
    Files are copied verbatim - devcontainer.json uses ${...} variables that must not be substituted."""
    import shutil

    source = _find_resource_dir('resources/templates/devcontainer')
    if source is None:
        return 0
    count = 0
    for src in sorted(source.rglob('*')):
        if not src.is_file() or '__pycache__' in src.parts:
            continue
        binary = src.suffix.lower() in _BINARY_SUFFIXES
        if binary and not include_binary:
            continue
        out = target / DEVCONTAINER_DIR / src.relative_to(source)
        out.parent.mkdir(parents=True, exist_ok=True)
        if binary:
            shutil.copyfile(src, out)
        else:
            # LF endings: post-create.sh runs inside a Linux container.
            with open(out, 'w', encoding='utf-8', newline='\n') as fh:
                fh.write(src.read_text(encoding='utf-8'))
        count += 1
    return count


DEVCONTAINER_WHEELS_DIR = DEVCONTAINER_DIR / 'wheels'


def _copy_ign_wheel(wheel: Optional[str]) -> None:
    """Optional override: copy a different Ignition CLI wheel into .devcontainer/wheels/
    (the bundled one from templates/devcontainer/wheels is already there for new dev containers).
    post-create.sh installs the newest version it finds.

    The wheel comes from --ign-wheel, else the IGN_WHEEL environment variable."""
    import os
    import shutil
    import zipfile

    wheel = wheel or os.environ.get('IGN_WHEEL')
    if not wheel:
        return
    src = Path(wheel).expanduser()
    if not src.is_file():
        raise click.ClickException(f"Ignition wheel not found: {src}")
    if not re.fullmatch(r'ign-[0-9][^-]*-py3-none-any\.whl', src.name) or not zipfile.is_zipfile(src):
        raise click.ClickException(f"Not an Ignition CLI wheel (expected ign-<version>-py3-none-any.whl): {src.name}")
    DEVCONTAINER_WHEELS_DIR.mkdir(parents=True, exist_ok=True)
    target = DEVCONTAINER_WHEELS_DIR / src.name
    shutil.copy2(src, target)
    console.print(f"  [dim]📄 {target.as_posix()} (installed by the dev container - commit it)[/dim]")


def create_devcontainer(ign_wheel: Optional[str] = None) -> None:
    """Add the standard dev container (Ignition CLI, Terraform, Azure CLI, ...) to the project.

    Never overwrites a .devcontainer/ the team already has, but still adds the ign wheel to it."""
    if DEVCONTAINER_DIR.exists():
        console.print(f"  [dim]↷ {DEVCONTAINER_DIR}/ exists - left unchanged[/dim]")
    elif _render_devcontainer(Path('.')) == 0:
        console.print("  [yellow]⚠️  Dev container templates not found in the installed package - skipped[/yellow]")
        return
    else:
        console.print(f"  [dim]📁 {DEVCONTAINER_DIR}/ (dev container)[/dim]")
    _copy_ign_wheel(ign_wheel)
