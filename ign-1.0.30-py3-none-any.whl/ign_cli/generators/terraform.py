"""terraform – part of the ign CLI (split from ignition.py)."""

from pathlib import Path
from ign_cli.console import cli_helper


def generate_aws_terraform_files(terraform_dir: Path, stack_name: str, description: str) -> None:
    """Generate Terraform files for a stack (AWS provider)."""

    for fname in ['providers.tf', 'variables.tf', 'data.tf', 'locals.tf', 'outputs.tf']:
        cli_helper.write_file(terraform_dir / fname,
            cli_helper.load_template(f'resources/templates/terraform/aws/{fname}.template'))

    cli_helper.write_file(terraform_dir / 'main.tf',
        cli_helper.load_template(
            'resources/templates/terraform/aws/main.tf.template',
            stack_name_upper=stack_name.upper().replace('-', '_'),
            description=description,
            stack_name=stack_name,
        ))

    tfvars_dir = terraform_dir / 'tfvars'
    cli_helper.create_directory(tfvars_dir)

    cli_helper.write_file(tfvars_dir / 'terraform.tfvars',
        cli_helper.load_template('resources/templates/terraform/aws/tfvars/terraform.tfvars.template'))

    for env in ['dev', 'tst', 'uat', 'prod']:
        cli_helper.write_file(tfvars_dir / f'{env}.tfvars',
            cli_helper.load_template(
                'resources/templates/terraform/aws/tfvars/env.tfvars.template',
                env=env,
                env_upper=env.upper(),
            ))


def generate_terraform_files(terraform_dir: Path, stack_name: str, description: str,
                            include_databricks: bool, include_storage: bool, include_keyvault: bool):
    """Generate Terraform files for a stack."""
    
    # Load and write base terraform files from templates
    providers_content = cli_helper.load_template('resources/templates/terraform/base/providers.tf.template')
    cli_helper.write_file(terraform_dir / 'providers.tf', providers_content)
    
    variables_content = cli_helper.load_template('resources/templates/terraform/base/variables.tf.template')
    cli_helper.write_file(terraform_dir / 'variables.tf', variables_content)
    
    # main.tf
    main_resources = []
    
    # Load main intro template
    main_intro = cli_helper.load_template(
        'resources/templates/terraform/base/main_intro.tf.template',
        stack_name_upper=stack_name.upper(),
        description=description,
        stack_name=stack_name
    )
    
    main_resources.append(main_intro)
    
    if include_storage:
        storage_module = cli_helper.load_template('resources/modules/azure/storage.tf')
        storage_module = storage_module.replace('{{resource_name}}', f'{stack_name}_storage')
        main_resources.append(storage_module)
    
    if include_keyvault:
        keyvault_module = cli_helper.load_template('resources/modules/azure/keyvault.tf')
        keyvault_module = keyvault_module.replace('{{resource_name}}', f'{stack_name}_keyvault')
        main_resources.append(keyvault_module)
    
    if include_databricks:
        databricks_module = cli_helper.load_template('resources/modules/azure/databricks.tf')
        databricks_module = databricks_module.replace('{{resource_name}}', f'{stack_name}_databricks')
        main_resources.append(databricks_module)
    
    cli_helper.write_file(terraform_dir / 'main.tf', '\n'.join(main_resources))
    
    # Load and write remaining terraform files from templates
    data_content = cli_helper.load_template('resources/templates/terraform/base/data.tf.template')
    cli_helper.write_file(terraform_dir / 'data.tf', data_content)
    
    outputs_content = cli_helper.load_template('resources/templates/terraform/base/outputs.tf.template')
    cli_helper.write_file(terraform_dir / 'outputs.tf', outputs_content)
    
    locals_content = cli_helper.load_template('resources/templates/terraform/base/locals.tf.template')
    cli_helper.write_file(terraform_dir / 'locals.tf', locals_content)
    
    # Create tfvars subdirectory
    tfvars_dir = terraform_dir / 'tfvars'
    cli_helper.create_directory(tfvars_dir)

    # terraform.tfvars
    terraform_tfvars_content = """# Common Terraform variables
# These values are shared across all environments
"""
    cli_helper.write_file(tfvars_dir / 'terraform.tfvars', terraform_tfvars_content)
    
    # Environment-specific tfvars
    environments = {
        'dev': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'dev',
        },
        'tst': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'tst',
        },
        'uat': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'uat',
        },
        'prd': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'prd',
        },
    }
    
    for env, values in environments.items():
        env_content = f"""# {env.upper()} Environment Configuration

subscription_id            = "{values['subscription_id']}"
management_subscription_id = "{values['management_subscription_id']}"
location                   = "uksouth"
location_short             = "uks"
environment                = "{values['environment']}"
project                    = "edp"
enable_telemetry           = true
"""
        cli_helper.write_file(tfvars_dir / f'{env}.tfvars', env_content)
    
    # Location-specific tfvars
    locations = ['uks', 'ukw']
    for loc in locations:
        loc_name = 'uksouth' if loc == 'uks' else 'ukwest'
        loc_content = f"""# UK South Configuration
location       = "{loc_name}"
location_short = "{loc}"
"""
        cli_helper.write_file(tfvars_dir / f'{loc}.tfvars', loc_content)


def generate_yaml_files(yaml_dir: Path, stack_dir: Path, stack_name: str, service_connection: str, cloud: str = 'azure'):
    """Generate YAML pipeline files for a stack."""

    # build.yml
    build_content = cli_helper.load_template('resources/templates/yaml/build.yml.template')
    cli_helper.write_file(yaml_dir / 'build.yml', build_content)
    
    # deploy.yml
    deploy_content = cli_helper.load_template('resources/templates/yaml/deploy.yml.template')
    cli_helper.write_file(yaml_dir / 'deploy.yml', deploy_content)
    
    # state.yml — backend vars differ between Azure (Storage Account) and AWS (S3)
    if cloud == 'aws':
        state_content = cli_helper.load_template('resources/templates/yaml/aws/state.yml.template', stack_name=stack_name)
    else:
        state_content = cli_helper.load_template('resources/templates/yaml/state.yml.template', stack_name=stack_name)
    cli_helper.write_file(yaml_dir / 'state.yml', state_content)
