"""modules – part of the ign CLI (split from ignition.py)."""

import click
from pathlib import Path
from typing import Dict
from ign_cli.core.settings import _detect_cloud_provider
from ign_cli.paths import SOURCE_ROOT


def discover_available_modules(cloud: str = 'azure') -> Dict[str, Path]:
    """
    Discover available Terraform modules from the modules directory for the given cloud.
    Returns a dict mapping module names to their file paths.
    """
    import sys
    import site

    modules = {}
    module_dirs = [
        # 1. Development: next to ignition.py
        SOURCE_ROOT / 'resources' / 'modules' / cloud,
        # 2. Current working directory
        Path.cwd() / 'resources' / 'modules' / cloud,
        # 3. Installed package: sys.prefix (for pip/uv install)
        Path(sys.prefix) / 'resources' / 'modules' / cloud,
        # 4. Installed package: site-packages data directory
        Path(sys.prefix) / 'share' / 'resources' / 'modules' / cloud,
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            module_dirs.append(Path(site.USER_BASE) / 'resources' / 'modules' / cloud)
            module_dirs.append(Path(site.USER_BASE) / 'share' / 'resources' / 'modules' / cloud)
    except Exception:
        pass

    try:
        for site_dir in site.getsitepackages():
            module_dirs.append(Path(site_dir) / 'resources' / 'modules' / cloud)
    except Exception:
        pass

    for module_dir in module_dirs:
        if not module_dir.exists():
            continue

        for tf_file in module_dir.glob('**/*.tf'):
            module_name = tf_file.stem
            if module_name not in modules:
                modules[module_name] = tf_file

    return modules


def load_terraform_module(module_path: Path, resource_name: str) -> str:
    """
    Load a Terraform module and replace placeholders.
    
    Placeholders supported:
    - {{resource_name}}: The name of the resource
    """
    if not module_path.exists():
        return ""
    
    content = module_path.read_text(encoding='utf-8')
    
    # Replace placeholders
    content = content.replace('{{resource_name}}', resource_name)
    
    return content


def generate_resource_code(resource_type: str, resource_name: str) -> str:
    """
    Generate Terraform code for a specific resource type.
    
    Loads from Terraform (.tf) modules library.
    """
    
    # Try to find .tf module first
    available_modules = discover_available_modules(_detect_cloud_provider())

    if resource_type.lower() in available_modules:
        module_path = available_modules[resource_type.lower()]
        tf_code = load_terraform_module(module_path, resource_name)
        if tf_code:
            click.echo(f"   Using Terraform module: {module_path.name}")
            return tf_code
    
    # Module not found
    click.echo(f"⚠️  Module not found: {resource_type}")
    click.echo(f"\nAvailable modules:")
    for module_name in sorted(available_modules.keys()):
        click.echo(f"  • {module_name}")
    return ""
