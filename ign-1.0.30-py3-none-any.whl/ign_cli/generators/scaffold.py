"""scaffold – part of the ign CLI (split from ignition.py)."""

import click
from pathlib import Path
from typing import List
from ign_cli.console import cli_helper, console
from ign_cli.paths import LEGACY_FILE, SOURCE_ROOT


def create_aws_utils_module() -> None:
    """Create the templates/utils naming module for AWS."""
    utils_dir = Path('templates/utils')

    cli_helper.write_file(utils_dir / 'variables.tf',
        cli_helper.load_template('resources/templates/utils/aws/variables.tf'))
    cli_helper.write_file(utils_dir / 'main.tf',
        cli_helper.load_template('resources/templates/utils/aws/main.tf'))
    cli_helper.write_file(utils_dir / 'outputs.tf',
        cli_helper.load_template('resources/templates/utils/aws/outputs.tf'))


def create_aws_scaffold_templates() -> None:
    """Create scaffold templates for new stacks (AWS)."""
    scaffold_tf = Path('templates/scaffold/terraform')
    scaffold_yaml = Path('templates/scaffold/yaml')

    for fname in ['providers.tf', 'variables.tf', 'data.tf', 'locals.tf', 'outputs.tf']:
        cli_helper.write_file(scaffold_tf / fname,
            cli_helper.load_template(f'resources/templates/terraform/aws/{fname}.template'))

    cli_helper.write_file(scaffold_tf / 'main_intro.tf',
        cli_helper.load_template('resources/templates/terraform/aws/main.tf.template'))

    cli_helper.write_file(scaffold_tf / 'README.md', """\
# Stack Scaffold Template

This directory contains template files for creating new infrastructure stacks.

## Files

- `terraform/` - Terraform configuration templates
- `yaml/` - Azure Pipeline YAML templates (using AWS tasks)
- `azure-pipelines.yml` - Main pipeline configuration

## Usage

Use the CLI tool to generate new stacks based on these templates:

```bash
ign add-stack --stack-name <name>
```
""")

    for fname in ['build.yml', 'deploy.yml', 'state.yml']:
        cli_helper.write_file(scaffold_yaml / fname,
            cli_helper.load_template(f'resources/templates/yaml/aws/{fname}.template'))


def create_utils_module(project_code: str):
    """Create the templates/utils naming module."""
    
    utils_dir = Path('templates/utils')
    
    # variables.tf
    variables_content = """variable "location" {
  description = "Azure region for naming"
  type        = string
}

variable "project" {
  description = "Project name"
  type        = string
}

variable "lz" {
  description = "Landing zone code"
  type        = string
}

variable "suffix" {
  description = "Suffix for naming"
  type        = string
}

variable "lz_short" {
  description = "Short landing zone code"
  type        = string
  default     = ""
}
"""
    cli_helper.write_file(utils_dir / 'variables.tf', variables_content)
    
    # main.tf
    main_content = """locals {
  location_short_map = {
    "uksouth" = "uks"
    "ukwest"  = "ukw"
    "eastus"  = "eus"
    "westus"  = "wus"
  }

  location_short = lookup(local.location_short_map, var.location, "uks")
}
"""
    cli_helper.write_file(utils_dir / 'main.tf', main_content)
    
    # outputs.tf
    outputs_content = """output "name" {
  description = "Standardized names for Azure resources"
  value = {
    resource_group       = "rg-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    storage_account      = "st${local.location_short}${var.project}${var.lz}${var.suffix}"
    key_vault            = "kv-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    databricks_workspace = "dbw-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    data_factory         = "adf-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    virtual_network      = "vnet-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    sql_server           = "sql-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    app_service          = "app-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
  }
}

output "lz" {
  description = "Landing zone code"
  value       = var.lz
}

output "location_short" {
  description = "Short location code"
  value       = local.location_short
}
"""
    cli_helper.write_file(utils_dir / 'outputs.tf', outputs_content)


def create_scaffold_templates(include_yaml: bool = True):
    """Create scaffold templates for new stacks.

    include_yaml=False skips the Azure DevOps YAML scaffold (GitHub Actions
    projects use templates/scaffold/github instead)."""
    
    scaffold_dir = Path('templates/scaffold/terraform')
    
    # Load scaffold terraform templates from files
    data_content = cli_helper.load_template('resources/templates/terraform/base/data.tf.template')
    cli_helper.write_file(scaffold_dir / 'data.tf', data_content)
    
    locals_content = cli_helper.load_template('resources/templates/terraform/base/locals.tf.template')
    cli_helper.write_file(scaffold_dir / 'locals.tf', locals_content)
    
    main_content = cli_helper.load_template('resources/templates/terraform/base/main_intro.tf.template')
    cli_helper.write_file(scaffold_dir / 'main_intro.tf', main_content)
    
    outputs_content = cli_helper.load_template('resources/templates/terraform/base/outputs.tf.template')
    cli_helper.write_file(scaffold_dir / 'outputs.tf', outputs_content)

    providers_content = cli_helper.load_template('resources/templates/terraform/base/providers.tf.template')
    cli_helper.write_file(scaffold_dir / 'providers.tf', providers_content)

    variables_content = cli_helper.load_template('resources/templates/terraform/base/variables.tf.template')
    cli_helper.write_file(scaffold_dir / 'variables.tf', variables_content)


    if include_yaml:
        scaffoldyaml_dir = Path('templates/scaffold/yaml')

        # Load scaffold yaml templates from files
        build_content = cli_helper.load_template('resources/templates/yaml/build.yml.template')
        cli_helper.write_file(scaffoldyaml_dir / 'build.yml', build_content)

        deploy_content = cli_helper.load_template('resources/templates/yaml/deploy.yml.template')
        cli_helper.write_file(scaffoldyaml_dir / 'deploy.yml', deploy_content)

        state_content = cli_helper.load_template('resources/templates/yaml/state.yml.template')
        cli_helper.write_file(scaffoldyaml_dir / 'state.yml', state_content)

    pipeline_line = (
        "- `yaml/` - Azure Pipeline YAML templates\n- `azure-pipelines.yml` - Main pipeline configuration"
        if include_yaml else
        "- `../github/stack-workflow.yml` - GitHub Actions caller workflow written to `.github/workflows/<stack>.yml`"
    )

    # Scaffold README
    readme = f"""# Stack Scaffold Template

This directory contains template files for creating new infrastructure stacks.

## Files

- `terraform/` - Terraform configuration templates
{pipeline_line}

## Usage

Use the CLI tool to generate new stacks based on these templates:

```bash
ign add-stack --stack-name <name>
```
"""
    cli_helper.write_file(scaffold_dir / 'README.md', readme)


def discover_script_templates() -> List[str]:
    """Discover available script template files dynamically from resources/templates/scripts."""
    import sys
    import site

    template_rel_path = Path('resources') / 'templates' / 'scripts'
    tf_iac_rel_path = Path('templates') / 'scripts'
    search_dirs = [
        # 1. Development: next to ignition.py
        SOURCE_ROOT / template_rel_path,
        # 2. Current working directory
        Path.cwd() / template_rel_path,
        # 3. Sibling repository tf-iac-modules
        LEGACY_FILE.parents[3] / 'tf-iac-modules' / tf_iac_rel_path,
        Path.cwd().parent / 'tf-iac-modules' / tf_iac_rel_path,
        # 4. Installed package: sys.prefix
        Path(sys.prefix) / template_rel_path,
        Path(sys.prefix) / 'share' / template_rel_path,
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            search_dirs.append(Path(site.USER_BASE) / template_rel_path)
            search_dirs.append(Path(site.USER_BASE) / 'share' / template_rel_path)
    except (AttributeError, OSError, RuntimeError):
        # USER_BASE lookup is optional; ignore failures and continue best-effort discovery.
        pass

    try:
        for site_dir in site.getsitepackages():
            search_dirs.append(Path(site_dir) / template_rel_path)
    except (AttributeError, OSError):
        # Best-effort discovery: some Python environments do not expose
        # getsitepackages() or may deny access to site-package locations.
        # Continue with other search directories.
        pass

    found_files = set()
    for sdir in search_dirs:
        if sdir.is_dir():
            for item in sdir.iterdir():
                if item.is_file() and item.name != 'README.md' and not item.name.startswith('.'):
                    found_files.add(item.name)

    return sorted(found_files)


def discover_test_script_templates() -> List[str]:
    """Discover available test script template files dynamically from resources/templates/tests/scripts."""
    import sys
    import site

    template_rel_path = Path('resources') / 'templates' / 'tests' / 'scripts'
    tf_iac_rel_path = Path('templates') / 'tests' / 'scripts'
    search_dirs = [
        # 1. Development: next to ignition.py
        SOURCE_ROOT / template_rel_path,
        # 2. Current working directory
        Path.cwd() / template_rel_path,
        # 3. Sibling repository tf-iac-modules
        LEGACY_FILE.parents[3] / 'tf-iac-modules' / tf_iac_rel_path,
        Path.cwd().parent / 'tf-iac-modules' / tf_iac_rel_path,
        # 4. Installed package: sys.prefix
        Path(sys.prefix) / template_rel_path,
        Path(sys.prefix) / 'share' / template_rel_path,
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            search_dirs.append(Path(site.USER_BASE) / template_rel_path)
            search_dirs.append(Path(site.USER_BASE) / 'share' / template_rel_path)
    except Exception:
        # USER_BASE may be unavailable or inaccessible in some environments; ignore and continue discovery.
        pass

    try:
        for site_dir in site.getsitepackages():
            search_dirs.append(Path(site_dir) / template_rel_path)
    except Exception as e:
        # Best-effort discovery: some environments may not expose site-packages paths.
        console.print(f"[dim]Skipping site.getsitepackages() during template discovery: {e}[/dim]")

    found_files = set()
    for sdir in search_dirs:
        if sdir.is_dir():
            for item in sdir.iterdir():
                if item.is_file() and item.name != 'README.md' and not item.name.startswith('.'):
                    found_files.add(item.name)

    return sorted(found_files)


def copy_script_templates():
    """Copy script templates to the project."""
    
    scripts_dir = Path('templates/scripts')
    
    # Discover available script template files dynamically
    script_files = discover_script_templates()
    
    for script_file in script_files:
        try:
            script_content = cli_helper.load_template(f'resources/templates/scripts/{script_file}')
            cli_helper.write_file(scripts_dir / script_file, script_content)
        except FileNotFoundError:
            click.echo(f"⚠️  Warning: Script template not found: {script_file}")
    
    # Create README for scripts directory
    readme_content = """# Script Templates

This directory contains shell script templates for various Azure DevOps and Terraform operations.

## Azure Pipeline Scripts

### `azp-backend.sh`
Creates or updates Azure backend storage for Terraform state management. Sets up:
- Resource Group
- Storage Account with blob retention policies
- Storage Container for Terraform state files

### `azp-spn-generator.sh`
Creates or updates Service Principal Names (SPNs) with certificate-based authentication:
- Creates Key Vault for certificate storage
- Generates 10 SPNs with Owner role assignments
- Stores certificates securely in Key Vault

## Terraform Operation Scripts

### `tf-apply.sh`
Applies Terraform infrastructure changes with retry logic:
- Supports multiple var-file configurations
- Automatic retry on failure (up to 5 attempts)
- Special handling for firewall rules workspace

### `tf-destroy.sh`
Destroys Terraform infrastructure:
- Handles management group hierarchy cleanup
- Recursive deletion up to 6 levels deep
- Fallback manual cleanup on failure

### `tf-fmt.sh`
Formats Terraform files:
- Checks formatting across all files
- Shows differences
- Recursive formatting

### `tf-init.sh`
Initializes Terraform workspace:
- Configures Azure backend storage
- Sets up remote state management
- Handles subscription and storage account configuration

### `tf-install.sh`
Installs Terraform binary:
- Downloads Terraform 1.12.2 for Linux AMD64
- Extracts and installs to `/usr/local/bin`
- Sets up executable in system PATH

### `tf-plan.sh`
Generates Terraform execution plan:
- Supports environment-specific var files
- Special handling for firewall rules configurations
- Outputs plan file for apply stage

## Usage

These templates can be copied and customized for your specific Azure DevOps pipelines and Terraform workflows.
"""
    cli_helper.write_file(scripts_dir / 'README.md', readme_content)

    # Copy test script templates to templates/tests/scripts
    test_scripts_dir = Path('templates/tests/scripts')
    test_script_files = discover_test_script_templates()
    for test_script_file in test_script_files:
        try:
            test_script_content = cli_helper.load_template(f'resources/templates/tests/scripts/{test_script_file}')
            cli_helper.write_file(test_scripts_dir / test_script_file, test_script_content)
        except FileNotFoundError:
            click.echo(f"⚠️  Warning: Test script template not found: {test_script_file}")
