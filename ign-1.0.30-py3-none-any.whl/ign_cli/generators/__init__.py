"""Code generators and template/resource discovery used by the commands."""
