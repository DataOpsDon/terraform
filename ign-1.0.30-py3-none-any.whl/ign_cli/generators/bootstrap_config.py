"""bootstrap_config – part of the ign CLI (split from ignition.py)."""

import re
from pathlib import Path
from typing import Optional
from ign_cli.console import cli_helper
from ign_cli.core.stacks import get_location_short


def _create_aws_bootstrap_config(project_code: str, aws_region: str, project_name: str) -> None:
    """Create a minimal AWS bootstrap configuration file."""
    bootstrap_dir = Path('bootstrap/terraform')
    config_yaml = f"""# Global Variables
environment: "dev"
region: "{aws_region}"  # AWS region, e.g. eu-west-2, us-east-1
app_short: "{project_code}"
tags:
  environment: "dev"
  Creator: "{project_code}"
  ReviewDate: "YY/MM"

# State Variables (S3 backend)
accountId_state: "000000000000"  # AWS account ID for Terraform state bucket
stateBucketName: "tf-state-{project_code}"
stateBucketRegion: "{aws_region}"

# IAM Variables
accountId_application: "000000000000"  # AWS account ID for application deployment
accountName_application: "{project_name}"

# OIDC / IAM role Variables
iamRoleName_build: "iam-role-tf-build"
iamRoleName_deploy: "iam-role-tf-deploy"

# Optional CI variables
preventSelfReviewDeploy: false
deployApprovalRequired: false
"""
    cli_helper.write_file(bootstrap_dir / 'config.yaml', config_yaml)

    # Copy BOOTSTRAP-DOCUMENTATION.md template as README.md in project bootstrap directory
    try:
        doc_content = cli_helper.load_template('resources/bootstrap/BOOTSTRAP-DOCUMENTATION.md')
        cli_helper.write_file(bootstrap_dir / 'README.md', doc_content)
    except FileNotFoundError:
        pass


def _apply_cicd_to_bootstrap_config(config_yaml: str, cicd: str,
                                    github_org: Optional[str], github_repo: Optional[str],
                                    cicd_repo: Optional[str] = None) -> str:
    """Set the CI/CD platform keys in the bootstrap config.yaml text.

    Line-based so the comments in the template are preserved."""
    def set_key(text: str, key: str, value: str) -> str:
        pattern = re.compile(rf'^({re.escape(key)}:\s*)([^#\n]*?)(\s*(#.*)?)$', re.MULTILINE)
        if pattern.search(text):
            return pattern.sub(lambda m: f"{m.group(1)}{value}{m.group(3)}", text, count=1)
        return text

    config_yaml = set_key(config_yaml, 'cicdPlatform', f'"{cicd}"')
    if cicd == 'github':
        config_yaml = set_key(config_yaml, 'orgName_gh', f'"{github_org}"' if github_org else 'null')
        if github_repo:
            config_yaml = set_key(config_yaml, 'repositoryName_gh', f'"{github_repo}"')
        if cicd_repo:
            config_yaml = set_key(config_yaml, 'cicdRepoName_gh', f'"{cicd_repo}"')
        # No Azure DevOps resources for GitHub projects
        config_yaml = set_key(config_yaml, 'isFirstTimeDeployToADO', 'false')
        config_yaml = set_key(config_yaml, 'adoOrgUrl', 'null')
        config_yaml = set_key(config_yaml, 'adoProjectName', 'null')
        config_yaml = set_key(config_yaml, 'adoProjectDescription', 'null')
    else:
        # No GitHub resources for Azure DevOps projects
        config_yaml = set_key(config_yaml, 'isFirstTimeDeployToGH', 'false')
    return config_yaml


def create_bootstrap_config(project_code: str, location: str, project_name: str, cicd: str = 'ado',
                            github_org: Optional[str] = None, github_repo: Optional[str] = None,
                            cicd_repo: Optional[str] = None):
    """Create bootstrap configuration file in the project."""
    bootstrap_dir = Path('bootstrap/terraform')
    
    # Get location short code
    location_short = get_location_short(location)
    
    # Load config.yaml template and populate project-specific values
    config_yaml = cli_helper.load_template(
        'resources/bootstrap/terraform/config.yaml',
        location=location,
        location_short=location_short,
        project_code=project_code,
        project_name=project_name,
    )
    config_yaml = _apply_cicd_to_bootstrap_config(config_yaml, cicd, github_org, github_repo, cicd_repo)
    cli_helper.write_file(bootstrap_dir / 'config.yaml', config_yaml)
    
    # Create README.md for bootstrap directory using BOOTSTRAP-DOCUMENTATION.md template
    try:
        doc_content = cli_helper.load_template('resources/bootstrap/BOOTSTRAP-DOCUMENTATION.md')
        cli_helper.write_file(bootstrap_dir / 'README.md', doc_content)
    except FileNotFoundError:
        # README template is optional; continue bootstrap generation when it is not packaged.
        pass
