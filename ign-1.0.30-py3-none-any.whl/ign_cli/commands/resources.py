"""resources – part of the ign CLI (split from ignition.py)."""

import click
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.rule import Rule
from pathlib import Path
from ign_cli.console import console
from ign_cli.core.settings import _detect_cloud_provider
from ign_cli.core.stacks import _resolve_stack_dir
from ign_cli.generators.modules import discover_available_modules, generate_resource_code
from ign_cli.paths import SOURCE_ROOT
from ign_cli.core.prompts import select, select_stack


@click.command()
@click.option('--debug', is_flag=True, help='Show debug information about module search paths')
def list_modules(debug: bool):
    """List all available Terraform modules that can be added to stacks.
    
    This includes both .tf modules (in modules/ directory) and template-based modules.
    Contributors can add new modules by creating .tf files in the modules/ directory.
    """
    
    cloud = _detect_cloud_provider()
    cloud_label = "AWS" if cloud == 'aws' else "Azure"

    console.print()
    console.print(Rule(f"[bold cyan]📦  Available Terraform Modules ({cloud_label})[/bold cyan]", style="cyan"))
    console.print()

    # Show debug info if requested
    if debug:
        import sys
        import site
        console.print(f"[bold]🔍  Debug: Cloud platform detected as [cyan]{cloud_label}[/cyan]. Searching:[/bold]")
        search_paths = [
            SOURCE_ROOT / 'resources' / 'modules' / cloud,
            Path.cwd() / 'resources' / 'modules' / cloud,
            Path(sys.prefix) / 'resources' / 'modules' / cloud,
            Path(sys.prefix) / 'share' / 'resources' / 'modules' / cloud,
        ]
        try:
            if hasattr(site, 'USER_BASE') and site.USER_BASE:
                search_paths.append(Path(site.USER_BASE) / 'resources' / 'modules' / cloud)
        except:
            pass
        try:
            for site_dir in site.getsitepackages():
                search_paths.append(Path(site_dir) / 'resources' / 'modules' / cloud)
        except:
            pass

        for path in search_paths:
            if path.exists():
                console.print(f"  [green]✅[/green]  {path}")
            else:
                console.print(f"  [red]❌[/red]  [dim]{path}[/dim]")
        console.print()

    # Discover Terraform modules for the detected cloud
    tf_modules = discover_available_modules(cloud)
    
    if tf_modules:
        table = Table(
            box=box.SIMPLE,
            header_style="bold cyan",
            border_style="dim",
            show_header=True,
            pad_edge=False,
        )
        table.add_column("Module", style="bold white", no_wrap=True)
        table.add_column("Description", style="white")
        if debug:
            table.add_column("Path", style="dim", no_wrap=True)
        
        for module_name, module_path in sorted(tf_modules.items()):
            try:
                first_lines = module_path.read_text(encoding='utf-8').split('\n')[:3]
                description = ""
                for line in first_lines:
                    if line.strip().startswith('# Description:'):
                        description = line.replace('# Description:', '').strip()
                        break
            except Exception:
                description = ""
            
            if debug:
                try:
                    relative_path = module_path.relative_to(SOURCE_ROOT) if module_path.is_relative_to(SOURCE_ROOT) else module_path
                except Exception:
                    relative_path = module_path
                table.add_row(module_name, description or "[dim italic]No description[/dim italic]", str(relative_path))
            else:
                table.add_row(module_name, description or "[dim italic]No description[/dim italic]")
        
        console.print(table)
    else:
        console.print("[yellow]⚠️   No Terraform modules found[/yellow]")
        console.print("\n[dim]💡 Tip: Run with --debug flag to see search paths:[/dim]")
        console.print("   [bold]ign list-modules --debug[/bold]")
    
    console.print()
    console.print(Rule("[dim]Need a module or found a bug?[/dim]", style="dim"))
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", "Raise an issue: [link]https://github.com/telefonicatechuki/devops-cli/issues[/link]")
    grid.add_row("2.", "It will be reviewed and added to the library if new")
    grid.add_row("3.", "If this is a bug it will be triaged")
    grid.add_row("4.", "Raise a PR if you know the fix and get it merged!")
    console.print()
    console.print(grid)
    console.print()
    console.print("[dim]📖 See modules/README.md for contributor guide[/dim]")
    console.print()


@click.command()
@click.option('--stack-name', default=None, help='Name of the stack to add resource to (pick from a list if omitted)')
@click.option('--resource-type', default=None, help='Type of resource to add (pick from a list if omitted; run list-modules to see available)')
@click.option('--resource-name', default=None, help='Name for the resource (prompted if omitted)')
def add_resource(stack_name: str, resource_type: str, resource_name: str):
    """Add a resource to an existing stack.
    
    Run 'ign list-modules' to see all available resource types.
    """
    if not stack_name:
        stack_name = select_stack('Which stack do you want to add a resource to?')
    if not resource_type:
        _modules = discover_available_modules(_detect_cloud_provider())
        if not _modules:
            console.print('[bold red]❌  Error:[/bold red] [red]No resource modules found[/red]')
            return
        resource_type = select('Which resource do you want to add?', [(n, n) for n in sorted(_modules)])
    if not resource_name:
        resource_name = click.prompt('Resource name')

    console.print(Panel(
        f"[bold white]Resource:[/bold white] [cyan]{resource_type}[/cyan]  →  [bold white]Stack:[/bold white] [cyan]{stack_name}[/cyan]",
        title="[bold cyan]📦  Adding Resource[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()
    
    # Validate stack exists
    stack_dir = _resolve_stack_dir(stack_name)
    if stack_dir is None:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Stack '{stack_name}' not found.[/red]")
        console.print("[dim]Run [bold]ign list-stacks[/bold] to see available stacks.[/dim]")
        return

    terraform_dir = stack_dir / 'terraform'
    main_tf = terraform_dir / 'main.tf'
    
    if not main_tf.exists():
        console.print(f"[bold red]❌  Error:[/bold red] [red]{main_tf} not found.[/red]")
        return
    
    # Generate resource code
    resource_code = generate_resource_code(resource_type, resource_name)
    
    if not resource_code:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Could not generate code for {resource_type}[/red]")
        console.print(f"\n[dim]💡 Run [bold]ign list-modules[/bold] to see available resource types[/dim]")
        return
    
    # Read existing main.tf
    existing_content = main_tf.read_text(encoding='utf-8')
    
    # Check if resource already exists
    if f'module "{resource_name}"' in existing_content:
        console.print(f"[yellow]⚠️   Warning:[/yellow] [yellow]Resource '{resource_name}' already exists in {stack_name}[/yellow]")
        if not click.confirm("Overwrite?"):
            console.print("[yellow]Aborted.[/yellow]")
            return
    
    # Append resource to main.tf
    updated_content = existing_content.rstrip() + "\n\n" + resource_code
    main_tf.write_text(updated_content, encoding='utf-8')
    
    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Review the generated code in [bold]main.tf[/bold]")
    grid.add_row("2.", "Update variable values as needed")
    grid.add_row("3.", f"Run: [bold]cd stacks/{stack_name}/terraform && terraform plan[/bold]")
    console.print(Panel(
        grid,
        title=f"[bold green]✅  Added {resource_type} '{resource_name}' to {stack_name}[/bold green]",
        title_align="left",
        style="green",
        expand=False
    ))
    console.print()
