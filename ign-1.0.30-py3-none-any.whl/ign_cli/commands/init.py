"""init – part of the ign CLI (split from ignition.py)."""

import click
import re
from rich.panel import Panel
from rich.table import Table
from pathlib import Path
from typing import Optional
from ign_cli.console import cli_helper, console
from ign_cli.core.settings import CICD_LABELS, DEFAULT_CICD_REF, DEFAULT_CICD_REPO, _prompt_cicd_platform, _prompt_cloud_provider, _save_project_settings
from ign_cli.generators.bootstrap_config import _create_aws_bootstrap_config, create_bootstrap_config
from ign_cli.generators.cicd import _render_cicd_repo, create_aws_pipeline_templates, create_github_pipeline_templates, create_pipeline_templates
from ign_cli.generators.devcontainer import create_devcontainer
from ign_cli.generators.scaffold import copy_script_templates, create_aws_scaffold_templates, create_aws_utils_module, create_scaffold_templates, create_utils_module
from ign_cli.paths import _find_resource_dir


@click.command()
@click.option('--cloud', type=click.Choice(['aws', 'azure'], case_sensitive=False), default=None, help='Cloud provider (aws or azure)')
@click.option('--cicd', type=click.Choice(['ado', 'github'], case_sensitive=False), default=None, help='CI/CD tool: ado (Azure DevOps) or github (GitHub Actions, Azure only)')
@click.option('--project-name', default=None, help='Name of the infrastructure project')
@click.option('--location', default=None, help='Default Azure location (Azure only, default: uksouth)')
@click.option('--aws-region', default=None, help='AWS region (AWS only, default: eu-west-2)')
@click.option('--project-code', default=None, help='Short project code (e.g., edp)')
@click.option('--service-connection', default=None, help='Azure DevOps service connection name (ADO only)')
@click.option('--github-org', default=None, help='GitHub organisation that owns the repos (GitHub only)')
@click.option('--github-repo', default=None, help='Name of this infrastructure repository on GitHub (GitHub only)')
@click.option('--cicd-repo', default=None, help=f'Shared CI/CD templates repository name (GitHub only, default: {DEFAULT_CICD_REPO})')
@click.option('--cicd-ref', default=None, help=f'Tag/branch/SHA of the shared CI/CD repo to pin (GitHub only, default: {DEFAULT_CICD_REF})')
@click.option('--ign-wheel', default=None, envvar='IGN_WHEEL',
              type=click.Path(exists=True, dir_okay=False, resolve_path=True),
              help='Optional: a different ign-<version>-py3-none-any.whl to add to .devcontainer/wheels/ '
                   '(a wheel is bundled by default). Env: IGN_WHEEL')
def init(cloud: str, cicd: str, project_name: str, location: str, aws_region: str, project_code: str,
         service_connection: str, github_org: str, github_repo: str, cicd_repo: str, cicd_ref: str,
         ign_wheel: Optional[str]):
    """Initialize a new infrastructure project with full structure."""

    if not cloud:
        cloud = _prompt_cloud_provider()
    cloud = cloud.lower()

    if cloud == 'aws':
        if cicd and cicd.lower() == 'github':
            console.print("[bold red]❌  GitHub Actions templates are currently Azure-only.[/bold red] "
                          "Use [bold]--cicd ado[/bold] for AWS projects.")
            return
        cicd = 'ado'
    elif not cicd:
        cicd = _prompt_cicd_platform()
    cicd = cicd.lower()

    if not project_name:
        project_name = click.prompt('  Project name')
    if not project_code:
        project_code = click.prompt('  Project code', default='edp')

    if cloud == 'azure':
        if not location:
            location = click.prompt('  Azure location', default='uksouth')
        if cicd == 'ado':
            if not service_connection:
                service_connection = click.prompt('  Service connection', default='DataPlatform - Dev')
        else:
            service_connection = None
            if not github_org:
                github_org = click.prompt('  GitHub organisation')
            if not github_repo:
                default_repo = re.sub(r'[^A-Za-z0-9._-]+', '-', project_name).strip('-').lower() or project_code
                github_repo = click.prompt('  GitHub repository (this infra repo)', default=default_repo)
            if not cicd_repo:
                cicd_repo = click.prompt('  Shared CI/CD templates repo', default=DEFAULT_CICD_REPO)
            if not cicd_ref:
                cicd_ref = click.prompt('  CI/CD repo ref to pin (tag/branch/SHA)', default=DEFAULT_CICD_REF)
        region_display = location
    else:
        if not aws_region:
            aws_region = click.prompt('  AWS region', default='eu-west-2')
        location = None
        service_connection = None
        region_display = aws_region

    cloud_label = (
        "[bold #FF9900]⬡  AWS[/bold #FF9900]"
        if cloud == 'aws'
        else "[bold #0078D4]◆  Azure[/bold #0078D4]"
    )

    console.print()
    console.print(Panel(
        f"[bold white]Cloud:[/bold white]    {cloud_label}\n"
        f"[bold white]CI/CD:[/bold white]    {CICD_LABELS[cicd]}\n"
        f"[bold white]Project:[/bold white]  [cyan]{project_name}[/cyan]\n"
        f"[bold white]Region:[/bold white]   [cyan]{region_display}[/cyan]  "
        f"[bold white]Code:[/bold white] [cyan]{project_code}[/cyan]"
        + (f"\n[bold white]GitHub:[/bold white]   [cyan]{github_org}/{github_repo}[/cyan]  "
           f"[bold white]CI/CD repo:[/bold white] [cyan]{github_org}/{cicd_repo}@{cicd_ref}[/cyan]"
           if cicd == 'github' else ''),
        title="[bold cyan]🚀  Initializing Infrastructure Project[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()

    # Create base directory structure
    if cicd == 'github':
        base_dirs = [
            'stacks',
            'bootstrap/terraform',
            '.github/workflows',
            'scripts',
            'templates/scaffold/terraform',
            'templates/scaffold/github',
            'templates/scripts',
            'templates/utils',
            'templates/tests/scripts',
        ]
    elif cloud == 'aws':
        base_dirs = [
            'stacks',
            'bootstrap/terraform',
            'templates/scaffold/terraform',
            'templates/scaffold/yaml',
            'templates/scripts',
            'templates/yaml',
            'templates/utils',
            'templates/tests/scripts',
        ]
    else:
        base_dirs = [
            'stacks',
            'bootstrap/terraform',
            'templates/scaffold/terraform',
            'templates/scaffold/yaml',
            'templates/scripts',
            'templates/yaml',
            'templates/yaml/build',
            'templates/yaml/deploy',
            'templates/utils',
            'templates/tests/config/lint',
            'templates/tests/config/leaks',
            'templates/tests/scripts',
        ]
    
    for dir_path in base_dirs:
        cli_helper.create_directory(Path(dir_path))
    
    # Create root Makefile
    makefile_content = """# Infrastructure Makefile

#
# Makefile
#

TEST?=$$(go list ./... |grep -v 'vendor'|grep -v 'utils')

# Azure Pipelines

azp-strategy:
	@echo "==> Running script..."
	./templates/scripts/azp-strategy.ps1

azp-backend:
	@echo "==> Running script..."
	./templates/scripts/azp-backend.sh

azp-spn-generator:
	@echo "==> Running script..."
	./templates/scripts/azp-spn-generator.sh

# Terraform

tf-install:
	@echo "==> Running script..."
	./templates/scripts/tf-install.sh

tf-prepare:
	@echo "==> Running script..."
	./templates/scripts/tf-prepare.sh

tf-fmt:
	@echo "==> Running script..."
	./templates/scripts/tf-fmt.sh

tf-validate:
	@echo "==> Running script..."
	./templates/scripts/tf-validate.sh

tf-init:
	@echo "==> Running script..."
	./templates/scripts/tf-init.sh

tf-plan:
	@echo "==> Running script..."
	./templates/scripts/tf-plan.sh

tf-apply:
	@echo "==> Running script..."
	./templates/scripts/tf-apply.sh

tf-destroy:
	@echo "==> Running script..."
	./templates/scripts/tf-destroy.sh

# Terratest

terratest:
	@echo "==> Running Go test..."
	cd tests/terratest && go test $(TEST) $(TESTARGS) -run ^$(TESTPREFIX)

# OPA Conftest

opa-install:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-install-linux.sh

opa-run-tests:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-run-tests.sh

opa-update-values:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-update-values.ps1 -GENERATE_AUTO_TFVARS

opa-update-git:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-update-git.sh

docs:
	terraform-docs .

.PHONY: azp-strategy azp-backend azp-spn-generator docs tf-install tf-prepare tf-fmt tf-validate tf-init tf-plan tf-apply tf-destroy terratest opa-install opa-run-tests opa-update-values opa-update-git
"""
    cli_helper.write_file(Path('Makefile'), makefile_content)
    
    # Create root README
    if cloud == 'aws':
        cloud_prereqs = "- AWS CLI\n- Terraform >= 1.5.0\n- AWS IAM access with appropriate permissions"
        cloud_cicd = (
            "Each stack includes CI/CD configuration for automated deployments:\n\n"
            "- **Build**: Validates and plans Terraform changes\n"
            "- **Deploy**: Applies Terraform configurations to target environments\n"
            "- **State**: Manages Terraform state in S3"
        )
        cloud_config_section = f"### Region\n\nDefault region: `{aws_region}`"
    elif cicd == 'github':
        cloud_prereqs = (
            "- Azure CLI\n"
            "- Terraform >= 1.5.0\n"
            "- GitHub CLI (`gh`) and access to the GitHub organisation"
        )
        cloud_cicd = (
            "Each stack has a caller workflow in `.github/workflows/<stack>.yml` that uses the shared "
            f"reusable pipeline in [`{github_org}/{cicd_repo}`](https://github.com/{github_org}/{cicd_repo}) "
            f"(pinned to `{cicd_ref}`):\n\n"
            "- **CI**: `terraform init`, `fmt`, `validate` and a Checkov scan\n"
            "- **Plan**: plan uploaded as an artifact and posted to the pull request\n"
            "- **Apply**: applies the reviewed plan on `develop` (dev) / `main` (prd), gated by the "
            "`<env>/apply` GitHub environment\n"
            "- **Auth**: OIDC federated credentials to Azure - no stored secrets\n"
            "- **State**: Terraform state in Azure Storage (azurerm backend)\n\n"
            "| Branch / event | Environment | Apply |\n"
            "|---|---|---|\n"
            "| `feature/**` push, PR into `develop` | `dev` | no |\n"
            "| `develop` push | `dev` | yes |\n"
            "| PR into `main` | `prd` | no |\n"
            "| `main` push | `prd` | yes |"
        )
        cloud_config_section = (
            "### GitHub Environments\n\n"
            "Create the `dev`, `dev/apply`, `prd` and `prd/apply` environments and set the "
            "`AZURE_*` / `TF_STATE_*` variables on each. `ign bootstrap` prints the exact "
            "`gh variable set` commands; `scripts/setup-github-oidc.ps1` is an alternative "
            "if you are not using bootstrap. Add required reviewers to the `*/apply` environments."
        )
    else:
        cloud_prereqs = (
            "- Azure CLI\n"
            "- Terraform >= 1.5.0\n"
            "- Azure DevOps access with appropriate permissions"
        )
        cloud_cicd = (
            "Each stack includes Azure Pipelines configuration for automated deployments:\n\n"
            "- **Build**: Validates and plans Terraform changes\n"
            "- **Deploy**: Applies Terraform configurations to target environments\n"
            "- **State**: Manages Terraform state in Azure Storage"
        )
        cloud_config_section = (
            f"### Service Connections\n\n"
            f"Configure service connections in Azure DevOps:\n"
            f"- Service Connection: `{service_connection}`"
        )

    if cicd == 'github':
        structure_extra = "├── .github/workflows/   # One caller workflow per stack\n├── scripts/             # setup-github-oidc.ps1 (manual OIDC setup)\n"
        structure_yaml = ""
    else:
        structure_extra = ""
        structure_yaml = "│   ├── yaml/            # CI/CD pipeline templates\n"

    readme_content = f"""# {project_name} Infrastructure

This repository contains Infrastructure as Code (IaC) for the {project_name} project.

## Project Structure

```
.
├── stacks/              # Deployment stacks (dlz, dmz, unity-catalog, etc.)
{structure_extra}├── templates/           # Reusable templates and utilities
│   ├── scaffold/        # Stack scaffolding templates
│   ├── scripts/         # Terraform scripts called by the Makefile / pipelines
│   ├── utils/           # Terraform utility modules
{structure_yaml}│   └── tests/           # Testing configurations
└── Makefile            # Common operations
```

## Getting Started

### Prerequisites

{cloud_prereqs}

### Adding a New Stack

Use the CLI to add a new deployment stack:

```bash
ign add-stack --stack-name <name>
```

### Manual Deployment

1. Navigate to the stack directory:
   ```bash
   cd stacks/<stack-name>/terraform
   ```

2. Initialize Terraform:
   ```bash
   terraform init
   ```

3. Plan the deployment:
   ```bash
   terraform plan -var-file="tfvars/dev.tfvars"
   ```

4. Apply the changes:
   ```bash
   terraform apply -var-file="tfvars/dev.tfvars"
   ```

## CI/CD Pipelines

{cloud_cicd}

## Configuration

### Environment Variables

Each stack supports multiple environments:
- `dev` - Development
- `tst` - Test
- `uat` - User Acceptance Testing
- `prd` - Production

{cloud_config_section}

## Contributing

1. Create a feature branch
2. Make your changes
3. Test locally
4. Submit a pull request

## Support

For questions or issues, contact the DevOps team.
"""
    cli_helper.write_file(Path('README.md'), readme_content)

    if cloud == 'aws':
        create_aws_utils_module()
        create_aws_pipeline_templates(aws_region)
        create_aws_scaffold_templates()
    elif cicd == 'github':
        create_utils_module(project_code)
        create_scaffold_templates(include_yaml=False)
        create_github_pipeline_templates(github_org, cicd_repo, cicd_ref, github_repo)
    else:
        create_utils_module(project_code)
        create_pipeline_templates()
        create_scaffold_templates()

    # Copy script templates (same for both clouds / CI/CD tools)
    copy_script_templates()

    # Standard dev container so the cloned repo opens with ign and the tooling installed
    create_devcontainer(ign_wheel)

    # Create bootstrap configuration (Azure-specific; AWS generates a minimal placeholder)
    if cloud == 'azure':
        create_bootstrap_config(project_code, location, project_name, cicd=cicd,
                                github_org=github_org, github_repo=github_repo,
                                cicd_repo=cicd_repo)
    else:
        _create_aws_bootstrap_config(project_code, aws_region, project_name)

    settings = {'cloud': cloud, 'cicd': cicd}
    if cicd == 'github':
        settings.update({
            'github_org': github_org,
            'github_repo': github_repo,
            'cicd_repo': cicd_repo,
            'cicd_ref': cicd_ref,
        })
    _save_project_settings(settings)

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", "Review the generated structure")
    if cicd == 'github':
        grid.add_row("2.", f"Create the shared CI/CD repo if it doesn't exist: [bold]ign init-cicd-repo --github-org {github_org} --cicd-repo {cicd_repo}[/bold]")
        grid.add_row("3.", "Configure bootstrap: Edit [bold]bootstrap/terraform/config.yaml[/bold] with your subscription IDs")
        grid.add_row("4.", "Run bootstrap: [bold]ign bootstrap --apply[/bold]  then run the printed [bold]gh variable set[/bold] commands")
        grid.add_row("5.", "Add your first stack: [bold]ign add-stack[/bold]  (creates [bold].github/workflows/<stack>.yml[/bold])")
        console.print()
        console.print(Panel(grid, title="[bold green]✅  Project Initialized Successfully![/bold green]", title_align="left", style="green", expand=False))
        console.print()
        return
    if cloud == 'azure':
        grid.add_row("2.", "Configure bootstrap: Edit [bold]bootstrap/terraform/config.yaml[/bold] with your subscription IDs")
        grid.add_row("3.", "Run bootstrap: [bold]ign bootstrap --plan-only[/bold]  (or [bold]--apply[/bold])")
    else:
        grid.add_row("2.", "Configure bootstrap: Edit [bold]bootstrap/terraform/config.yaml[/bold] with your AWS account details")
        grid.add_row("3.", "Run bootstrap: [bold]ign bootstrap --plan-only[/bold]  (or [bold]--apply[/bold])")
    grid.add_row("4.", "Add your first stack: [bold]ign add-stack[/bold]")
    grid.add_row("5.", "Customize templates in the [bold]templates/[/bold] directory")
    console.print(Panel(grid, title="[bold green]✅  Project Initialized Successfully![/bold green]", title_align="left", style="green", expand=False))
    console.print()


@click.command('init-cicd-repo')
@click.option('--github-org', default=None, help='GitHub organisation that will own the shared CI/CD repo')
@click.option('--cicd-repo', default=None, help=f'Repository name (default: {DEFAULT_CICD_REPO})')
@click.option('--cicd-ref', default=None, help=f'Ref the reusable workflow uses for its own composite actions (default: {DEFAULT_CICD_REF})')
@click.option('--output-dir', default=None, help='Directory to write into (default: ./<cicd-repo>)')
@click.option('--force', is_flag=True, default=False, help='Overwrite files in a non-empty output directory')
def init_cicd_repo(github_org: str, cicd_repo: str, cicd_ref: str, output_dir: str, force: bool):
    """Scaffold the shared GitHub Actions CI/CD repo for Azure Terraform.

    Creates the reusable workflow (_terraform-pipeline.yml), the tf-ci / tf-plan /
    tf-apply composite actions and a release workflow. Push the result to
    GitHub as <github-org>/<cicd-repo>; projects created with
    `ign init --cicd github` call it from .github/workflows/<stack>.yml.
    """
    if not github_org:
        github_org = click.prompt('  GitHub organisation')
    if not cicd_repo:
        cicd_repo = click.prompt('  CI/CD repo name', default=DEFAULT_CICD_REPO)
    if not cicd_ref:
        cicd_ref = click.prompt('  Ref for internal action references (tag/branch/SHA)', default=DEFAULT_CICD_REF)

    source = _find_resource_dir('resources/templates/pipelines/github/cicd-repo')
    if source is None:
        console.print("[bold red]❌  CI/CD repo templates not found in the installed package.[/bold red]")
        return

    target = Path(output_dir) if output_dir else Path(cicd_repo)
    if target.exists() and any(target.iterdir()) and not force:
        console.print(f"[bold red]❌  {target} is not empty.[/bold red] Use [bold]--force[/bold] to overwrite.")
        return

    console.print(Panel(
        f"[bold white]Repo:[/bold white] [cyan]{github_org}/{cicd_repo}[/cyan]\n"
        f"[bold white]Into:[/bold white] [cyan]{target}[/cyan]",
        title="[bold cyan]🔁  Scaffolding Shared GitHub Actions CI/CD Repo (Azure)[/bold cyan]",
        title_align="left", style="cyan", expand=False,
    ))
    console.print()

    count = _render_cicd_repo(source, target, github_org, cicd_repo, cicd_ref)
    console.print(f"[green]✓[/green] Rendered {count} files into [cyan]{target}[/cyan]")

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Push to GitHub: [bold]cd {target} && git init -b main && git add . && git commit -m 'Initial CI/CD templates'[/bold]")
    grid.add_row("2.", f"Create the repo: [bold]gh repo create {github_org}/{cicd_repo} --private --source . --push[/bold]")
    grid.add_row("3.", "Settings → Actions → General → Access: allow repositories in the organisation")
    grid.add_row("4.", f"Create the [bold]{cicd_repo}-maintainers[/bold] team (CODEOWNERS) - or let [bold]ign bootstrap[/bold] create the whole repo")
    grid.add_row("5.", "After the first release, pin consumers (and the internal action refs) to the tag")
    console.print(Panel(grid, title="[bold green]✅  CI/CD Repo Scaffolded[/bold green]", title_align="left", style="green", expand=False))
    console.print()
