"""quality – part of the ign CLI (split from ignition.py)."""

import click
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.rule import Rule
from pathlib import Path
from ign_cli.console import console
from ign_cli.core.stacks import STACK_DIRS, _iter_all_stacks, _resolve_stack_dir
from ign_cli.paths import LEGACY_FILE
from ign_cli.core.prompts import select_stack_or_all


@click.command()
@click.option('--stack', default=None, help='Name of the stack to validate (e.g. dlz, dmz)')
@click.option('--all', 'validate_all', is_flag=True, default=False, help='Validate all stacks and templates in the project')
@click.option('--config', 'yamllint_config', default=None, help='Path to a custom yamllint config file')
def validate(stack: str, validate_all: bool, yamllint_config: str):
    """Validate YAML files in a stack or across the whole project.

    Checks every .yml / .yaml file for syntax errors and linting issues.
    Use --stack to target one stack, or --all to scan everything.
    """
    try:
        from yamllint import linter as yamllinter
        from yamllint.config import YamlLintConfig
    except ImportError:
        console.print("[bold red]❌  Error:[/bold red] [red]yamllint is required but not installed.[/red]")
        console.print("   Install it with: [bold]pip install yamllint[/bold]")
        return

    # ------------------------------------------------------------------
    # Resolve scope
    # ------------------------------------------------------------------
    if not stack and not validate_all:
        console.print()
        stack, validate_all = select_stack_or_all("Validate a single stack or the whole project?", all_label='The whole project', default_all=False)

    # Collect target directories
    scan_dirs: list[Path] = []
    project_root = Path.cwd()

    if validate_all:
        scan_dirs.append(project_root)
        scope_label = "Whole Project"
    else:
        stack_dir = _resolve_stack_dir(stack, project_root)
        if stack_dir is None:
            console.print(f"[bold red]❌  Error:[/bold red] [red]Stack '{stack}' not found.[/red]")
            console.print("[dim]Run [bold]ign list-stacks[/bold] to see available stacks.[/dim]")
            return
        scan_dirs.append(stack_dir)
        scope_label = f"Stack: {stack}"

    # ------------------------------------------------------------------
    # Build yamllint config
    # ------------------------------------------------------------------
    if yamllint_config:
        cfg_path = Path(yamllint_config)
        if not cfg_path.exists():
            console.print(f"[bold red]❌  Error:[/bold red] [red]Config file not found: {yamllint_config}[/red]")
            return
        lint_cfg = YamlLintConfig(file=str(cfg_path))
    else:
        # Sensible defaults for Azure Pipelines / Terraform YAML
        lint_cfg = YamlLintConfig("""\
extends: default
rules:
  line-length:
    max: 250
    level: warning
  truthy:
    allowed-values: ['true', 'false', 'yes', 'no', 'on', 'off']
    level: warning
  comments:
    min-spaces-from-content: 1
    level: warning
  indentation:
    spaces: 2
    indent-sequences: whatever
    check-multi-line-strings: false
  document-start: disable
""")

    # ------------------------------------------------------------------
    # Discover YAML files
    # ------------------------------------------------------------------
    yaml_files: list[Path] = []
    skip_dirs = {'.git', '__pycache__', '.terraform', 'node_modules'}
    for scan_dir in scan_dirs:
        for pattern in ('**/*.yml', '**/*.yaml'):
            for f in scan_dir.glob(pattern):
                if not any(part in skip_dirs for part in f.parts):
                    yaml_files.append(f)

    yaml_files = sorted(set(yaml_files))

    if not yaml_files:
        console.print(Panel(
            f"[yellow]No YAML files found in scope:[/yellow] [bold]{scope_label}[/bold]",
            style="yellow", expand=False
        ))
        return

    # ------------------------------------------------------------------
    # Header
    # ------------------------------------------------------------------
    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]   "
        f"[bold white]Files found:[/bold white] [cyan]{len(yaml_files)}[/cyan]",
        title="[bold cyan]🔍  Validating YAML[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    # ------------------------------------------------------------------
    # Lint each file
    # ------------------------------------------------------------------
    results_table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        border_style="cyan",
        show_lines=False,
        expand=True,
    )
    results_table.add_column("File", style="white", no_wrap=False, ratio=5)
    results_table.add_column("Status", justify="center", width=12)
    results_table.add_column("Errors", justify="right", width=8)
    results_table.add_column("Warnings", justify="right", width=10)

    total_errors = 0
    total_warnings = 0
    files_ok = 0
    files_with_issues: list[tuple[Path, list]] = []

    for yaml_file in yaml_files:
        try:
            content = yaml_file.read_text(encoding='utf-8')
        except Exception as e:
            results_table.add_row(
                str(yaml_file.relative_to(project_root)),
                "[red]READ ERROR[/red]",
                "[red]–[/red]", "[red]–[/red]",
            )
            total_errors += 1
            continue

        problems = list(yamllinter.run(content, lint_cfg))
        errors = [p for p in problems if p.level == 'error']
        warnings = [p for p in problems if p.level == 'warning']

        total_errors += len(errors)
        total_warnings += len(warnings)

        try:
            rel = yaml_file.relative_to(project_root)
        except ValueError:
            rel = yaml_file

        if errors:
            status = "[bold red]✗  ERROR[/bold red]"
            files_with_issues.append((yaml_file, problems))
        elif warnings:
            status = "[yellow]⚠  WARN[/yellow]"
            files_with_issues.append((yaml_file, problems))
            files_ok += 1
        else:
            status = "[green]✓  OK[/green]"
            files_ok += 1

        err_cell = f"[red]{len(errors)}[/red]" if errors else "[dim]0[/dim]"
        warn_cell = f"[yellow]{len(warnings)}[/yellow]" if warnings else "[dim]0[/dim]"
        results_table.add_row(str(rel), status, err_cell, warn_cell)

    console.print(results_table)

    # ------------------------------------------------------------------
    # Detail panel for files with issues
    # ------------------------------------------------------------------
    if files_with_issues:
        console.print()
        console.print(Rule("[bold]Issue Details[/bold]", style="dim"))
        for yaml_file, problems in files_with_issues:
            try:
                rel = yaml_file.relative_to(project_root)
            except ValueError:
                rel = yaml_file

            issue_table = Table(
                box=box.SIMPLE,
                show_header=True,
                header_style="bold",
                pad_edge=False,
            )
            issue_table.add_column("Line", style="dim", width=6, justify="right")
            issue_table.add_column("Col", style="dim", width=5, justify="right")
            issue_table.add_column("Level", width=10)
            issue_table.add_column("Message")

            for p in problems:
                level_str = "[red]error[/red]" if p.level == 'error' else "[yellow]warning[/yellow]"
                issue_table.add_row(str(p.line), str(p.column), level_str, p.message)

            console.print(f"\n  [bold white]{rel}[/bold white]")
            console.print(issue_table)

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    console.print()
    files_errored = sum(1 for _, problems in files_with_issues if any(p.level == 'error' for p in problems))
    files_warned = sum(1 for _, problems in files_with_issues if not any(p.level == 'error' for p in problems))

    summary_grid = Table.grid(padding=(0, 3))
    summary_grid.add_column(style="bold", no_wrap=True)
    summary_grid.add_column()
    summary_grid.add_row("[cyan]Files checked[/cyan]", str(len(yaml_files)))
    summary_grid.add_row("[green]✓  Valid[/green]", str(len(yaml_files) - files_errored))
    summary_grid.add_row("[yellow]⚠  Warnings[/yellow]", str(files_warned))
    summary_grid.add_row("[red]✗  Errors[/red]", str(files_errored))

    if files_errored:
        summary_style = "red"
        summary_title = "[bold red]✗  Validation Failed[/bold red]"
    elif files_warned:
        summary_style = "yellow"
        summary_title = "[bold yellow]⚠  Validation Passed with Warnings[/bold yellow]"
    else:
        summary_style = "green"
        summary_title = "[bold green]✅  All YAML Files Valid[/bold green]"

    console.print(Panel(
        summary_grid,
        title=summary_title,
        title_align="left",
        style=summary_style,
        expand=False,
    ))
    console.print()

    if files_errored:
        raise click.exceptions.Exit(code=1)


# =============================================================================
# ign lint-tf
# =============================================================================

@click.command("lint-tf")
@click.option("--stack", default=None, help="Stack to lint")
@click.option("--all",   "lint_all", is_flag=True, help="Lint all stacks")
@click.option("--fix",   is_flag=True, help="Auto-format with terraform fmt (modifies files)")
def lint_tf(stack, lint_all, fix):
    """Run terraform fmt and validate across one or all stacks.

    Use --fix to automatically reformat rather than just report.
    validate is skipped for stacks not yet initialised (no .terraform/).
    """
    import subprocess
    import os
    import json as _json

    if not stack and not lint_all:
        stack, lint_all = select_stack_or_all("Lint a stack or all stacks?", all_label='All stacks', default_all=False)

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target = (
        [p.name for p in _iter_all_stacks()]
        if lint_all else [stack]
    )
    scope_label = "All Stacks" if lint_all else f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]   "
        f"[bold white]Mode:[/bold white] [cyan]{'fix (auto-format)' if fix else 'check only'}[/cyan]",
        title="[bold cyan]🔧  Terraform Linter[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Stack",    style="bold white", no_wrap=True)
    table.add_column("fmt",      justify="center", width=14)
    table.add_column("validate", justify="center", width=22)
    table.add_column("Notes",    style="dim")

    original_dir = Path.cwd()
    ok_n = warn_n = err_n = 0

    for sname in target:
        tf_dir = (_resolve_stack_dir(sname) or (stacks_dir / sname)) / "terraform"
        if not tf_dir.exists():
            table.add_row(sname, "[dim]—[/dim]", "[dim]—[/dim]", "No terraform/ directory")
            warn_n += 1
            continue

        fmt_args = ["terraform", "fmt"]
        if not fix:
            fmt_args.append("-check")
        fmt_args.append(str(tf_dir))

        fmt_cell      = "[dim]—[/dim]"
        validate_cell = "[dim]—[/dim]"
        notes         = ""

        try:
            r = subprocess.run(fmt_args, capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                fmt_cell = "[cyan]✓  Fixed[/cyan]" if fix else "[green]✓  OK[/green]"
            else:
                fmt_cell = "[red]✗  fmt failed[/red]" if fix else "[yellow]⚠  Needs fmt[/yellow]"
                notes = (r.stderr or r.stdout).strip()[:60]
        except FileNotFoundError:
            fmt_cell = "[red]✗  not found[/red]"
            notes    = "Terraform not installed"
            table.add_row(sname, fmt_cell, "[dim]—[/dim]", notes)
            err_n += 1
            continue
        except Exception as e:
            fmt_cell = "[red]✗  error[/red]"
            notes    = str(e)[:60]

        if (tf_dir / ".terraform").exists():
            try:
                os.chdir(tf_dir)
                r = subprocess.run(
                    ["terraform", "validate", "-json"],
                    capture_output=True, text=True, timeout=30,
                )
                os.chdir(original_dir)
                if r.returncode == 0:
                    validate_cell = "[green]✓  Valid[/green]"
                else:
                    try:
                        vdata = _json.loads(r.stdout)
                        errs  = [d for d in vdata.get("diagnostics", [])
                                 if d.get("severity") == "error"]
                        validate_cell = f"[red]✗  {len(errs)} error(s)[/red]"
                        if errs:
                            notes = errs[0].get("summary", "")[:60]
                    except Exception:
                        validate_cell = "[red]✗  failed[/red]"
            except Exception as e:
                os.chdir(original_dir)
                validate_cell = "[red]✗  error[/red]"
                notes         = str(e)[:60]
        else:
            validate_cell = "[dim]skipped (run terraform init)[/dim]"

        has_err  = "✗" in (fmt_cell + validate_cell)
        has_warn = "⚠" in fmt_cell or "skipped" in validate_cell
        if has_err:    err_n  += 1
        elif has_warn: warn_n += 1
        else:          ok_n   += 1

        table.add_row(sname, fmt_cell, validate_cell, notes)

    console.print(table)
    console.print()

    if err_n:
        style = "red"
        title = f"[bold red]✗  {err_n} stack(s) with errors[/bold red]"
        console.print(Panel(title, title_align="left", style=style, expand=False))
        raise click.exceptions.Exit(code=1)
    elif warn_n and not fix:
        hint = Table.grid(padding=(0, 2))
        hint.add_column()
        hint.add_row("[dim]Run [bold]ign lint-tf --fix[/bold] (or [bold]--all --fix[/bold]) to auto-format.[/dim]")
        console.print(Panel(
            hint,
            title=f"[bold yellow]⚠  {warn_n} stack(s) need formatting[/bold yellow]",
            title_align="left", style="yellow", expand=False,
        ))
    else:
        console.print(Panel(
            "[bold green]✅  All Terraform Files Pass[/bold green]",
            title_align="left", style="green", expand=False,
        ))
    console.print()


# =============================================================================
# ign pr-check
# =============================================================================

@click.command("pr-check")
@click.argument("stack", required=False)
@click.option("--all", "check_all", is_flag=True, help="Run against all stacks")
def pr_check(stack, check_all):
    """Run all quality gates (validate, lint-tf, secrets, checklist) in one pass.

    Exits with code 1 if any gate fails — suitable for CI pipelines.
    """
    import subprocess
    import sys

    if not stack and not check_all:
        stack, check_all = select_stack_or_all("Check a single stack or all?", all_label='All stacks', default_all=False)

    scope = "All Stacks" if check_all else stack

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope}[/cyan]",
        title="[bold cyan]🚦  PR Quality Gate[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    gates = [
        ("YAML Validate",  ["validate"]  + (["--all"] if check_all else ["--stack", stack])),
        ("Terraform Lint", ["lint-tf"]   + (["--all"] if check_all else ["--stack", stack])),
        ("Secret Scan",    ["secrets"]   + (["--all"] if check_all else ["--stack", stack])),
        ("Checklist",      ["checklist"] + (["--all"] if check_all else ["--stack", stack])),
    ]

    results = []
    overall_pass = True

    for gate_name, args in gates:
        console.print(Rule(f"[bold white]{gate_name}[/bold white]", style="dim"))
        result = subprocess.run(
            [sys.executable, str(LEGACY_FILE)] + args,
            capture_output=False,
        )
        passed = result.returncode == 0
        if not passed:
            overall_pass = False
        results.append((gate_name, passed))
        console.print()

    # Summary table
    t = Table(box=box.ROUNDED, header_style="bold cyan", border_style="cyan", expand=False)
    t.add_column("Gate",   style="bold white", min_width=20)
    t.add_column("Result", justify="center", width=10)
    for gname, passed in results:
        icon = "[bold green]✅  PASS[/bold green]" if passed else "[bold red]✗  FAIL[/bold red]"
        t.add_row(gname, icon)

    console.print(t)
    console.print()

    if overall_pass:
        console.print(Panel(
            "[bold green]✅  All gates passed — ready to merge![/bold green]",
            style="green",
            expand=False,
        ))
    else:
        console.print(Panel(
            "[bold red]✗  One or more gates failed. Fix issues before merging.[/bold red]",
            style="red",
            expand=False,
        ))
        sys.exit(1)

    console.print()
