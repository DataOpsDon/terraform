"""security – part of the ign CLI (split from ignition.py)."""

import click
import re
from rich.panel import Panel
from rich.table import Table
from rich.rule import Rule
from pathlib import Path
from typing import Dict, List
from ign_cli.console import console
from ign_cli.core.stacks import _iter_all_stacks, _resolve_stack_dir
from ign_cli.core.prompts import select_stack_or_all


# =============================================================================
# Secret scanning patterns (module-level, used by `secrets` command)
# =============================================================================

_SECRET_PATTERNS = [
    (re.compile(r"DefaultEndpointsProtocol=https?;AccountName=", re.I),
     "Azure Storage connection string", "critical"),
    (re.compile(r"[?&]sig=[A-Za-z0-9+/%]{20,}"),
     "SAS token", "critical"),
    (re.compile(r"-----BEGIN\s+(?:RSA\s+|EC\s+)?PRIVATE KEY-----"),
     "Private key", "critical"),
    (re.compile(
        r'(?i)(?:password|secret|client_secret|access_key|account_key|api_key|pat|token)'
        r'\s*[=:]\s*["\x27](?!\$\{|var\.|local\.|module\.)[^"\x27]{8,}["\x27]'
    ), "Potential hardcoded credential", "high"),
    (re.compile(
        r'(?i)(?:subscription_id|tenant_id|client_id)\s*=\s*"'
        r'(?!00000000-0000-0000-0000-000000000000)'
        r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"'
    ), "Real subscription/tenant/client ID", "medium"),
]


_SEVERITY_COLOUR = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "dim yellow",
}


_SCAN_EXTENSIONS = {".tf", ".tfvars", ".yml", ".yaml", ".json", ".env", ".sh", ".ps1"}


_SKIP_DIRS = {".git", "__pycache__", ".terraform", "node_modules", ".tfsec"}


_PLACEHOLDER_UUID = "00000000-0000-0000-0000-000000000000"


# =============================================================================
# ign secrets
# =============================================================================

@click.command()
@click.option("--stack", default=None, help="Scan a specific stack")
@click.option("--all", "scan_all", is_flag=True, help="Scan the whole project")
def secrets(stack, scan_all):
    """Scan for accidentally committed secrets and credentials."""
    project_root = Path.cwd()

    if not stack and not scan_all:
        stack, scan_all = select_stack_or_all("Scan a stack or whole project?", all_label='The whole project', default_all=True)

    if scan_all:
        scan_root = project_root
        scope_label = "Whole Project"
    else:
        scan_root = _resolve_stack_dir(stack, project_root)
        if scan_root is None:
            console.print(f"[bold red]❌  Stack '{stack}' not found.[/bold red]")
            return
        scope_label = f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]",
        title="[bold cyan]🔐  Secret Scanner[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    files = [
        f for f in scan_root.rglob("*")
        if f.is_file()
        and f.suffix in _SCAN_EXTENSIONS
        and not any(part in _SKIP_DIRS for part in f.parts)
    ]

    findings = []
    for fpath in sorted(files):
        try:
            lines = fpath.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception:
            continue
        for lineno, line in enumerate(lines, 1):
            for pattern, label, severity in _SECRET_PATTERNS:
                if pattern.search(line):
                    snippet = line.strip()[:80]
                    try:
                        rel = str(fpath.relative_to(project_root))
                    except ValueError:
                        rel = str(fpath)
                    findings.append((rel, lineno, label, snippet, severity))

    if not findings:
        console.print(Panel(
            "[bold green]No secrets or credentials detected.[/bold green]\n"
            "[dim]This does not guarantee absence of secrets — always review before pushing.[/dim]",
            title="[bold green]✅  Scan Clean[/bold green]",
            title_align="left",
            style="green",
            expand=False,
        ))
        console.print()
        return

    crit = high = med = low = 0
    console.print()
    for rel, lineno, label, snippet, severity in findings:
        colour = _SEVERITY_COLOUR.get(severity, "white")
        badge  = f"[{colour}] {severity.upper():<8} [/{colour}]"
        console.print(f"  {badge}  [bold white]{label}[/bold white]")
        console.print(f"            [cyan]{rel}[/cyan][dim]:{lineno}[/dim]")
        console.print(f"            [dim italic]{snippet}[/dim italic]")
        console.print()
        if severity == "critical":   crit += 1
        elif severity == "high":     high += 1
        elif severity == "medium":   med  += 1
        else:                        low  += 1
    console.print()

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("[bold red]Critical[/bold red]",    str(crit))
    g.add_row("[red]High[/red]",                  str(high))
    g.add_row("[yellow]Medium[/yellow]",          str(med))
    g.add_row("[dim yellow]Low[/dim yellow]",     str(low))
    g.add_row("[white]Total findings[/white]",    str(len(findings)))

    sev_style = "red" if (crit or high) else "yellow"
    console.print(Panel(
        g,
        title=f"[bold {sev_style}]⚠  {len(findings)} Potential Secret(s) Found — Review Before Pushing![/bold {sev_style}]",
        title_align="left",
        style=sev_style,
        expand=False,
    ))
    console.print()

    # Exit non-zero so CI gates (e.g. ign pr-check) actually fail when secrets
    # are detected, rather than silently passing.
    raise click.exceptions.Exit(code=1)


# =============================================================================
# ign tfsec
# =============================================================================

@click.command()
@click.argument("stack", required=False)
@click.option("--all", "scan_all", is_flag=True, help="Scan all stacks")
@click.option("--tool", type=click.Choice(["tfsec", "checkov"], case_sensitive=False), default=None,
              help="Force a specific tool (auto-detected by default)")
def tfsec(stack, scan_all, tool):
    """Run tfsec or checkov on Terraform code and display findings by severity."""
    import subprocess
    import shutil
    import json as _json

    if not stack and not scan_all:
        stack, scan_all = select_stack_or_all("Scan a single stack or all?", all_label='All stacks', default_all=False)

    # Auto-detect available tool
    if not tool:
        if shutil.which("tfsec"):
            tool = "tfsec"
        elif shutil.which("checkov"):
            tool = "checkov"
        else:
            console.print(Panel(
                "[bold red]✗  Neither tfsec nor checkov found on PATH.[/bold red]\n\n"
                "[white]Install one of:[/white]\n"
                "  [bold]choco install tfsec[/bold]  (Windows)\n"
                "  [bold]pip install checkov[/bold]",
                title="[bold red]Missing Security Scanner[/bold red]",
                title_align="left",
                style="red",
                expand=False,
            ))
            return

    stacks_dir = Path("stacks")
    targets = (
        _iter_all_stacks()
        if scan_all
        else [_resolve_stack_dir(stack) or (stacks_dir / stack)]
    )

    scope = "All Stacks" if scan_all else stack
    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope}[/cyan]   "
        f"[bold white]Tool:[/bold white]  [cyan]{tool}[/cyan]",
        title="[bold cyan]🔒  Terraform Security Scan[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    all_findings = []

    scanned = 0
    for tgt in targets:
        tf_dir = tgt / "terraform"
        if not tf_dir.exists():
            console.print(f"[yellow]⚠  Skipping {tgt.name}: no terraform/ directory[/yellow]")
            continue
        scanned += 1

        if tool == "tfsec":
            cmd = ["tfsec", str(tf_dir), "--format", "json", "--no-colour"]
        else:
            cmd = ["checkov", "-d", str(tf_dir), "-o", "json", "--quiet"]

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            raw  = proc.stdout or proc.stderr
        except FileNotFoundError:
            console.print(f"[red]✗  {tool} not found on PATH.[/red]")
            return
        except subprocess.TimeoutExpired:
            console.print(f"[yellow]⚠  {tool} timed out on {tgt.name}[/yellow]")
            continue

        try:
            data = _json.loads(raw)
        except _json.JSONDecodeError:
            console.print(f"[yellow]⚠  Could not parse {tool} output for {tgt.name}[/yellow]")
            continue

        # Normalise findings to (severity, rule_id, description, file, start_line)
        if tool == "tfsec":
            for r in data.get("results", []):
                sev  = r.get("severity", "UNKNOWN").upper()
                rid  = r.get("rule_id", "")
                desc = r.get("description", "")
                loc  = r.get("location", {})
                fname = loc.get("filename", "")
                line  = loc.get("start_line", 0)
                all_findings.append((sev, rid, desc, fname, line))
        else:
            for check in data.get("results", {}).get("failed_checks", []):
                sev   = check.get("severity", "MEDIUM").upper()
                rid   = check.get("check_id", "")
                desc  = check.get("check_type", "")
                fname = check.get("repo_file_path", "")
                line  = check.get("file_line_range", [0])[0]
                all_findings.append((sev, rid, desc, fname, line))

    if scanned == 0:
        console.print(Panel(
            f"[bold yellow]⚠  No stacks scanned — '{scope}' not found or has no terraform/ directory.[/bold yellow]",
            style="yellow",
            expand=False,
        ))
        console.print()
        return

    if not all_findings:
        console.print(Panel(
            "[bold green]✅  No security issues found![/bold green]",
            style="green",
            expand=False,
        ))
        console.print()
        return

    _SEV_ORDER   = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    _SEV_COLOURS = {"CRITICAL": "bold red", "HIGH": "red", "MEDIUM": "yellow", "LOW": "dim yellow", "UNKNOWN": "dim"}
    all_findings.sort(key=lambda x: _SEV_ORDER.get(x[0], 9))

    counts: Dict[str, int] = {}
    console.print()
    for sev, rid, desc, fname, line in all_findings:
        counts[sev] = counts.get(sev, 0) + 1
        colour = _SEV_COLOURS.get(sev, "white")
        badge  = f"[{colour}] {sev:<8} [/{colour}]"
        console.print(f"  {badge}  [bold white]{rid}[/bold white]  [dim]{desc}[/dim]")
        console.print(f"            [cyan]{fname}[/cyan][dim]:{line}[/dim]")
        console.print()

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
        n = counts.get(sev, 0)
        if n:
            colour = _SEV_COLOURS.get(sev, "white")
            g.add_row(f"[{colour}]{sev}[/{colour}]", str(n))
    g.add_row("[white]Total[/white]", str(len(all_findings)))

    sev_style = "red" if counts.get("CRITICAL") or counts.get("HIGH") else "yellow"
    console.print(Panel(
        g,
        title=f"[bold {sev_style}]🔒  {len(all_findings)} Security Finding(s)[/bold {sev_style}]",
        title_align="left",
        style=sev_style,
        expand=False,
    ))
    console.print()


# =============================================================================
# ign policy
# =============================================================================

# House rules: (rule_id, description, check_fn)
# check_fn(content: str, path: Path) -> list[str]  (list of violation messages)

def _policy_required_tags(content: str, path: Path) -> List[str]:
    """Every resource block must have a tags argument."""
    issues = []
    in_resource = False
    brace_depth = 0
    resource_name = ""
    has_tags = False

    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("resource ") and "{" in stripped:
            in_resource = True
            brace_depth = stripped.count("{") - stripped.count("}")
            resource_name = stripped.split('"')[1] if '"' in stripped else stripped
            has_tags = False
            continue
        if in_resource:
            brace_depth += stripped.count("{") - stripped.count("}")
            if re.match(r'tags\s*=', stripped) or re.match(r'tags\s*\{', stripped):
                has_tags = True
            if brace_depth <= 0:
                if not has_tags:
                    issues.append(f"Resource '{resource_name}' is missing a 'tags' argument")
                in_resource = False
    return issues


def _policy_no_public_ip(content: str, path: Path) -> List[str]:
    """No resource should expose a public IP via allocation_method = 'Static'/'Dynamic' on a public IP resource."""
    issues = []
    in_public_ip = False
    brace_depth  = 0
    for i, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        if re.search(r'resource\s+"azurerm_public_ip"', stripped):
            in_public_ip = True
            brace_depth  = stripped.count("{") - stripped.count("}")
            continue
        if in_public_ip:
            brace_depth += stripped.count("{") - stripped.count("}")
            if re.match(r'allocation_method\s*=\s*"(Static|Dynamic)"', stripped):
                issues.append(f"Line {i}: Public IP resource with allocation_method — review if intentional")
            if brace_depth <= 0:
                in_public_ip = False
    return issues


def _policy_storage_soft_delete(content: str, path: Path) -> List[str]:
    """Storage accounts should have blob_properties soft_delete enabled."""
    issues = []
    if "azurerm_storage_account" not in content:
        return issues
    if "blob_properties" not in content:
        issues.append("azurerm_storage_account missing blob_properties (soft-delete not configured)")
        return issues
    # Check delete_retention_policy is present
    if "delete_retention_policy" not in content:
        issues.append("azurerm_storage_account blob_properties missing delete_retention_policy")
    return issues


def _policy_naming_convention(content: str, path: Path) -> List[str]:
    """Resource names should use variables/locals, not hardcoded strings."""
    issues = []
    for i, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        m = re.match(r'name\s*=\s*"([^${}][^"]*)"', stripped)
        if m and not stripped.startswith("#"):
            val = m.group(1)
            # Allow short placeholder-style names but flag obvious hardcoded env names
            if re.search(r'(dev|tst|uat|prd|prod|staging)', val, re.I) and len(val) > 5:
                issues.append(f"Line {i}: Hardcoded environment name in resource name '{val}' — use var/local")
    return issues


_POLICY_RULES = [
    ("POL-001", "Required tags on all resources",              _policy_required_tags),
    ("POL-002", "No unrestricted public IP resources",         _policy_no_public_ip),
    ("POL-003", "Storage account soft-delete configured",      _policy_storage_soft_delete),
    ("POL-004", "No hardcoded environment names in resource names", _policy_naming_convention),
]


@click.command()
@click.argument("stack", required=False)
@click.option("--all", "check_all", is_flag=True, help="Check all stacks")
def policy(stack, check_all):
    """Check Terraform files against house policy rules (tags, naming, security)."""
    if not stack and not check_all:
        stack, check_all = select_stack_or_all("Check a single stack or all?", all_label='All stacks', default_all=False)

    stacks_dir = Path("stacks")
    targets = (
        _iter_all_stacks()
        if check_all
        else [_resolve_stack_dir(stack) or (stacks_dir / stack)]
    )

    scope = "All Stacks" if check_all else stack
    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope}[/cyan]   "
        f"[bold white]Rules:[/bold white] [cyan]{len(_POLICY_RULES)}[/cyan]",
        title="[bold cyan]📐  Policy Check[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    total_violations = 0
    all_clean = True
    checked = 0

    for tgt in targets:
        tf_dir = tgt / "terraform"
        if not tf_dir.exists():
            console.print(f"[yellow]⚠  Skipping {tgt.name}: no terraform/ directory[/yellow]")
            continue

        tf_files = list(tf_dir.glob("*.tf"))
        if not tf_files:
            console.print(f"[yellow]⚠  Skipping {tgt.name}: no .tf files[/yellow]")
            continue
        checked += 1

        stack_violations = []

        for tf_file in sorted(tf_files):
            try:
                content = tf_file.read_text(encoding="utf-8")
            except Exception:
                continue
            for rule_id, rule_desc, check_fn in _POLICY_RULES:
                try:
                    msgs = check_fn(content, tf_file)
                except Exception:
                    msgs = []
                for msg in msgs:
                    stack_violations.append((rule_id, tf_file.name, msg))

        if stack_violations:
            all_clean = False
            total_violations += len(stack_violations)
            console.print(Rule(f"[bold yellow]{tgt.name}[/bold yellow]", style="yellow"))
            for rule_id, fname, msg in stack_violations:
                console.print(f"  [yellow]{rule_id}[/yellow]  [dim]{fname}[/dim]")
                console.print(f"          {msg}")
            console.print()
        else:
            console.print(f"  [green]✔[/green]  [bold]{tgt.name}[/bold] — all rules passed")

    console.print()

    if checked == 0:
        console.print(Panel(
            f"[bold yellow]⚠  No stacks checked — '{scope}' not found or has no terraform files.[/bold yellow]",
            style="yellow",
            expand=False,
        ))
        console.print()
        return

    if all_clean:
        console.print(Panel(
            "[bold green]✅  All stacks comply with policy rules![/bold green]",
            style="green",
            expand=False,
        ))
    else:
        console.print(Panel(
            f"[bold yellow]⚠  {total_violations} violation(s) found across stacks.[/bold yellow]\n"
            "[dim]Fix the issues above before merging.[/dim]",
            title="[bold yellow]Policy Violations[/bold yellow]",
            title_align="left",
            style="yellow",
            expand=False,
        ))

    console.print()
