"""release – part of the ign CLI (split from ignition.py)."""

import click
import json
from rich.panel import Panel
from rich.rule import Rule
from pathlib import Path
from typing import List
from ign_cli.console import console
from ign_cli.core.parsing import _extract_latest_tag, _parse_version_tuple
from ign_cli.version import __version__


# =============================================================================
# ign changelog
# =============================================================================

@click.command()
@click.option("--from-tag", "from_tag", default=None, help="Start tag (exclusive). Defaults to previous release.")
@click.option("--to-tag",   "to_tag",   default=None, help="End tag (inclusive). Defaults to latest release.")
@click.option("--out", "-o", default=None, help="Write output to a file instead of stdout.")
def changelog(from_tag, to_tag, out):
    """Generate a CHANGELOG from GitHub release notes between two tags."""
    import urllib.request
    import urllib.error
    import json as _json
    import os

    token = os.environ.get("GITHUB_TOKEN", "")
    headers = {
        "User-Agent": "ign-cli/1.0",
        "Accept":     "application/vnd.github+json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    console.print(Panel(
        f"[bold white]Repo:[/bold white] [cyan]github.com/{_UPDATE_REPO}[/cyan]",
        title="[bold cyan]📝  Changelog Generator[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()
    console.print("[dim]Fetching releases...[/dim]")

    try:
        req = urllib.request.Request(
            f"https://api.github.com/repos/{_UPDATE_REPO}/releases?per_page=50",
            headers=headers,
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            releases = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 401:
            console.print("[red]✗  GitHub 401 — set GITHUB_TOKEN for private repos.[/red]")
        else:
            console.print(f"[red]✗  GitHub API error (HTTP {e.code}).[/red]")
        return
    except Exception as exc:
        console.print(f"[yellow]⚠  Could not reach GitHub: {exc}[/yellow]")
        return

    if not releases:
        console.print("[yellow]⚠  No releases found.[/yellow]")
        return

    # Filter by tag range
    tags = [r["tag_name"] for r in releases]

    if to_tag and to_tag not in tags:
        console.print(f"[red]✗  Tag '{to_tag}' not found. Available: {', '.join(tags[:10])}[/red]")
        return
    if from_tag and from_tag not in tags:
        console.print(f"[red]✗  Tag '{from_tag}' not found. Available: {', '.join(tags[:10])}[/red]")
        return

    to_idx = tags.index(to_tag) if to_tag else 0

    # --from-tag is exclusive (it's the baseline), so slice up to but not
    # including it. When omitted, include everything down to the oldest release.
    if from_tag:
        from_idx = tags.index(from_tag)
        selected = releases[to_idx:from_idx]
    else:
        selected = releases[to_idx:]

    if not selected:
        console.print("[yellow]⚠  No releases in the specified range.[/yellow]")
        return

    # Build markdown
    lines = ["# Changelog\n"]
    for rel in selected:
        tag       = rel["tag_name"]
        published = rel.get("published_at", "")[:10]
        name      = rel.get("name") or tag
        body      = (rel.get("body") or "").strip()
        url       = rel.get("html_url", "")

        lines.append(f"## [{name}]({url}) — {published}\n")
        if body:
            lines.append(body)
        else:
            lines.append("_No release notes provided._")
        lines.append("")

    md_output = "\n".join(lines)

    if out:
        Path(out).write_text(md_output, encoding="utf-8")
        console.print(Panel(
            f"[bold green]✅  Changelog written to [bold]{out}[/bold] ({len(selected)} release(s))[/bold green]",
            style="green",
            expand=False,
        ))
    else:
        console.print(Rule("[bold cyan]CHANGELOG[/bold cyan]", style="cyan"))
        console.print()
        from rich.markdown import Markdown
        console.print(Markdown(md_output))

    console.print()


# =============================================================================
# ign update
# =============================================================================

_UPDATE_REPO = "telefonicatechuki/devops-cli"


@click.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.option("--check", is_flag=True, help="Only check for updates, don't install")
@click.option("--pre-release", is_flag=True, help="Include pre-releases")
def update(yes: bool, check: bool, pre_release: bool):
    """Check GitHub for a newer ign release and install it."""
    import os
    import shutil
    import subprocess
    import sys
    import tempfile

    if shutil.which("gh") is None:
        console.print(Panel(
            "[bold red]✗  GitHub CLI ('gh') not found on PATH.[/bold red]\n"
            "[dim]Install it, then run 'gh auth login':\n"
            "  Windows: winget install GitHub.cli\n"
            "  macOS:   brew install gh\n"
            "  Linux:   sudo apt install gh[/dim]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)

    current_version = __version__

    try:
        args = ["gh", "release", "list", "--repo", _UPDATE_REPO, "--json", "tagName"]
        if not pre_release:
            args.append("--exclude-pre-releases")
        r = subprocess.run(
            args + ["--limit", "1", "-q", ".[0].tagName"],
            capture_output=True, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        console.print(Panel(
            "[bold red]✗  Timed out contacting GitHub.[/bold red]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)
    except Exception as e:
        console.print(Panel(f"[bold red]✗  {e}[/bold red]", style="red", expand=False))
        raise click.exceptions.Exit(code=1)

    if r.returncode != 0:
        console.print(Panel(
            f"[bold red]✗  Could not check for updates.[/bold red]\n"
            f"[dim]{r.stderr.strip() or r.stdout.strip()}[/dim]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)

    latest_tag = _extract_latest_tag(r.stdout)
    if not latest_tag:
        console.print(Panel(
            "[bold red]✗  No matching releases were found.[/bold red]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)
    latest_version = latest_tag.lstrip("v")

    if _parse_version_tuple(latest_version) <= _parse_version_tuple(current_version):
        console.print(Panel(
            f"[bold green]✅  You're up to date.[/bold green]  [dim](v{current_version})[/dim]",
            style="green", expand=False,
        ))
        return

    console.print(Panel(
        f"[bold white]Current:[/bold white] [yellow]v{current_version}[/yellow]\n"
        f"[bold white]Latest:[/bold white]  [green]{latest_tag}[/green]",
        title="[bold cyan]⬆  Update Available[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))

    if check:
        return

    if not yes and not click.confirm("Download and install this update?"):
        console.print("[dim]Skipped.[/dim]")
        return

    def _start_windows_delayed_install(install_cmd: List[str], wheel: Path) -> None:
        import shutil as _shutil
        import subprocess as _subprocess
        import textwrap

        staging_dir = Path(tempfile.mkdtemp(prefix="ign-update-"))
        staged_wheel = staging_dir / wheel.name
        _shutil.copy2(wheel, staged_wheel)
        staged_install_cmd = [
            str(staged_wheel) if arg == str(wheel) else arg
            for arg in install_cmd
        ]

        helper_script = textwrap.dedent(f"""
            import ctypes
            import pathlib
            import shutil
            import subprocess
            import sys
            import time

            pid = {os.getpid()}
            cmd = {json.dumps(staged_install_cmd)}
            staging_dir = pathlib.Path(r"{staging_dir}")

            kernel32 = ctypes.windll.kernel32
            process_query_limited_information = 0x1000

            while True:
                handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
                if not handle:
                    break
                kernel32.CloseHandle(handle)
                time.sleep(0.25)

            result = subprocess.run(cmd)
            shutil.rmtree(staging_dir, ignore_errors=True)
            sys.exit(result.returncode)
        """)

        creationflags = 0
        if hasattr(_subprocess, "DETACHED_PROCESS"):
            creationflags |= _subprocess.DETACHED_PROCESS
        if hasattr(_subprocess, "CREATE_NEW_PROCESS_GROUP"):
            creationflags |= _subprocess.CREATE_NEW_PROCESS_GROUP

        _subprocess.Popen(
            [sys.executable, "-c", helper_script],
            creationflags=creationflags,
            stdin=_subprocess.DEVNULL,
            stdout=_subprocess.DEVNULL,
            stderr=_subprocess.DEVNULL,
        )

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        console.print(f"[dim]Downloading {latest_tag}...[/dim]")
        try:
            r = subprocess.run(
                ["gh", "release", "download", latest_tag, "--repo", _UPDATE_REPO,
                 "--pattern", "*.whl", "--dir", str(tmp_path), "--clobber"],
                capture_output=True, text=True, timeout=60,
            )
        except Exception as e:
            console.print(Panel(f"[bold red]✗  Download failed: {e}[/bold red]", style="red", expand=False))
            raise click.exceptions.Exit(code=1)

        if r.returncode != 0:
            console.print(Panel(
                f"[bold red]✗  Download failed.[/bold red]\n[dim]{r.stderr.strip()}[/dim]",
                style="red", expand=False,
            ))
            raise click.exceptions.Exit(code=1)

        wheels = list(tmp_path.glob("*.whl"))
        if not wheels:
            console.print(Panel(
                "[bold red]✗  No .whl file found in the release assets.[/bold red]",
                style="red", expand=False,
            ))
            raise click.exceptions.Exit(code=1)

        whl = wheels[0]

        uv_exe = shutil.which("uv")
        is_windows = sys.platform.startswith("win")
        if uv_exe:
            console.print("[dim]Installing with uv...[/dim]")
            install_cmd = ["uv", "tool", "install", str(whl), "--force"]
            if is_windows:
                _start_windows_delayed_install(install_cmd, whl)
                console.print(
                    "[dim]Windows will finish the install after this command exits.[/dim]"
                )
                console.print(Panel(
                    f"[bold green]✅  Update queued for {latest_tag}.[/bold green]\n"
                    "[dim]Open a new shell in a few seconds, then run 'ign --version'.[/dim]",
                    style="green", expand=False,
                ))
                return
            install = subprocess.run(install_cmd)
        else:
            console.print(
                "[yellow]⚠  'uv' not found — falling back to pip.[/yellow]\n"
                "[dim]Installing uv is recommended: https://astral.sh/uv[/dim]"
            )
            install_cmd = [sys.executable, "-m", "pip", "install", "--force-reinstall", str(whl)]
            if is_windows:
                _start_windows_delayed_install(install_cmd, whl)
                console.print(
                    "[dim]Windows will finish the install after this command exits.[/dim]"
                )
                console.print(Panel(
                    f"[bold green]✅  Update queued for {latest_tag}.[/bold green]\n"
                    "[dim]Open a new shell in a few seconds, then run 'ign --version'.[/dim]",
                    style="green", expand=False,
                ))
                return
            install = subprocess.run(install_cmd)

        if install.returncode != 0:
            console.print(Panel(
                "[bold red]✗  Install failed. See output above.[/bold red]",
                style="red", expand=False,
            ))
            raise click.exceptions.Exit(code=1)

    console.print(Panel(
        f"[bold green]✅  Updated to {latest_tag}.[/bold green]\n"
        "[dim]Open a new shell and run 'ign --version' to confirm.[/dim]",
        style="green", expand=False,
    ))
