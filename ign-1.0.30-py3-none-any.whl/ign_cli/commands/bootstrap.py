"""bootstrap – part of the ign CLI (split from ignition.py)."""

import click
import json
import re
from rich.panel import Panel
from rich.rule import Rule
from pathlib import Path
from typing import Dict
from ign_cli.console import cli_helper, console
from ign_cli.core.settings import DEFAULT_CICD_REF, DEFAULT_CICD_REPO, _load_project_settings
from ign_cli.generators.cicd import _github_repo_exists, _render_cicd_repo
from ign_cli.generators.devcontainer import _render_devcontainer
from ign_cli.paths import SOURCE_ROOT, _find_resource_dir


@click.command()
@click.option('--init-only', is_flag=True, default=False, help='Only run terraform init')
@click.option('--plan-only', is_flag=True, default=False, help='Only run terraform plan')
@click.option('--apply', is_flag=True, default=False, help='Run terraform apply after plan')
@click.option('--auto-approve', is_flag=True, default=False, help='Skip confirmation prompts for terraform apply')
@click.option('--ado-pat', envvar='AZDO_PERSONAL_ACCESS_TOKEN', help='Azure DevOps PAT token (prompted if not provided, not stored)')
@click.option('--gh-token', envvar='GITHUB_TOKEN', help='GitHub token for cicdPlatform: github (falls back to `gh auth token`, then a prompt; not stored)')
@click.option('--keep-state', is_flag=True, default=False, help='Keep the Terraform state file after apply (default: state file is deleted since bootstrap resources are one-time setup)')
@click.option('--cleanup-cache', is_flag=True, default=False, help='Clean up .terraform directory (provider cache) after successful apply. Safe to delete.')
def bootstrap(init_only: bool, plan_only: bool, apply: bool, auto_approve: bool, ado_pat: str, gh_token: str, keep_state: bool, cleanup_cache: bool):
    """Bootstrap infrastructure by running Terraform in the bootstrap directory.
    
    This command sets up the foundational infrastructure including:
    - Resource groups for Terraform state storage
    - Storage accounts for Terraform state
    - User Managed Identities for build and deploy operations
    - Azure DevOps service connections (requires ADO PAT token), or
    - GitHub repository guardrails, role teams, environments, environment
      variables and OIDC federated credentials (requires a GitHub token)
    
    Configuration is managed via config.yaml in the bootstrap/terraform directory.
    Tokens are prompted securely and never stored.
    """
    import subprocess
    import sys
    import os
    
    # Try to import yaml, provide helpful error if missing
    try:
        import yaml
    except ImportError:
        console.print("[bold red]❌  Error:[/bold red] [red]PyYAML is required but not installed.[/red]")
        console.print("   Please reinstall the package:")
        console.print("     [bold]uv pip install --force-reinstall .[/bold]")
        console.print("   Or install PyYAML directly:")
        console.print("     [bold]pip install PyYAML[/bold]")
        return
    
    console.print(Panel(
        "[white]Sets up foundational infrastructure: resource groups, storage accounts,\nmanaged identities, and CI/CD access (Azure DevOps service connections\nor GitHub Actions OIDC federated credentials).[/white]",
        title="[bold cyan]🚀  Bootstrapping Infrastructure[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()
    
    # Find CLI's bootstrap terraform directory (where terraform files are)
    # When installed via pip/uv, data_files go to sys.prefix or site-packages
    cli_bootstrap_dirs = [
        # 1. Development: next to ignition.py (source directory)
        SOURCE_ROOT / 'resources' / 'bootstrap' / 'terraform',
        # 2. Installed package location (data_files go here)
        Path(sys.prefix) / 'resources' / 'bootstrap' / 'terraform',
    ]
    
    # Try to get from site-packages (where data_files are installed)
    try:
        import site
        # Check site-packages directories
        for site_dir in site.getsitepackages():
            cli_bootstrap_dirs.append(Path(site_dir) / 'bootstrap' / 'terraform')
        
        # Check user site-packages
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            user_site = site.getusersitepackages() if hasattr(site, 'getusersitepackages') else None
            if user_site:
                cli_bootstrap_dirs.append(Path(user_site) / 'bootstrap' / 'terraform')
            else:
                cli_bootstrap_dirs.append(Path(site.USER_BASE) / 'bootstrap' / 'terraform')
    except Exception:
        pass
    
    # Find CLI bootstrap directory (where terraform files are)
    cli_bootstrap_dir = None
    for dir_path in cli_bootstrap_dirs:
        if dir_path.exists() and (dir_path / 'main.tf').exists():
            cli_bootstrap_dir = dir_path
            break
    
    if not cli_bootstrap_dir:
        console.print("[bold red]❌  Error:[/bold red] [red]CLI bootstrap terraform directory not found.[/red]")
        console.print("   The bootstrap terraform files are not installed with the package.")
        console.print("   Please reinstall the package:")
        console.print("     [bold]pip install --force-reinstall .[/bold]")
        console.print("   Or if using uv:")
        console.print("     [bold]uv pip install --force-reinstall .[/bold]")
        console.print("\n   [dim]Searched in:[/dim]")
        for dir_path in cli_bootstrap_dirs:
            exists_icon = "[green]✓[/green]" if dir_path.exists() else "[red]✗[/red]"
            console.print(f"     {exists_icon}  [dim]{dir_path}[/dim]")
        return
    
    # Check for config.yaml in current project directory
    project_config_file = Path.cwd() / 'bootstrap' / 'terraform' / 'config.yaml'
    cli_config_file = cli_bootstrap_dir / 'config.yaml'
    
    # Use project config.yaml if it exists, otherwise check CLI directory
    config_source = None
    if project_config_file.exists():
        config_source = project_config_file
        console.print(f"[green]📁[/green]  Found project config: [bold]{project_config_file}[/bold]")
        console.print(f"[green]📁[/green]  Using CLI terraform files: [dim]{cli_bootstrap_dir}[/dim]")
    elif cli_config_file.exists():
        config_source = cli_config_file
        console.print(f"[green]📁[/green]  Using CLI config: [bold]{cli_config_file}[/bold]")
    else:
        console.print("[bold red]❌  Error:[/bold red] [red]config.yaml not found.[/red]")
        console.print(f"   Please create config.yaml at:")
        console.print(f"     [bold]{project_config_file}[/bold] [dim](project directory)[/dim]")
        console.print(f"   Or run [bold]ign init[/bold] to generate it.")
        return
    
    # Read config.yaml to check if ADO is configured
    with open(config_source, 'r', encoding='utf-8') as f:
        config_data = yaml.safe_load(f)
    
    ado_org_url = config_data.get('adoOrgUrl')
    ado_project_id = config_data.get('adoProjectId')
    cicd_platform = str(config_data.get('cicdPlatform') or 'ado').strip().lower()
    first_time_gh = False
    gh_org = config_data.get('orgName_gh')
    github_configured = (
        cicd_platform == 'github'
        and gh_org is not None
        and str(gh_org).strip() not in ('', 'null', '<Fill Me In>')
    )
    if cicd_platform == 'github':
        # Azure DevOps resources are never created for GitHub projects
        ado_org_url = None
        if not github_configured:
            console.print("[bold red]❌  cicdPlatform is github but orgName_gh is not set in config.yaml.[/bold red]")
            return
        first_time_gh = config_data.get('isFirstTimeDeployToGH')
        if not isinstance(first_time_gh, bool):
            console.print("[bold red]❌  Set isFirstTimeDeployToGH to true or false in config.yaml.[/bold red]")
            console.print("   [dim]true  = first environment for this repository: creates the role teams and repository guardrails[/dim]")
            console.print("   [dim]false = later environments: only the GitHub environments and OIDC trust are created[/dim]")
            return
    
    # Check if ADO is configured (adoOrgUrl is set and not null/empty)
    # Service connections will be created if adoOrgUrl is set, so PAT is needed
    ado_configured = (
        ado_org_url is not None 
        and str(ado_org_url).strip() != '' 
        and str(ado_org_url).lower() != 'null'
    )
    
    # Warn if adoProjectId is missing but adoOrgUrl is set
    if ado_configured:
        if not ado_project_id or str(ado_project_id).lower() == 'null' or str(ado_project_id).strip() == '':
            console.print("[yellow]⚠️   Warning:[/yellow] [yellow]adoOrgUrl is configured but adoProjectId is not set.[/yellow]")
            console.print("   Service connections require adoProjectId. Update config.yaml with your project ID.")
            console.print("   Service connection creation will fail if adoProjectId is missing.\n")
    
    # Prompt for ADO PAT token if ADO is configured and not provided
    if ado_configured and not ado_pat:
        console.print("[bold cyan]🔐  Azure DevOps configuration detected in config.yaml[/bold cyan]")
        console.print("   ADO PAT token is required for creating service connections.")
        console.print("   [dim]The token will be used securely and never stored.[/dim]\n")
        ado_pat = click.prompt("Enter Azure DevOps PAT token", hide_input=True)
        if not ado_pat or not ado_pat.strip():
            console.print("[bold red]❌  ADO PAT token is required when adoOrgUrl is configured.[/bold red]")
            return
    
    # Resolve a GitHub token if GitHub is configured: --gh-token / GITHUB_TOKEN,
    # then the GitHub CLI's token, then a hidden prompt.
    if github_configured and not gh_token:
        try:
            gh_res = subprocess.run(['gh', 'auth', 'token'], capture_output=True, text=True, timeout=20)
            if gh_res.returncode == 0 and gh_res.stdout.strip():
                if click.confirm("Use the GitHub CLI's current token (gh auth token)?", default=True):
                    gh_token = gh_res.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    if github_configured and not gh_token:
        console.print("[bold cyan]🔐  GitHub configuration detected in config.yaml[/bold cyan]")
        console.print(f"   A token with admin rights on [bold]{gh_org}/{config_data.get('repositoryName_gh')}[/bold] is required")
        console.print("   (classic PAT scopes: repo, admin:org, workflow - or a fine-grained token with")
        console.print("   Administration, Environments, Variables and Members write access).")
        console.print("   [dim]The token will be used securely and never stored.[/dim]\n")
        gh_token = click.prompt("Enter GitHub token", hide_input=True)
        if not gh_token or not gh_token.strip():
            console.print("[bold red]❌  A GitHub token is required when cicdPlatform is github.[/bold red]")
            return

    # The infrastructure repository must already exist (and be visible to the token) unless this
    # first run creates it. GitHub answers 404 for repos the token cannot see, and the Terraform
    # provider turns that into an empty result rather than an error, so check up front.
    if github_configured and not (first_time_gh and config_data.get('ghCreateRepository') is True):
        infra_repo = str(config_data.get('repositoryName_gh') or '').strip()
        for _ in range(5):  # resolve ${key} placeholders, e.g. "${app_short}"
            infra_repo = re.sub(r'\$\{(\w+)\}', lambda m: str(config_data.get(m.group(1), m.group(0))), infra_repo)
        exists = _github_repo_exists(str(gh_org).strip(), infra_repo, gh_token.strip())
        if exists is None:
            console.print(f"[bold red]❌  Could not check whether {gh_org}/{infra_repo} exists (GitHub API unreachable or token rejected).[/bold red]")
            return
        if not exists:
            console.print(f"[bold red]❌  GitHub repository {gh_org}/{infra_repo} was not found, or the token cannot see it.[/bold red]")
            console.print("   - Check repositoryName_gh / orgName_gh in config.yaml")
            console.print("   - Fine-grained PAT: give it access to this repository (and the organisation)")
            console.print("   - Classic PAT: needs the repo scope and SSO authorisation for the organisation")
            if first_time_gh:
                console.print("   - Or set [bold]ghCreateRepository: true[/bold] to have bootstrap create it")
            return

    # Shared CI/CD repo: on a repository's first run, create it if the organisation does not have it yet.
    cicd_repo_tf_env: Dict[str, str] = {}
    cicd_render_dir = None
    if github_configured and first_time_gh and config_data.get('createCicdRepo_gh', True) is not False:
        project_settings = _load_project_settings()
        cicd_repo_name = str(config_data.get('cicdRepoName_gh') or project_settings.get('cicd_repo') or DEFAULT_CICD_REPO).strip()
        cicd_ref = str(project_settings.get('cicd_ref') or DEFAULT_CICD_REF).strip()
        exists = _github_repo_exists(str(gh_org).strip(), cicd_repo_name, gh_token.strip())
        if exists is None:
            console.print(f"[bold red]❌  Could not check whether {gh_org}/{cicd_repo_name} exists (GitHub API unreachable or token rejected).[/bold red]")
            console.print("   Fix the token / network, or set [bold]createCicdRepo_gh: false[/bold] in config.yaml.")
            return
        if exists:
            console.print(f"[green]📦[/green]  Shared CI/CD repo [bold]{gh_org}/{cicd_repo_name}[/bold] already exists [dim](left unchanged)[/dim]\n")
            cicd_repo_tf_env['TF_VAR_cicd_repo_exists'] = 'true'
        else:
            source = _find_resource_dir('resources/templates/pipelines/github/cicd-repo')
            if source is None:
                console.print("[bold red]❌  CI/CD repo templates not found in the installed package.[/bold red]")
                return
            import tempfile
            cicd_render_dir = Path(tempfile.mkdtemp(prefix='ign-cicd-repo-'))
            count = _render_cicd_repo(source, cicd_render_dir, str(gh_org).strip(), cicd_repo_name, cicd_ref)
            console.print(f"[green]📦[/green]  Shared CI/CD repo [bold]{gh_org}/{cicd_repo_name}[/bold] will be created "
                          f"with {count} files [dim](internal refs @{cicd_ref})[/dim]\n")
            cicd_repo_tf_env['TF_VAR_cicd_repo_exists'] = 'false'
            cicd_repo_tf_env['TF_VAR_cicd_repo_files_dir'] = cicd_render_dir.as_posix()

    # New infrastructure repository: commit the dev container so it is there on first clone.
    app_render_dir = None
    if github_configured and first_time_gh and config_data.get('ghCreateRepository') is True:
        import tempfile
        app_render_dir = Path(tempfile.mkdtemp(prefix='ign-app-repo-'))
        if _render_devcontainer(app_render_dir):
            import sys
            cicd_repo_tf_env['TF_VAR_app_repo_files_dir'] = app_render_dir.as_posix()
            # The ign wheel is binary: Terraform uploads it via the Contents API using this interpreter.
            cicd_repo_tf_env['TF_VAR_python_executable'] = Path(sys.executable).as_posix()
            console.print("[green]📦[/green]  Dev container (including the ign wheel) will be committed to the new repository\n")
        else:
            console.print("[yellow]⚠️  Dev container templates not found in the installed package - repository will be created without one[/yellow]\n")

    # Copy project config.yaml to CLI bootstrap directory temporarily
    config_backup = None
    if config_source == project_config_file:
        # Backup existing CLI config if it exists
        if cli_config_file.exists():
            config_backup = cli_bootstrap_dir / 'config.yaml.backup'
            if config_backup.exists():
                config_backup.unlink()
            cli_config_file.rename(config_backup)
        
        # Copy project config to CLI directory
        import shutil
        shutil.copy2(project_config_file, cli_config_file)
        console.print(f"[green]📋[/green]  Copied project config to CLI bootstrap directory\n")
    
    # Set up environment variables for terraform
    terraform_env = os.environ.copy()
    # Set AZDO_ORG_SERVICE_URL if adoOrgUrl is configured (needed for provider initialization)
    # This is independent of whether PAT is provided or adoProjectId is set
    if ado_configured or (ado_org_url and str(ado_org_url).strip() and str(ado_org_url).lower() != 'null'):
        terraform_env['AZDO_ORG_SERVICE_URL'] = str(ado_org_url).strip()
        if ado_pat:
            terraform_env['AZDO_PERSONAL_ACCESS_TOKEN'] = ado_pat
            console.print("[green]🔐[/green]  ADO PAT token set in environment [dim](will not be stored)[/dim]\n")
        else:
            console.print("[yellow]⚠️   ADO org URL set, but PAT token not provided.[/yellow]\n")
    
    if github_configured:
        terraform_env['GITHUB_TOKEN'] = gh_token.strip()
        terraform_env['GITHUB_OWNER'] = str(gh_org).strip()
        terraform_env.update(cicd_repo_tf_env)
        console.print("[green]🔐[/green]  GitHub token set in environment [dim](will not be stored)[/dim]\n")

    # Azure DevOps resources live in ado.tf. The azuredevops provider contacts the ADO
    # organisation as soon as it is configured (even when every ADO resource has count = 0),
    # so GitHub runs set the file aside and restore it afterwards.
    ado_tf = cli_bootstrap_dir / 'ado.tf'
    ado_tf_disabled = cli_bootstrap_dir / 'ado.tf.disabled'
    if ado_tf_disabled.exists():
        # Left over from an interrupted GitHub run - put it back first.
        if ado_tf.exists():
            ado_tf_disabled.unlink()
        else:
            ado_tf_disabled.rename(ado_tf)
    ado_tf_set_aside = False

    # Change to CLI bootstrap directory to run terraform
    original_dir = Path.cwd()
    try:
        if cicd_platform == 'github' and ado_tf.exists():
            ado_tf.rename(ado_tf_disabled)
            ado_tf_set_aside = True
            console.print("[dim]⏭️   Azure DevOps resources (ado.tf) excluded: cicdPlatform is github[/dim]")
        os.chdir(cli_bootstrap_dir)
        console.print(f"[dim]📂  Running terraform from: {cli_bootstrap_dir}[/dim]\n")
        
        # Run terraform init (always needed before plan/apply, unless init-only)
        if not init_only:
            console.print(Rule("[bold]🔧  Running terraform init...[/bold]", style="blue"))
            result = subprocess.run(['terraform', 'init'], capture_output=False, env=terraform_env)
            if result.returncode != 0:
                console.print("[bold red]❌  Terraform init failed[/bold red]")
                return
        
        if init_only:
            console.print(Panel("[bold green]✅  Bootstrap initialization complete![/bold green]", style="green", expand=False))
            return
        
        # Run terraform plan
        if not apply:
            console.print(Rule("[bold]📋  Running terraform plan...[/bold]", style="blue"))
            result = subprocess.run(['terraform', 'plan'], capture_output=False, env=terraform_env)
            if result.returncode != 0:
                console.print("[bold red]❌  Terraform plan failed[/bold red]")
                return
            
            if plan_only:
                console.print(Panel("[bold green]✅  Terraform plan complete![/bold green]", style="green", expand=False))
                return
        
        # Run terraform apply
        if apply:
            if not auto_approve:
                if not click.confirm("\n⚠️  Do you want to apply these changes?"):
                    console.print("[yellow]Aborted.[/yellow]")
                    return
            
            console.print(Rule("[bold]🚀  Running terraform apply...[/bold]", style="blue"))
            apply_args = ['terraform', 'apply']
            if auto_approve:
                apply_args.append('-auto-approve')
            if cicd_render_dir is not None or 'TF_VAR_app_repo_files_dir' in cicd_repo_tf_env:
                # Files are committed to one branch one at a time - parallel commits conflict.
                apply_args.append('-parallelism=1')
            
            result = subprocess.run(apply_args, capture_output=False, env=terraform_env)
            if result.returncode != 0:
                console.print("[bold red]❌  Terraform apply failed[/bold red]")
                return
            
            console.print(Panel("[bold green]✅  Bootstrap deployment complete![/bold green]", style="green", expand=False))
            
            # Generate environment-specific output documentation before local state cleanup
            try:
                output_res = subprocess.run(
                    ['terraform', 'output', '-json'],
                    capture_output=True,
                    text=True,
                    env=terraform_env,
                    cwd=cli_bootstrap_dir
                )
                if output_res.returncode == 0 and output_res.stdout.strip():
                    raw_outputs = json.loads(output_res.stdout)
                    
                    from datetime import datetime
                    output_params = {
                        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }

                    # Dynamically map all terraform outputs into output_params dictionary
                    for key, output_obj in raw_outputs.items():
                        val = output_obj.get("value") if isinstance(output_obj, dict) else output_obj
                        if isinstance(val, dict):
                            # Handle nested dictionary outputs
                            for sub_k, sub_v in val.items():
                                output_params[f"{key}_{sub_k}"] = str(sub_v) if sub_v is not None else ""
                        elif isinstance(val, list):
                            output_params[key] = ", ".join(f"`{item}`" for item in val)
                        else:
                            output_params[key] = str(val) if val is not None else ""

                    env_name = output_params.get("environment", "unknown")
                    outputs_template = (
                        'resources/bootstrap/BOOTSTRAP-OUTPUTS-github.md.template'
                        if output_params.get("cicd_platform") == "github"
                        else 'resources/bootstrap/BOOTSTRAP-OUTPUTS.md.template'
                    )

                    try:
                        template_content = cli_helper.load_template(outputs_template, **output_params)
                        
                        output_dir = original_dir / 'bootstrap'
                        output_dir.mkdir(parents=True, exist_ok=True)
                        output_file = output_dir / f'BOOTSTRAP-OUTPUTS-{env_name}.md'
                        
                        cli_helper.write_file(output_file, template_content)
                        console.print(f"[bold green]📝  Generated environment summary: [cyan]{output_file}[/cyan][/bold green]")
                    except Exception as te:
                        console.print(f"[yellow]⚠️  Could not generate BOOTSTRAP-OUTPUTS markdown summary: {te}[/yellow]")
            except Exception as oe:
                console.print(f"[yellow]⚠️  Could not capture terraform outputs: {oe}[/yellow]")

            # Cleanup after successful apply
            import shutil
            terraform_dir = Path(cli_bootstrap_dir) / '.terraform'
            state_file = Path(cli_bootstrap_dir) / 'terraform.tfstate'
            state_backup = Path(cli_bootstrap_dir) / 'terraform.tfstate.backup'
            
            # Clean up state file by default (bootstrap resources are one-time setup and don't need tracking)
            if not keep_state:
                if state_file.exists():
                    state_file.unlink()
                    console.print("[cyan]🧹  Removed local state file (terraform.tfstate)[/cyan]")
                if state_backup.exists():
                    state_backup.unlink()
                    console.print("[cyan]🧹  Removed state backup file (terraform.tfstate.backup)[/cyan]")
            
            # Clean up provider cache if requested
            if cleanup_cache and terraform_dir.exists():
                shutil.rmtree(terraform_dir)
                console.print("[cyan]🧹  Cleaned up .terraform directory (provider cache)[/cyan]")
        else:
            console.print("\n[dim]💡  Tip: Use [bold]--apply[/bold] flag to apply the changes[/dim]")
            console.print("   [dim]Example: [bold]ign bootstrap --apply[/bold][/dim]")
    
    finally:
        # Clear PAT token from environment
        if 'AZDO_PERSONAL_ACCESS_TOKEN' in terraform_env:
            terraform_env.pop('AZDO_PERSONAL_ACCESS_TOKEN', None)
            console.print("\n[dim]🔒  ADO PAT token cleared from environment[/dim]")
        if cicd_render_dir is not None:
            import shutil
            shutil.rmtree(cicd_render_dir, ignore_errors=True)
        if app_render_dir is not None:
            import shutil
            shutil.rmtree(app_render_dir, ignore_errors=True)
        if 'GITHUB_TOKEN' in terraform_env:
            terraform_env.pop('GITHUB_TOKEN', None)
            console.print("[dim]🔒  GitHub token cleared from environment[/dim]")
        
        # Restore CLI config.yaml backup if we copied project config
        if config_source == project_config_file and config_backup:
            if cli_config_file.exists():
                cli_config_file.unlink()
            if config_backup.exists():
                config_backup.rename(cli_config_file)

        # Put the Azure DevOps resources back for the next (possibly ADO) run
        if ado_tf_set_aside and ado_tf_disabled.exists() and not ado_tf.exists():
            ado_tf_disabled.rename(ado_tf)

        # Always return to original directory
        os.chdir(original_dir)
