"""stacks – part of the ign CLI (split from ignition.py)."""

import click
import re
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.rule import Rule
from pathlib import Path
from ign_cli.console import cli_helper, console
from ign_cli.core.settings import CICD_LABELS, _detect_cicd_platform, _detect_cloud_provider
from ign_cli.core.stacks import _discover_env_tfvars, STACK_DIRS, _CAF_REGION_ABBRS, _ENV_ORDER, _iter_all_stacks, _resolve_stack_dir
from ign_cli.generators.bootstrap_config import create_bootstrap_config
from ign_cli.generators.cicd import create_pipeline_templates, generate_azure_pipelines, generate_github_workflow
from ign_cli.generators.devcontainer import create_devcontainer
from ign_cli.generators.scaffold import copy_script_templates, create_scaffold_templates, create_utils_module
from ign_cli.generators.stack_templates import copy_stack_template, create_landing_zones_environments_file, discover_stack_templates, generate_configuration_guide
from ign_cli.generators.terraform import generate_aws_terraform_files, generate_terraform_files, generate_yaml_files
from ign_cli.paths import SOURCE_ROOT
from ign_cli.core.prompts import select, select_stack


@click.command()
@click.option('--stack-name', prompt='Stack name', help='Name of the stack (e.g., dlz, dmz)')
@click.option('--description', prompt='Stack description', help='Brief description of the stack')
@click.option('--service-connection', default=None, help='DevOps service connection name (Azure DevOps projects only; prompted if omitted)')
@click.option('--include-databricks', is_flag=True, default=False, help='Include Databricks workspace resources (Azure only)')
@click.option('--include-storage', is_flag=True, default=False, help='Include storage account resources (Azure only)')
@click.option('--include-keyvault', is_flag=True, default=False, help='Include Key Vault resources (Azure only)')
def add_stack(stack_name: str, description: str, service_connection: str,
              include_databricks: bool, include_storage: bool, include_keyvault: bool):
    """Add a new deployment stack to the project."""

    cloud = _detect_cloud_provider()
    cicd = _detect_cicd_platform()
    if cicd == 'ado' and not service_connection:
        service_connection = click.prompt('Service connection', default='DataPlatform - Dev')

    cloud_label = (
        "[bold #FF9900]⬡  AWS[/bold #FF9900]"
        if cloud == 'aws'
        else "[bold #0078D4]◆  Azure[/bold #0078D4]"
    )
    console.print(Panel(
        f"[bold white]Cloud:[/bold white] {cloud_label}\n"
        f"[bold white]CI/CD:[/bold white] {CICD_LABELS[cicd]}\n"
        f"[bold white]Stack:[/bold white] [cyan]{stack_name}[/cyan]",
        title="[bold cyan]📦  Creating New Stack[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()

    # Validate stacks directory exists
    stacks_dir = Path('stacks')
    if not stacks_dir.exists():
        console.print("[bold red]❌  Error:[/bold red] [red]'stacks' directory not found. Did you run 'init' first?[/red]")
        return

    stack_dir = stacks_dir / stack_name
    if stack_dir.exists():
        if not click.confirm(f"Stack '{stack_name}' already exists. Overwrite?"):
            console.print("[yellow]Aborted.[/yellow]")
            return

    # Create stack structure
    terraform_dir = stack_dir / 'terraform'
    yaml_dir = stack_dir / 'yaml'

    cli_helper.create_directory(terraform_dir)

    if cloud == 'aws':
        generate_aws_terraform_files(terraform_dir, stack_name, description)
    else:
        generate_terraform_files(terraform_dir, stack_name, description,
                                 include_databricks, include_storage, include_keyvault)

    if cicd == 'github':
        # One caller workflow per stack, calling the shared reusable pipeline
        generate_github_workflow(stack_name)
    else:
        cli_helper.create_directory(yaml_dir)
        generate_yaml_files(yaml_dir, stack_dir, stack_name, service_connection, cloud=cloud)
        # Generate Azure Pipelines file (same structure for both clouds)
        generate_azure_pipelines(stack_dir, stack_name, service_connection)

    # Generate configuration guide
    generate_configuration_guide(stack_dir, terraform_dir, yaml_dir)

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Customize Terraform configuration in [bold]stacks/{stack_name}/terraform/[/bold]")
    grid.add_row("2.", "Update variable values in [bold]terraform/tfvars/*.tfvars[/bold] files")
    if cicd == 'github':
        grid.add_row("3.", f"Review the workflow in [bold].github/workflows/{stack_name}.yml[/bold] and [bold]stacks/{stack_name}/CONFIGURATION.md[/bold]")
    else:
        grid.add_row("3.", "Review pipeline configuration in [bold]azure-pipelines.yml[/bold]")
    grid.add_row("4.", "Commit changes and push to trigger CI/CD")
    console.print(Panel(grid, title=f"[bold green]✅  Stack '{stack_name}' Created Successfully![/bold green]", title_align="left", style="green", expand=False))
    console.print()


@click.command()
def list_stacks():
    """List all stacks in the project."""
    
    stack_paths = _iter_all_stacks()
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No 'stacks' directory found.[/bold red] Initialize a project first with [bold]ign init[/bold].")
        return

    if not stack_paths:
        console.print("[yellow]No stacks found in the project.[/yellow]")
        return

    table = Table(
        title="[bold cyan]📋  Project Stacks[/bold cyan]",
        box=box.ROUNDED,
        header_style="bold cyan",
        border_style="cyan",
        show_lines=False,
    )
    table.add_column("Status", style="bold", no_wrap=True, width=8)
    table.add_column("Stack Name", style="bold white")
    table.add_column("Location", style="dim", no_wrap=True)
    table.add_column("Terraform", justify="center", width=12)
    table.add_column("YAML", justify="center", width=8)

    for stack_path in stack_paths:
        terraform_exists = (stack_path / 'terraform').exists()
        yaml_exists = (stack_path / 'yaml').exists()
        is_complete = terraform_exists and yaml_exists
        status = "[green]●  Ready[/green]" if is_complete else "[yellow]●  Partial[/yellow]"
        tf_icon = "[green]✓[/green]" if terraform_exists else "[red]✗[/red]"
        yaml_icon = "[green]✓[/green]" if yaml_exists else "[red]✗[/red]"
        table.add_row(status, stack_path.name, f"{stack_path.parent.name}/", tf_icon, yaml_icon)

    console.print()
    console.print(table)
    console.print()


@click.command()
@click.option('--debug', is_flag=True, help='Show debug information about stack template search paths')
def list_stack_templates(debug: bool):
    """List all available stack templates.
    
    Stack templates are pre-configured infrastructure stacks that can be
    applied to your project. These provide starting points for common
    deployment patterns.
    """
    
    cloud = _detect_cloud_provider()
    cloud_label = "AWS" if cloud == 'aws' else "Azure"

    console.print()
    console.print(Rule(f"[bold cyan]🗂   Available Stack Templates ({cloud_label})[/bold cyan]", style="cyan"))
    console.print()

    # Show debug info if requested
    if debug:
        import sys
        import site
        console.print(f"[bold]🔍  Debug: Cloud platform detected as [cyan]{cloud_label}[/cyan]. Searching:[/bold]")
        search_paths = [
            SOURCE_ROOT / 'resources' / 'modules' / 'stacks',
            Path.cwd() / 'resources' / 'modules' / 'stacks',
            Path(sys.prefix) / 'resources' / 'modules' / 'stacks',
            Path(sys.prefix) / 'share' / 'modules' / 'stacks',
        ]
        try:
            if hasattr(site, 'USER_BASE') and site.USER_BASE:
                search_paths.append(Path(site.USER_BASE) / 'resources' / 'modules' / 'stacks')
        except:
            pass
        try:
            for site_dir in site.getsitepackages():
                search_paths.append(Path(site_dir) / 'resources' / 'modules' / 'stacks')
        except:
            pass

        for path in search_paths:
            if path.exists():
                console.print(f"  [green]✅[/green]  {path}")
            else:
                console.print(f"  [red]❌[/red]  [dim]{path}[/dim]")
        console.print()

    # Discover stack templates for the detected cloud
    stack_templates = discover_stack_templates(cloud)
    
    if stack_templates:
        table = Table(
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="cyan",
            show_lines=False,
        )
        table.add_column("Template", style="bold green", no_wrap=True)
        table.add_column("Terraform", justify="center", width=12)
        table.add_column("YAML", justify="center", width=8)
        table.add_column("Scripts", justify="center", width=10)
        table.add_column("Pipeline", justify="center", width=10)
        
        for template_name, stack_path in sorted(stack_templates.items()):
            has_terraform = (stack_path / 'terraform').exists()
            has_yaml = (stack_path / 'yaml').exists()
            has_scripts = (stack_path / 'scripts').exists()
            has_pipeline = (stack_path / 'azure-pipelines.yml').exists()
            
            tf_icon = "[green]✓[/green]" if has_terraform else "[dim]–[/dim]"
            yaml_icon = "[green]✓[/green]" if has_yaml else "[dim]–[/dim]"
            scripts_icon = "[green]✓[/green]" if has_scripts else "[dim]–[/dim]"
            pipeline_icon = "[green]✓[/green]" if has_pipeline else "[dim]–[/dim]"
            table.add_row(template_name, tf_icon, yaml_icon, scripts_icon, pipeline_icon)
        
        console.print(table)
    else:
        console.print("[yellow]⚠️   No stack templates found[/yellow]")
        console.print("\n[dim]💡 Tip: Run with --debug flag to see search paths:[/dim]")
        console.print("   [bold]ign list-stack-templates --debug[/bold]")
    
    console.print(f"\n[dim]To add a stack template:[/dim] [bold]ign add-stack-template --stack-name <name>[/bold]")
    console.print()


@click.command()
@click.option('--stack-name', default=None, help='Name of the stack template to add (pick from a list if omitted)')
def add_stack_template(stack_name: str):
    """Add a stack template to the current project.
    
    This command copies a pre-configured stack template from the templates library
    into your project's stacks/ directory (or landing-zones/ for ALZ stacks). 
    Useful for quickly scaffolding common deployment patterns.
    """
    
    if not stack_name:
        templates = discover_stack_templates(_detect_cloud_provider())
        if not templates:
            console.print("[bold red]❌  Error:[/bold red] [red]No stack templates found[/red]")
            return
        stack_name = select('Select a stack template to add', [(n, n) for n in sorted(templates)])

    console.print(Panel(
        f"[bold white]Template:[/bold white] [cyan]{stack_name}[/cyan]",
        title="[bold cyan]🗂   Adding Stack Template[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()
    
    # Check if we're in a project directory
    stacks_dir = Path('stacks')
    if not stacks_dir.exists():
        console.print("[bold red]❌  Error:[/bold red] [red]Not in a project directory. Run [bold]ign init[/bold] first.[/red]")
        console.print("[dim]Or navigate to a directory with a 'stacks/' folder.[/dim]")
        return
    
    # Determine target directory based on stack name
    # If stack name starts with "alz", use landing-zones directory
    is_alz_stack = stack_name.lower().startswith('alz')
    if is_alz_stack:
        target_dir = Path('landing-zones')
        # Create landing-zones directory if it doesn't exist
        if not target_dir.exists():
            cli_helper.create_directory(target_dir)
    else:
        target_dir = stacks_dir
    
    # Check if stack already exists
    dest_path = target_dir / stack_name
    if dest_path.exists():
        if not click.confirm(f"Warning: Stack '{stack_name}' already exists. Overwrite?"):
            console.print("[yellow]Aborted.[/yellow]")
            return
    
    # Discover available stacks for the current cloud platform
    available_stacks = discover_stack_templates(_detect_cloud_provider())

    if not available_stacks:
        console.print("[bold red]❌  Error:[/bold red] [red]No stack templates found[/red]")
        console.print("\n[dim]Run [bold]ign list-stack-templates[/bold] to see available templates[/dim]")
        return
    
    if stack_name not in available_stacks:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Stack template '{stack_name}' not found[/red]")
        console.print(f"\n[bold]Available stack templates:[/bold]")
        for name in sorted(available_stacks.keys()):
            console.print(f"  [green]•[/green]  {name}")
        console.print(f"\n[dim]Run [bold]ign list-stack-templates[/bold] for more details[/dim]")
        return
    
    # Copy the stack
    if copy_stack_template(stack_name, dest_path):
        # If this is an ALZ stack, ensure environments.yml exists in landing-zones root
        if is_alz_stack:
            create_landing_zones_environments_file(target_dir)
        
        # Generate configuration guide for the copied stack
        terraform_dir = dest_path / 'terraform'
        yaml_dir = dest_path / 'yaml'
        # Only generate if at least one of the directories exists
        if terraform_dir.exists() or yaml_dir.exists():
            generate_configuration_guide(dest_path, terraform_dir, yaml_dir)
        
        location_path = f"{target_dir.name}/{stack_name}/"
        console.print()
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="bold cyan", no_wrap=True)
        grid.add_column()
        grid.add_row("1.", "Review and customize the stack configuration")
        grid.add_row("2.", "Update variable values in [bold]terraform/tfvars/*.tfvars[/bold] files")
        grid.add_row("3.", "Review Azure Pipeline configuration")
        console.print(Panel(
            grid,
            title=f"[bold green]✅  Stack Template '{stack_name}' Added Successfully![/bold green]",
            title_align="left",
            style="green",
            expand=False
        ))
        console.print(f"[dim]Stack location:[/dim] [bold]{location_path}[/bold]")
        console.print()
    else:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Failed to add stack template '{stack_name}'[/red]")


# =============================================================================
# ign scaffold
# =============================================================================

@click.command()
def scaffold():
    """Interactive step-by-step wizard to scaffold a complete infrastructure stack.

    Guides you through project initialisation (if needed), stack naming,
    Azure resource selection, and generates all Terraform and pipeline files.
    """
    console.print(Panel(
        "[white]This wizard guides you through creating a fully configured\n"
        "infrastructure stack with Terraform, YAML pipelines, and Azure Pipelines.[/white]",
        title="[bold cyan]🧙  Stack Scaffold Wizard[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    # ── Step 1: Project ───────────────────────────────────────────────────────
    console.print(Rule("[bold]Step 1 of 4 — Project[/bold]", style="cyan"))
    console.print()

    if not Path("stacks").exists():
        console.print("[yellow]⚠  No stacks/ directory — looks like a fresh environment.[/yellow]")
        if click.confirm("  Initialise a new project first?", default=True):
            proj_name = click.prompt("  Project name")
            proj_loc  = click.prompt("  Azure location", default="uksouth")
            proj_code = click.prompt("  Project code (e.g. edp)", default="edp")
            proj_svc  = click.prompt("  Service connection", default="DataPlatform - Dev")
            console.print()
            console.print(Rule("[bold cyan]Initialising project...[/bold cyan]", style="cyan"))
            for d in [
                "stacks", "bootstrap/terraform",
                "templates/scaffold/terraform", "templates/scaffold/yaml",
                "templates/scripts", "templates/yaml", "templates/yaml/build",
                "templates/yaml/deploy", "templates/utils",
                "templates/tests/config/lint", "templates/tests/config/leaks",
                "templates/tests/scripts",
            ]:
                cli_helper.create_directory(Path(d))
            create_utils_module(proj_code)
            create_pipeline_templates()
            create_scaffold_templates()
            copy_script_templates()
            create_devcontainer()
            create_bootstrap_config(proj_code, proj_loc, proj_name)
            console.print()
            console.print("[green]✓  Project initialised.[/green]")
        else:
            console.print("[yellow]Continuing without initialising.[/yellow]")
    else:
        console.print("[green]✓  Project directory detected.[/green]")
    console.print()

    # ── Step 2: Stack details ─────────────────────────────────────────────────
    console.print(Rule("[bold]Step 2 of 4 — Stack Details[/bold]", style="cyan"))
    console.print()

    cicd        = _detect_cicd_platform()
    stack_name  = click.prompt("  Stack name (e.g. dlz, dmz, unity-catalog)")
    description = click.prompt("  Description", default=f"{stack_name} stack")
    svc_conn    = (click.prompt("  Service connection", default="DataPlatform - Dev")
                   if cicd == 'ado' else None)
    console.print()

    # ── Step 3: Azure Resources ───────────────────────────────────────────────
    console.print(Rule("[bold]Step 3 of 4 — Azure Resources[/bold]", style="cyan"))
    console.print()
    console.print("[dim]  Select which Azure resources to scaffold into this stack:[/dim]")
    console.print()

    inc_storage    = click.confirm("  Include Storage Account?",      default=False)
    inc_keyvault   = click.confirm("  Include Key Vault?",            default=False)
    inc_databricks = click.confirm("  Include Databricks Workspace?", default=False)
    console.print()

    # ── Step 4: Confirm ───────────────────────────────────────────────────────
    console.print(Rule("[bold]Step 4 of 4 — Confirm[/bold]", style="cyan"))
    console.print()

    summary = Table.grid(padding=(0, 3))
    summary.add_column(style="bold cyan", no_wrap=True)
    summary.add_column(style="white")
    summary.add_row("Stack name",         stack_name)
    summary.add_row("Description",        description)
    if cicd == 'ado':
        summary.add_row("Service connection", svc_conn)
    else:
        summary.add_row("Workflow", f".github/workflows/{stack_name}.yml")
    summary.add_row("Storage Account",    "[green]yes[/green]" if inc_storage    else "[dim]no[/dim]")
    summary.add_row("Key Vault",          "[green]yes[/green]" if inc_keyvault   else "[dim]no[/dim]")
    summary.add_row("Databricks",         "[green]yes[/green]" if inc_databricks else "[dim]no[/dim]")

    console.print(Panel(summary, title="[bold]Configuration Summary[/bold]",
                        style="cyan", expand=False))
    console.print()

    if not click.confirm("  Create stack with these settings?", default=True):
        console.print("[yellow]Scaffold cancelled.[/yellow]")
        return

    console.print()
    console.print(Rule("[bold cyan]Creating Stack...[/bold cyan]", style="cyan"))
    console.print()

    stacks_dir = Path("stacks")
    stack_dir  = stacks_dir / stack_name
    tf_dir     = stack_dir / "terraform"
    yaml_dir   = stack_dir / "yaml"

    if stack_dir.exists():
        if not click.confirm(f"  Stack '{stack_name}' already exists. Overwrite?"):
            console.print("[yellow]Scaffold cancelled.[/yellow]")
            return

    cli_helper.create_directory(tf_dir)
    generate_terraform_files(tf_dir, stack_name, description,
                             inc_databricks, inc_storage, inc_keyvault)
    if cicd == 'github':
        generate_github_workflow(stack_name)
    else:
        cli_helper.create_directory(yaml_dir)
        generate_yaml_files(yaml_dir, stack_dir, stack_name, svc_conn)
        generate_azure_pipelines(stack_dir, stack_name, svc_conn)
    generate_configuration_guide(stack_dir, tf_dir, yaml_dir)

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Review [bold]stacks/{stack_name}/CONFIGURATION.md[/bold]")
    grid.add_row("2.", f"Update subscription IDs in [bold]stacks/{stack_name}/terraform/tfvars/*.tfvars[/bold]")
    grid.add_row("3.", "Run [bold]ign checklist[/bold] to verify readiness")
    grid.add_row("4.", "Run [bold]ign validate[/bold] to lint YAML files")
    grid.add_row("5.", "Commit and push to trigger your CI/CD pipeline")
    console.print(Panel(
        grid,
        title=f"[bold green]✅  Stack '{stack_name}' Scaffolded Successfully![/bold green]",
        title_align="left",
        style="green",
        expand=False,
    ))
    console.print()


# =============================================================================
# ign rename-stack
# =============================================================================

@click.command("rename-stack")
@click.argument("old_name", required=False)
@click.argument("new_name", required=False)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def rename_stack(old_name, new_name, yes):
    """Rename a stack: moves the folder and updates all internal references."""
    import shutil

    if not old_name:
        old_name = select_stack("Which stack do you want to rename?")
    if not new_name:
        new_name = click.prompt("New stack name")

    resolved   = _resolve_stack_dir(old_name)
    old_dir    = resolved if resolved is not None else Path("stacks") / old_name
    new_dir    = old_dir.parent / new_name

    console.print(Panel(
        f"[bold white]From:[/bold white] [yellow]{old_name}[/yellow]\n"
        f"[bold white]To:[/bold white]   [green]{new_name}[/green]",
        title="[bold cyan]✏️   Rename Stack[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    if not old_dir.exists():
        console.print(f"[bold red]✗  Stack '{old_name}' not found in stacks/ or landing-zones/[/bold red]")
        return

    if new_dir.exists():
        console.print(f"[bold red]✗  A stack named '{new_name}' already exists.[/bold red]")
        return

    _RENAME_EXTS = {".tf", ".tfvars", ".yml", ".yaml", ".json", ".md"}

    # Dry-run: collect files that will be touched
    to_update = []
    for f in old_dir.rglob("*"):
        if f.is_file() and f.suffix in _RENAME_EXTS:
            try:
                content = f.read_text(encoding="utf-8")
            except Exception:
                continue
            if old_name in content:
                to_update.append(f)

    old_wf = Path(".github/workflows") / f"{old_name}.yml"
    new_wf = Path(".github/workflows") / f"{new_name}.yml"
    if old_wf.exists() and new_wf.exists():
        console.print(f"[bold red]✗  Workflow {new_wf} already exists.[/bold red]")
        return

    console.print(f"[dim]  Will rename folder:[/dim] {old_dir.parent.name}/{old_name} → {new_dir.parent.name}/{new_name}")
    if old_wf.exists():
        console.print(f"[dim]  Will rename workflow:[/dim] {old_wf.as_posix()} → {new_wf.as_posix()}")
    console.print(f"[dim]  Will update {len(to_update)} file(s) containing '{old_name}'[/dim]")
    console.print()

    if not yes and not click.confirm("Proceed?"):
        console.print("[yellow]Rename cancelled.[/yellow]")
        return

    # 1. Move directory
    shutil.move(str(old_dir), str(new_dir))
    console.print(f"  [green]✔[/green]  Moved folder")

    # 2. Update references inside files
    updated = 0
    for rel in to_update:
        # path relative to old_dir → same relative under new_dir
        rel_path  = rel.relative_to(old_dir)
        new_fpath = new_dir / rel_path
        if not new_fpath.exists():
            continue
        try:
            content = new_fpath.read_text(encoding="utf-8")
            # Word-boundary match so we only rewrite the stack name as a whole
            # token, not substrings inside unrelated identifiers/URLs
            # (e.g. renaming "dev" must not touch "developer_portal").
            new_content = re.sub(
                r'(?<![\w-])' + re.escape(old_name) + r'(?![\w-])',
                new_name,
                content,
            )
            if new_content != content:
                new_fpath.write_text(new_content, encoding="utf-8")
                console.print(f"  [green]✔[/green]  Updated [dim]{new_fpath}[/dim]")
                updated += 1
        except Exception as exc:
            console.print(f"  [yellow]⚠[/yellow]  Could not update {new_fpath}: {exc}")

    # 3. GitHub Actions caller workflow lives outside the stack folder
    if old_wf.exists():
        try:
            content = old_wf.read_text(encoding="utf-8")
            new_content = re.sub(
                r'(?<![\w-])' + re.escape(old_name) + r'(?![\w-])',
                new_name,
                content,
            )
            new_wf.write_text(new_content, encoding="utf-8")
            old_wf.unlink()
            console.print(f"  [green]✔[/green]  Renamed workflow [dim]{new_wf}[/dim]")
            updated += 1
        except Exception as exc:
            console.print(f"  [yellow]⚠[/yellow]  Could not rename workflow {old_wf}: {exc}")

    console.print()
    console.print(Panel(
        f"[bold green]✅  Stack renamed to '{new_name}'. {updated} file(s) updated.[/bold green]",
        style="green",
        expand=False,
    ))
    console.print()


# =============================================================================
# ign env-clone
# =============================================================================

@click.command("env-clone")
@click.argument("stack", required=False)
@click.argument("source_env", required=False)
@click.argument("new_env", required=False)
def env_clone(stack, source_env, new_env):
    """Clone an environment's tfvars into a new environment for a stack.

    Example: ign env-clone my-stack dev staging
    """
    if not stack:
        stack = select_stack("Which stack do you want to clone an environment in?")
    tf_dir     = (_resolve_stack_dir(stack) or (Path("stacks") / stack)) / "terraform"

    if not source_env:
        _tfv = (tf_dir / "tfvars") if (tf_dir / "tfvars").exists() else tf_dir
        _envs = _discover_env_tfvars(_tfv) if tf_dir.exists() else []
        if not _envs:
            console.print(f"[bold red]✗  No environment tfvars found for stack '{stack}'.[/bold red]")
            return
        source_env = select("Which environment do you want to copy from?", _envs)
    if not new_env:
        new_env = click.prompt("Name of the new environment")

    console.print(Panel(
        f"[bold white]Stack:[/bold white]  [cyan]{stack}[/cyan]\n"
        f"[bold white]From:[/bold white]   [yellow]{source_env}[/yellow]\n"
        f"[bold white]To:[/bold white]     [green]{new_env}[/green]",
        title="[bold cyan]📋  Clone Environment[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    if not tf_dir.exists():
        console.print(f"[bold red]✗  No terraform/ directory found for stack '{stack}'.[/bold red]")
        return

    # Support both terraform/tfvars/ subdirectory and terraform/ root
    tfvars_dir = (tf_dir / "tfvars") if (tf_dir / "tfvars").exists() else tf_dir

    src = tfvars_dir / f"{source_env}.tfvars"
    dst = tfvars_dir / f"{new_env}.tfvars"

    if not src.exists():
        console.print(f"[bold red]✗  Source file not found: {src}[/bold red]")
        return

    if dst.exists():
        if not click.confirm(f"  '{new_env}.tfvars' already exists. Overwrite?"):
            console.print("[yellow]Clone cancelled.[/yellow]")
            return

    content = src.read_text(encoding="utf-8")
    lines   = content.splitlines()

    # Prompt for any line containing a UUID, a lifecycle env label, or a
    # CAF-aligned region abbreviation (landing zones are region-scoped).
    _ENV_NAMES  = set(_ENV_ORDER) | _CAF_REGION_ABBRS
    _UUID_RE    = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I)

    new_lines = []
    replacements = 0
    console.print(f"[bold]Review values to update (press Enter to keep current):[/bold]\n")

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") or "=" not in stripped:
            new_lines.append(line)
            continue

        key, _, val = stripped.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")

        needs_update = bool(_UUID_RE.search(val)) or (source_env in val) or (val.lower() in _ENV_NAMES)
        if needs_update:
            console.print(f"  [cyan]{key}[/cyan] = [yellow]{val}[/yellow]")
            new_val = click.prompt(f"  New value for '{key}'", default=val)
            if new_val != val:
                # Reconstruct line preserving original quoting style, replacing
                # only within the value part (after '=') so a value that also
                # appears inside the key can't corrupt the key.
                head, sep, tail = line.partition("=")
                orig_val_in_line = tail.strip()
                if orig_val_in_line[:1] in ('"', "'"):
                    q = orig_val_in_line[0]
                    new_tail = tail.replace(f"{q}{val}{q}", f"{q}{new_val}{q}", 1)
                else:
                    new_tail = tail.replace(val, new_val, 1)
                new_lines.append(head + sep + new_tail)
                replacements += 1
                continue

        new_lines.append(line)

    dst.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    console.print()
    console.print(Panel(
        f"[bold green]✅  Created {dst}  ({replacements} value(s) updated)[/bold green]",
        style="green",
        expand=False,
    ))
    console.print()
