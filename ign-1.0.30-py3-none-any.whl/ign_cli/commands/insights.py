"""insights – part of the ign CLI (split from ignition.py)."""

import click
import re
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.rule import Rule
from pathlib import Path
from ign_cli.commands.security import _PLACEHOLDER_UUID
from ign_cli.console import console
from ign_cli.core.parsing import _parse_providers_tf, _parse_tfvars
from ign_cli.core.settings import _detect_cicd_platform, _stack_pipeline_file
from ign_cli.core.stacks import STACK_DIRS, _discover_env_tfvars, _iter_all_stacks, _resolve_stack_dir
from ign_cli.core.prompts import select_stack, select_stack_or_all


# =============================================================================
# ign doctor
# =============================================================================

@click.command()
def doctor():
    """Check your environment is correctly set up to use ign."""
    import subprocess
    import sys
    import importlib.metadata

    console.print(Panel(
        "[white]Checks tools, authentication, Python packages and project structure.[/white]",
        title="[bold cyan]🩺  Environment Health Check[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    checks = []  # (name, status, detail, action)

    pv = sys.version_info
    ver_str = f"{pv.major}.{pv.minor}.{pv.micro}"
    checks.append(("Python", "ok" if pv >= (3, 7) else "error", ver_str,
                   "" if pv >= (3, 7) else "Upgrade to >= 3.7"))

    try:
        r = subprocess.run(["terraform", "--version"], capture_output=True, text=True, timeout=10)
        checks.append(("Terraform", "ok", r.stdout.strip().split("\n")[0], ""))
    except FileNotFoundError:
        checks.append(("Terraform", "error", "Not installed",
                       "https://developer.hashicorp.com/terraform/install"))
    except Exception as e:
        checks.append(("Terraform", "warning", str(e), ""))

    az_ok = False
    try:
        r = subprocess.run(["az", "--version"], capture_output=True, text=True, timeout=10)
        az_ok = r.returncode == 0
        checks.append(("Azure CLI", "ok", r.stdout.strip().split("\n")[0], ""))
    except FileNotFoundError:
        checks.append(("Azure CLI", "warning", "Not installed", "https://aka.ms/installazurecli"))
    except Exception as e:
        checks.append(("Azure CLI", "warning", str(e), ""))

    if az_ok:
        try:
            r = subprocess.run(
                ["az", "account", "show", "--query", "name", "-o", "tsv"],
                capture_output=True, text=True, timeout=15,
            )
            if r.returncode == 0 and r.stdout.strip():
                checks.append(("Azure Auth", "ok", r.stdout.strip(), ""))
            else:
                checks.append(("Azure Auth", "warning", "Not authenticated", "Run: az login"))
        except Exception as e:
            checks.append(("Azure Auth", "warning", str(e), ""))

    try:
        r = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=10)
        checks.append(("git", "ok", r.stdout.strip(), ""))
    except FileNotFoundError:
        checks.append(("git", "warning", "Not found", "https://git-scm.com"))

    for dist, imp in [
        ("click", "click"), ("PyYAML", "yaml"), ("rich", "rich"),
        ("yamllint", "yamllint"), ("checkov", "checkov"),
    ]:
        try:
            __import__(imp)
            try:
                ver = importlib.metadata.version(dist)
            except Exception:
                ver = "installed"
            checks.append((f"pkg: {dist}", "ok", ver, ""))
        except ImportError:
            checks.append((f"pkg: {dist}", "error", "Not installed", f"pip install {dist}"))

    import shutil as _shutil
    import platform as _platform
    if _shutil.which("tfsec"):
        try:
            r = subprocess.run(["tfsec", "--version"], capture_output=True, text=True, timeout=10)
            checks.append(("tfsec", "ok", r.stdout.strip() or "installed", ""))
        except Exception:
            checks.append(("tfsec", "ok", "installed", ""))
    else:
        _os = _platform.system()
        if _os == "Windows":
            hint = "choco install tfsec  OR  winget install tfsec"
        elif _os == "Darwin":
            hint = "brew install tfsec"
        else:
            hint = "https://aquasecurity.github.io/tfsec/latest/getting-started/installation/"
        checks.append(("tfsec", "warning", "Not installed", hint))

    for label, p, hint in [
        ("stacks/",    Path("stacks"),    "Run: ign init"),
        ("bootstrap/", Path("bootstrap"), "Run: ign init"),
        ("templates/", Path("templates"), "Run: ign init"),
    ]:
        if p.exists():
            items = list(p.iterdir())
            checks.append((label, "ok", f"{len(items)} item(s)", ""))
        else:
            checks.append((label, "warning", "Not found", hint))

    table = Table(box=box.ROUNDED, header_style="bold cyan", border_style="cyan", show_lines=False)
    table.add_column("Check", style="bold white", no_wrap=True, min_width=22)
    table.add_column("Status", justify="center", width=10)
    table.add_column("Detail")
    table.add_column("Action", style="dim cyan")

    ok_n = warn_n = err_n = 0
    for name, status, detail, action in checks:
        if status == "ok":
            cell = "[green]✓  OK[/green]"; ok_n += 1
        elif status == "warning":
            cell = "[yellow]⚠  WARN[/yellow]"; warn_n += 1
        else:
            cell = "[red]✗  FAIL[/red]"; err_n += 1
        table.add_row(name, cell, detail, action)

    console.print(table)
    console.print()

    if err_n:
        style, title = "red", "[bold red]✗  Issues Found — Fix Errors Before Proceeding[/bold red]"
    elif warn_n:
        style, title = "yellow", "[bold yellow]⚠  Environment Ready with Warnings[/bold yellow]"
    else:
        style, title = "green", "[bold green]✅  All Checks Passed — Good to Go![/bold green]"

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("[green]✓  Passed[/green]", str(ok_n))
    g.add_row("[yellow]⚠  Warnings[/yellow]", str(warn_n))
    g.add_row("[red]✗  Errors[/red]", str(err_n))
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()


@click.command()
@click.option("--stack", default=None, help="Stack name")
@click.option("--envs",  default=None, help="Comma-separated envs to compare (e.g. dev,prd)")
def compare(stack, envs):
    """Compare .tfvars files across environments for a stack.

    Highlights every variable that differs between dev / tst / uat / prd.
    """
    if not stack:
        stack = select_stack("Which stack do you want to compare?")

    resolved = _resolve_stack_dir(stack)
    if resolved is None or not (resolved / "terraform").exists():
        console.print(f"[bold red]❌  Stack '{stack}' not found.[/bold red]")
        console.print("[dim]Run [bold]ign list-stacks[/bold] to see available stacks.[/dim]")
        return
    stack_dir = resolved / "terraform"

    # Support both terraform/tfvars/ subdirectory and terraform/ root
    tfvars_dir = stack_dir / "tfvars" if (stack_dir / "tfvars").exists() else stack_dir

    # When --envs isn't given, auto-discover whatever <target>.tfvars files
    # exist so this works for both lifecycle envs (dev/tst/uat/prd) and
    # region-based landing zones (uks/ukw/...).
    env_list = (
        [e.strip() for e in envs.split(",") if e.strip()]
        if envs
        else _discover_env_tfvars(tfvars_dir)
    )

    if not env_list:
        console.print(f"[yellow]⚠  No .tfvars files found in [bold]{tfvars_dir}[/bold][/yellow]")
        console.print("[dim]Expected one or more <target>.tfvars files — lifecycle envs "
                      "(dev.tfvars, prd.tfvars) or regions (uks.tfvars, ukw.tfvars).[/dim]")
        return

    env_data = {}
    missing  = []
    for env in env_list:
        fpath = tfvars_dir / f"{env}.tfvars"
        if fpath.exists():
            env_data[env] = _parse_tfvars(fpath)
        else:
            missing.append(env)
            env_data[env] = {}

    if missing:
        console.print(f"[yellow]⚠  Missing tfvars for: {', '.join(missing)}[/yellow]")

    all_keys = sorted({k for d in env_data.values() for k in d})
    if not all_keys:
        console.print("[yellow]⚠  No variables found in tfvars files.[/yellow]")
        return

    console.print(Panel(
        f"[bold white]Stack:[/bold white] [cyan]{stack}[/cyan]   "
        f"[bold white]Environments:[/bold white] [cyan]{' | '.join(e.upper() for e in env_list)}[/cyan]",
        title="[bold cyan]📊  Environment Comparison[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Variable", style="bold white", no_wrap=True, ratio=3)
    for env in env_list:
        table.add_column(env.upper(), ratio=3)

    diffs = 0
    for key in all_keys:
        vals    = [env_data[env].get(key) for env in env_list]
        present = [v for v in vals if v is not None]
        is_diff = len(set(present)) > 1 or len(present) < len(env_list)
        if is_diff:
            diffs += 1
        cells = []
        for v in vals:
            if v is None:
                cells.append("[dim]— missing —[/dim]")
            elif is_diff:
                cells.append(f"[yellow]{v}[/yellow]")
            else:
                cells.append(f"[dim]{v}[/dim]")
        table.add_row(key, *cells)

    console.print(table)
    console.print()

    style = "yellow" if diffs else "green"
    title = (
        f"[bold yellow]⚠  {diffs} variable(s) differ across environments[/bold yellow]"
        if diffs else
        "[bold green]✅  All variables are consistent across environments[/bold green]"
    )
    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("Variables checked",       str(len(all_keys)))
    g.add_row("[yellow]Differ[/yellow]",  str(diffs))
    g.add_row("[green]Consistent[/green]", str(len(all_keys) - diffs))
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()


# =============================================================================
# ign status
# =============================================================================

@click.command()
def status():
    """Show a live dashboard of every stack and its readiness."""
    import subprocess

    stack_paths = _iter_all_stacks()
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory.[/bold red] Run [bold]ign init[/bold] first.")
        return

    if not stack_paths:
        console.print("[yellow]No stacks found.[/yellow]")
        return

    project_root = Path.cwd()
    git_ok = False
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, cwd=str(project_root),
        )
        git_ok = r.returncode == 0
    except FileNotFoundError:
        pass

    console.print(Panel(
        f"[bold white]Project:[/bold white] [cyan]{project_root.name}[/cyan]   "
        f"[bold white]Stacks:[/bold white] [cyan]{len(stack_paths)}[/cyan]",
        title="[bold cyan]📊  Project Status Dashboard[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Stack",        style="bold white", no_wrap=True)
    table.add_column("Terraform",    justify="center", width=11)
    table.add_column("YAML",         justify="center", width=8)
    table.add_column("Pipeline",     justify="center", width=10)
    table.add_column("Resources",    justify="right",  width=11)
    table.add_column("Last Changed", width=18, style="dim")

    total_res  = 0
    yaml_errors = 0
    try:
        from yamllint import linter as _yl2
        from yamllint.config import YamlLintConfig as _YLC2
        _yl2_cfg = _YLC2(
            "extends: default\nrules:\n  line-length: disable\n  document-start: disable\n"
        )
        yl2_ok = True
    except ImportError:
        yl2_ok = False

    for spath in stack_paths:
        sname     = spath.name
        tf_dir    = spath / "terraform"
        yaml_dir  = spath / "yaml"
        pipe_file = _stack_pipeline_file(spath, project_root)

        tf_cell   = "[green]✓[/green]" if tf_dir.exists()    else "[red]✗[/red]"
        if _detect_cicd_platform(project_root) == 'github':
            yaml_cell = "[dim]n/a[/dim]"  # GitHub stacks have no per-stack yaml/ dir
        else:
            yaml_cell = "[green]✓[/green]" if yaml_dir.exists()  else "[red]✗[/red]"
        pipe_cell = "[green]✓[/green]" if pipe_file.exists() else "[dim]—[/dim]"

        res_count = 0
        main_tf = tf_dir / "main.tf"
        if main_tf.exists():
            try:
                content   = main_tf.read_text(encoding="utf-8")
                res_count = len(re.findall(r'^(?:resource|module)\s+"', content, re.MULTILINE))
                total_res += res_count
            except Exception:
                pass
        res_cell = str(res_count) if res_count else "[dim]—[/dim]"

        last_changed = "[dim]—[/dim]"
        if git_ok:
            try:
                r = subprocess.run(
                    ["git", "log", "-1", "--format=%cr", "--", str(spath)],
                    capture_output=True, text=True, cwd=str(project_root),
                )
                if r.returncode == 0 and r.stdout.strip():
                    last_changed = r.stdout.strip()
            except Exception:
                pass

        if yl2_ok and yaml_dir.exists():
            for f in list(yaml_dir.glob("*.yml")) + list(yaml_dir.glob("*.yaml")):
                try:
                    probs = [p for p in _yl2.run(f.read_text(encoding="utf-8"), _yl2_cfg)
                             if p.level == "error"]
                    yaml_errors += len(probs)
                except Exception:
                    pass

        table.add_row(sname, tf_cell, yaml_cell, pipe_cell, res_cell, last_changed)

    console.print(table)
    console.print()

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("Stacks",                    str(len(stack_paths)))
    g.add_row("Total resources / modules", str(total_res))
    g.add_row(
        "YAML errors",
        f"[red]{yaml_errors}[/red]" if yaml_errors else "[green]0[/green]",
    )
    style = "yellow" if yaml_errors else "green"
    title = (
        "[bold yellow]⚠  YAML Issues — run ign validate for details[/bold yellow]"
        if yaml_errors else
        "[bold green]✅  Project Looks Healthy[/bold green]"
    )
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()


# =============================================================================
# ign upgrade  (helpers + command)
# =============================================================================

def _fetch_latest_tf_provider_version(source):
    """Query the Terraform Registry for the latest version of a provider."""
    import urllib.request
    import json as _json

    parts = source.strip().split("/")
    if len(parts) != 2:
        return None
    namespace, ptype = parts
    url = f"https://registry.terraform.io/v1/providers/{namespace}/{ptype}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ign-cli/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
            return data.get("version")
    except Exception:
        return None


@click.command()
@click.option("--stack",  default=None, help="Check a specific stack")
@click.option("--all",    "upgrade_all", is_flag=True, help="Check all stacks")
@click.option("--apply",  "do_apply",   is_flag=True, help="Write updated versions to providers.tf")
def upgrade(stack, upgrade_all, do_apply):
    """Check Terraform provider versions against the registry and optionally update them."""
    if not stack and not upgrade_all:
        stack, upgrade_all = select_stack_or_all("Check a stack or all stacks?", all_label='All stacks', default_all=True)

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target      = (
        [p.name for p in _iter_all_stacks()]
        if upgrade_all else [stack]
    )
    scope_label = "All Stacks" if upgrade_all else f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]   "
        f"[bold white]Mode:[/bold white] [cyan]{'apply updates' if do_apply else 'check only'}[/cyan]",
        title="[bold cyan]⬆   Provider Version Checker[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()
    console.print("[dim]Querying Terraform Registry...[/dim]\n")

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Stack",    style="bold white", no_wrap=True)
    table.add_column("Provider", style="white")
    table.add_column("Current",  style="dim", justify="center", width=20)
    table.add_column("Latest",   justify="center", width=12)
    table.add_column("Status",   justify="center", width=18)

    updates_available = 0
    updates_applied   = 0

    for sname in target:
        tf_dir       = (_resolve_stack_dir(sname) or (stacks_dir / sname)) / "terraform"
        providers_tf = tf_dir / "providers.tf"
        if not providers_tf.exists():
            table.add_row(sname, "[dim]No providers.tf[/dim]", "—", "—", "[dim]—[/dim]")
            continue

        providers = _parse_providers_tf(providers_tf)
        if not providers:
            table.add_row(sname, "[dim]No providers found[/dim]", "—", "—", "[dim]—[/dim]")
            continue

        for prov in providers:
            latest  = _fetch_latest_tf_provider_version(prov["source"])
            current = prov["version"]

            if latest is None:
                table.add_row(sname, prov["name"], current, "[dim]—[/dim]", "[dim]API unavailable[/dim]")
                continue

            current_base = re.sub(r"[>=<~! ]", "", current).split(",")[0].strip()
            outdated     = current_base != latest

            if outdated:
                updates_available += 1
                status_cell = f"[yellow]⬆  {latest} available[/yellow]"
                latest_cell = f"[yellow]{latest}[/yellow]"
            else:
                status_cell = "[green]✓  Up to date[/green]"
                latest_cell = f"[green]{latest}[/green]"

            table.add_row(sname, prov["name"], current, latest_cell, status_cell)

            if do_apply and outdated:
                try:
                    content = providers_tf.read_text(encoding="utf-8")
                    # Only rewrite the version *inside this provider's block* —
                    # anchoring on the provider name avoids clobbering other
                    # providers' versions or the terraform required_version.
                    pattern = re.compile(
                        r'(' + re.escape(prov["name"]) + r'\s*=\s*\{[^}]*?version\s*=\s*")([^"]+)(")',
                        re.DOTALL,
                    )
                    new_content, n = pattern.subn(
                        lambda m, lat=latest: f'{m.group(1)}{lat}{m.group(3)}',
                        content,
                        count=1,
                    )
                    if n:
                        providers_tf.write_text(new_content, encoding="utf-8")
                        updates_applied += 1
                    else:
                        console.print(
                            f"[yellow]⚠  Could not locate version for provider "
                            f"'{prov['name']}' in {providers_tf}[/yellow]"
                        )
                except Exception as e:
                    console.print(f"[red]Failed to update {providers_tf}: {e}[/red]")

    console.print(table)
    console.print()

    if updates_available == 0:
        console.print(Panel("[bold green]✅  All providers are up to date![/bold green]",
                            style="green", expand=False))
    elif do_apply:
        console.print(Panel(
            f"[bold green]✅  Applied {updates_applied} update(s) to providers.tf files.[/bold green]\n"
            "[dim]Run [bold]terraform init -upgrade[/bold] in each stack to download new providers.[/dim]",
            style="green", expand=False,
        ))
    else:
        console.print(Panel(
            f"[bold yellow]⬆   {updates_available} update(s) available.[/bold yellow]\n"
            "[dim]Run [bold]ign upgrade --apply[/bold] to update providers.tf files.[/dim]",
            style="yellow", expand=False,
        ))
    console.print()


# =============================================================================
# ign cost
# =============================================================================

@click.command()
@click.option("--stack",  default=None, help="Stack to estimate costs for")
@click.option("--all",    "cost_all",   is_flag=True, help="Estimate costs for all stacks")
@click.option("--format", "out_fmt",
              default="table",
              type=click.Choice(["table", "json", "html"], case_sensitive=False),
              help="Infracost output format")
def cost(stack, cost_all, out_fmt):
    """Estimate infrastructure costs using Infracost.

    Requires Infracost: https://www.infracost.io/docs/
    """
    import subprocess

    try:
        r = subprocess.run(["infracost", "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            raise FileNotFoundError
        ver = (r.stdout or r.stderr).strip()
    except FileNotFoundError:
        console.print(Panel(
            "[red]infracost is not installed or not on your PATH.[/red]\n\n"
            "[dim]Install from:[/dim]  [bold]https://www.infracost.io/docs/#quick-start[/bold]\n"
            "[dim]Brew install:[/dim]  [bold]brew install infracost[/bold]\n"
            "[dim]After install:[/dim] [bold]infracost auth login[/bold]",
            title="[bold red]❌  infracost Not Found[/bold red]",
            title_align="left",
            style="red",
            expand=False,
        ))
        return

    if not stack and not cost_all:
        stack, cost_all = select_stack_or_all("Estimate a stack or all stacks?", all_label='All stacks', default_all=False)

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target = (
        [p.name for p in _iter_all_stacks()]
        if cost_all else [stack]
    )

    console.print(Panel(
        f"[bold white]Scope:[/bold white]  [cyan]{'All Stacks' if cost_all else stack}[/cyan]\n"
        f"[bold white]Tool:[/bold white]   [cyan]{ver}[/cyan]",
        title="[bold cyan]💰  Cost Estimator[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    for sname in target:
        tf_dir = (_resolve_stack_dir(sname) or (stacks_dir / sname)) / "terraform"
        if not tf_dir.exists():
            console.print(f"[yellow]⚠  Skipping {sname}: no terraform/ directory[/yellow]")
            continue
        console.print(Rule(f"[bold]{sname}[/bold]", style="cyan"))
        subprocess.run(["infracost", "breakdown", "--path", str(tf_dir), "--format", out_fmt])
        console.print()

    console.print(Panel(
        "[dim]Costs are estimates. Actual costs may differ.[/dim]\n"
        "[dim]For a diff vs last run:[/dim] [bold]infracost diff --path <terraform-dir>[/bold]",
        style="dim",
        expand=False,
    ))
    console.print()


# =============================================================================
# ign checklist
# =============================================================================

@click.command()
@click.option("--stack", default=None, help="Stack to check")
@click.option("--all",   "check_all", is_flag=True, help="Check all stacks")
def checklist(stack, check_all):
    """Run a pre-deployment readiness checklist for a stack.

    Verifies files exist, placeholder values are replaced, YAML is valid,
    and the service connection has been customised.
    """
    if not stack and not check_all:
        stack, check_all = select_stack_or_all("Check a stack or all stacks?", all_label='All stacks', default_all=False)

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target      = (
        [p.name for p in _iter_all_stacks()]
        if check_all else [stack]
    )
    scope_label = "All Stacks" if check_all else f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]",
        title="[bold cyan]📋  Pre-Deployment Checklist[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    try:
        from yamllint import linter as _yl3
        from yamllint.config import YamlLintConfig as _YLC3
        _yl3_cfg = _YLC3(
            "extends: default\nrules:\n  line-length: disable\n  document-start: disable\n"
        )
        yl3_ok = True
    except ImportError:
        yl3_ok = False

    total_pass = total_fail = total_warn = 0

    for sname in target:
        spath    = _resolve_stack_dir(sname) or (stacks_dir / sname)
        tf_dir   = spath / "terraform"
        yaml_dir = spath / "yaml"

        checks = []  # (item, "pass"|"fail"|"warn", detail)

        if _detect_cicd_platform() == 'github':
            pipeline_checks = [(f".github/workflows/{sname}.yml", Path(".github/workflows") / f"{sname}.yml")]
        else:
            pipeline_checks = [("yaml/ directory", yaml_dir),
                               ("azure-pipelines.yml", spath / "azure-pipelines.yml")]
        for label, p in [
            ("terraform/ directory",   tf_dir),
            *pipeline_checks,
            ("CONFIGURATION.md",       spath / "CONFIGURATION.md"),
            ("terraform/main.tf",      tf_dir / "main.tf"),
            ("terraform/variables.tf", tf_dir / "variables.tf"),
            ("terraform/providers.tf", tf_dir / "providers.tf"),
        ]:
            checks.append((label, "pass" if p.exists() else "fail",
                           "Found" if p.exists() else "Missing"))

        tfvars_search_dir = (tf_dir / "tfvars") if (tf_dir / "tfvars").exists() else tf_dir
        tfvars = list(tfvars_search_dir.glob("*.tfvars")) if tf_dir.exists() else []
        if tfvars:
            count = sum(
                f.read_text(encoding="utf-8", errors="ignore").count(_PLACEHOLDER_UUID)
                for f in tfvars
            )
            checks.append((
                "No placeholder UUIDs in tfvars",
                "pass" if count == 0 else "fail",
                "All replaced" if count == 0 else f"{count} placeholder(s) still present",
            ))
        else:
            checks.append(("tfvars files", "warn", "No .tfvars files found"))

        if yl3_ok and yaml_dir.exists():
            yaml_errs = sum(
                len([p for p in _yl3.run(f.read_text(encoding="utf-8", errors="ignore"), _yl3_cfg)
                     if p.level == "error"])
                for f in list(yaml_dir.glob("*.yml")) + list(yaml_dir.glob("*.yaml"))
            )
            checks.append((
                "YAML files valid",
                "pass" if yaml_errs == 0 else "fail",
                "No errors" if yaml_errs == 0 else f"{yaml_errs} error(s) — run ign validate",
            ))
        elif not yl3_ok:
            checks.append(("YAML lint", "warn", "yamllint not installed"))

        gh_wf = Path(".github/workflows") / f"{sname}.yml"
        if _detect_cicd_platform() == 'github' and gh_wf.exists():
            content = gh_wf.read_text(encoding="utf-8", errors="ignore")
            if "<GITHUB_ORG>" in content:
                checks.append(("CI/CD repo configured", "fail",
                               "<GITHUB_ORG> placeholder in workflow"))
            elif re.search(r"_terraform-pipeline\.yml@(main|develop)\b", content):
                checks.append(("CI/CD repo pinned", "warn",
                               "Workflow tracks a branch - pin to a release tag or SHA"))
            else:
                checks.append(("CI/CD repo pinned", "pass", "Pinned"))

        pipe = spath / "azure-pipelines.yml"
        if pipe.exists():
            content = pipe.read_text(encoding="utf-8", errors="ignore")
            if "DataPlatform - Dev" in content or "YOUR_SERVICE_CONNECTION" in content:
                checks.append(("Service connection customised", "warn",
                                "Default/placeholder value in azure-pipelines.yml"))
            else:
                checks.append(("Service connection customised", "pass", "Looks customised"))

        console.print(Rule(f"[bold white]{sname}[/bold white]", style="cyan"))
        for item, status, detail in checks:
            if status == "pass":
                icon = "[green]✓[/green]"; total_pass += 1
            elif status == "fail":
                icon = "[red]✗[/red]";    total_fail += 1
            else:
                icon = "[yellow]⚠[/yellow]"; total_warn += 1
            console.print(f"  {icon}  [white]{item}[/white]  [dim]{detail}[/dim]")
        console.print()

    if total_fail:
        style, title = "red",    f"[bold red]✗  Not Ready — {total_fail} check(s) failed[/bold red]"
    elif total_warn:
        style, title = "yellow", f"[bold yellow]⚠  Ready with {total_warn} warning(s)[/bold yellow]"
    else:
        style, title = "green",  "[bold green]✅  All Checks Passed — Ready to Deploy![/bold green]"

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("[green]✓  Passed[/green]",     str(total_pass))
    g.add_row("[yellow]⚠  Warnings[/yellow]", str(total_warn))
    g.add_row("[red]✗  Failed[/red]",         str(total_fail))
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()

    if total_fail:
        raise click.exceptions.Exit(code=1)
