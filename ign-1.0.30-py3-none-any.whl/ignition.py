#!/usr/bin/env python3
"""
Infrastructure CLI Tool
A CLI for DevOps engineers to scaffold infrastructure projects and manage deployment stacks.

This file is a thin entry point; the implementation lives in the ign_cli/ package.
"""

from ign_cli.cli import cli, __version__  # noqa: F401

if __name__ == '__main__':
    cli()
